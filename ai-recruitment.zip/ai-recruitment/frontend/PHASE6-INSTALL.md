# Phase 6 frontend: voice interviews

New files only (nothing of yours is overwritten):

  src/types/interview.ts
  src/lib/interviewApi.ts            (uses your existing src/lib/api.ts)
  src/lib/useSpeech.ts               (microphone + spoken questions)
  src/components/interview/*         (Orb, PreCheck, InterviewRoom, HRInterviewPanel, EvaluationView, InterviewChip, CandidateInterviewCard)
  src/app/candidate/interview/[id]/page.tsx   (candidate interview room)
  src/app/hr/applications/[id]/interview/page.tsx   (HR interview page, works on its own)

## Four small edits in your existing pages

1. Candidate application type (in src/types/, the one that describes an item from GET /api/applications/mine). Add:

       interview?: { id: number; status: "invited" | "in_progress" | "completed" } | null;

2. (simplest) Candidate "My applications" page: one line inside each application card, no type change needed:

       import CandidateInterviewButton from "@/components/interview/CandidateInterviewButton";
       <CandidateInterviewButton applicationId={app.id} />

   (Older option) Candidate "My applications" page (src/app/candidate/applications/page.tsx). Import and put it inside each application card:

       import CandidateInterviewCard from "@/components/interview/CandidateInterviewCard";
       ...
       <CandidateInterviewCard interview={app.interview} />

3. (recommended, shows only for candidates whose decision is "Interview")
   HR candidate page (src/app/hr/applications/[id]/page.tsx):

       import InterviewSection from "@/components/interview/InterviewSection";
       <InterviewSection applicationId={application.id} decision={application.decision} analysisStatus={application.analysis_status} />

   Older option: HR candidate page (src/app/hr/applications/[id]/page.tsx). Either add a link:

       <Link href={`/hr/applications/${id}/interview`}>AI interview</Link>

   or show the panel directly (use your own variable for the application id and status):

       import HRInterviewPanel from "@/components/interview/HRInterviewPanel";
       <HRInterviewPanel applicationId={application.id} canInvite={application.analysis_status === "done"} />

4. Ranking page: the API now returns `interview` on each ranked candidate. Add to its type:

       interview?: { status: "invited" | "in_progress" | "completed"; score?: number | null; label?: string | null } | null;

   and next to the candidate's name:

       import InterviewChip from "@/components/interview/InterviewChip";
       <InterviewChip interview={row.interview} />

If `src/lib/api.ts` exports your axios instance under another name, fix the one line at the top of src/lib/interviewApi.ts.
No new npm packages are needed (uses axios and lucide-react, which you already have).
