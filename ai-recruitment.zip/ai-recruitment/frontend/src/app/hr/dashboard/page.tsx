"use client";

import Link from "next/link";
import {
  ArrowRight, Bot, CalendarClock, CheckCircle2, ChevronRight, FilePenLine, Gauge, Hourglass, Mic, Plus, Sparkles,
  UserSearch, Users, Zap,
} from "lucide-react";
import { C, Funnel, Legend, Meter, SegmentedBar, TimelineChart } from "@/components/dashboard/charts";
import { ACT_FALLBACK, ACT_ICON, Card, Insights, Loading, ScorePill, Stat, ago, useInsights } from "@/components/dashboard/shared";
import DecisionBadge from "@/components/DecisionBadge";

function greeting(): string {
  const h = new Date().getHours();
  return h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
}

const more = "inline-flex items-center gap-1 text-sm font-medium text-maroon-700 hover:underline";

/** Concrete things HR can do next, worked out from the numbers. */
function todos(d: Insights) {
  const out: { key: string; href: string; icon: typeof Bot; tone: string; title: string; sub: string }[] = [];
  const k = d.kpis;
  if (d.decisions.under_review > 0)
    out.push({ key: "review", href: "/hr/candidates", icon: UserSearch, tone: "bg-amber-50 text-amber-800",
      title: `${d.decisions.under_review} ${d.decisions.under_review === 1 ? "candidate is" : "candidates are"} waiting for you`,
      sub: "Decide, or turn on hands-free hiring" });
  if (k.interviews_pending > 0)
    out.push({ key: "iv", href: "/hr/candidates", icon: Hourglass, tone: "bg-blue-50 text-blue-700",
      title: `${k.interviews_pending} ${k.interviews_pending === 1 ? "interview has" : "interviews have"} not been taken yet`,
      sub: "Invited candidates who have not started" });
  for (const j of d.jobs) {
    if (!j.auto_enabled && j.applicants > 0 && j.selected < j.openings)
      out.push({ key: `auto${j.id}`, href: `/hr/jobs/${j.id}`, icon: Zap, tone: "bg-maroon-50 text-maroon-700",
        title: `Automate ${j.title}`, sub: `${j.applicants} applicants, decided by hand today` });
    else if (j.status === "published" && j.applicants === 0)
      out.push({ key: `none${j.id}`, href: `/hr/jobs/${j.id}`, icon: Users, tone: "bg-stone-100 text-stone-700",
        title: `${j.title} has no applicants yet`, sub: "Check the description or share the job" });
    else if (j.status === "published" && j.selected >= j.openings)
      out.push({ key: `full${j.id}`, href: `/hr/jobs/${j.id}`, icon: CheckCircle2, tone: "bg-emerald-50 text-emerald-700",
        title: `${j.title} is fully staffed`, sub: "Consider unpublishing it" });
  }
  if (k.draft_jobs > 0)
    out.push({ key: "drafts", href: "/hr/jobs", icon: FilePenLine, tone: "bg-stone-100 text-stone-700",
      title: `${k.draft_jobs} ${k.draft_jobs === 1 ? "job is" : "jobs are"} not published yet`, sub: "Finish and publish them" });
  return out;
}

export default function DashboardPage() {
  const { data: d, error } = useInsights();
  if (error) return <p className="text-red-700">{error}</p>;
  if (!d) return <Loading />;

  const k = d.kpis;
  const filled = k.openings ? Math.round((100 * k.selected) / k.openings) : 0;
  const tasks = todos(d);

  return (
    // Fills the screen height: the bottom row grows into whatever space is left.
    <div className="flex min-h-[calc(100dvh-4rem)] flex-col gap-5 lg:min-h-[calc(100dvh-5rem)]">
      {/* Header */}
      <section className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-maroon-950 via-maroon-900 to-maroon-700 px-6 py-5 text-white shadow-lg">
        <div aria-hidden className="pointer-events-none absolute -right-16 -top-24 h-64 w-64 rounded-full bg-white/5" />
        <div className="relative flex flex-wrap items-center justify-between gap-5">
          <div className="min-w-0">
            <p className="mb-1.5 inline-flex items-center gap-2 rounded-full bg-white/10 px-2.5 py-0.5 text-xs font-medium text-maroon-100">
              <Sparkles size={12} />
              {k.jobs_automated > 0 ? `Hands-free hiring on for ${k.jobs_automated} ${k.jobs_automated === 1 ? "job" : "jobs"}` : "Hiring overview"}
            </p>
            <h1 className="font-display text-2xl font-semibold leading-tight sm:text-3xl">{greeting()}, {d.hr_name.split(" ")[0]}</h1>
            <p className="mt-1 text-sm text-maroon-100">
              {d.company ? `${d.company} · ` : ""}{k.open_jobs} live {k.open_jobs === 1 ? "job" : "jobs"} · {k.total_applicants} applicants
              {k.applicants_7d ? ` · ${k.applicants_7d} this week` : ""}
            </p>
          </div>
          <div className="flex items-center gap-8">
            <div>
              <p className="text-[11px] uppercase tracking-wider text-maroon-200">Openings filled</p>
              <p className="mt-0.5 text-4xl font-semibold leading-none">{k.selected}<span className="text-xl text-maroon-200">/{k.openings}</span></p>
              <div className="mt-2 h-1.5 w-28 overflow-hidden rounded-full bg-white/15">
                <div className="grow-x h-full rounded-full bg-emerald-400" style={{ width: `${filled}%`, animationDelay: "300ms" }} />
              </div>
            </div>
            <div className="hidden sm:block">
              <p className="text-[11px] uppercase tracking-wider text-maroon-200">Decided automatically</p>
              <p className="mt-0.5 text-4xl font-semibold leading-none">{k.automation_rate ?? 0}<span className="text-xl text-maroon-200">%</span></p>
              <p className="mt-2 text-xs text-maroon-200">{k.automated_decisions} decisions</p>
            </div>
            <Link href="/hr/jobs/new" className="hidden items-center gap-2 rounded-lg bg-white px-4 py-2.5 text-sm font-semibold text-maroon-800 shadow-sm hover:bg-maroon-50 lg:flex">
              <Plus size={16} /> Create a job
            </Link>
          </div>
        </div>
      </section>

      {/* KPI tiles */}
      <div className="stagger grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat icon={Users} label="Applicants" value={k.total_applicants} spark={d.timeline.slice(-14).map((t) => t.applications)}
              delta={{ value: k.applicants_7d - k.applicants_prev_7d, label: "vs last week" }} />
        <Stat icon={Gauge} label="Average CV match" value={k.avg_match === null ? "–" : `${k.avg_match}%`} note="Keywords + meaning" />
        <Stat icon={Mic} label="Interviews done" value={k.interviews_completed}
              note={k.avg_interview === null ? `${k.interviews_pending} waiting` : `Avg ${k.avg_interview} · ${k.interviews_pending} waiting`} />
        <Stat icon={CalendarClock} label="Time to decision" value={k.avg_days_to_decision === null ? "–" : `${k.avg_days_to_decision}d`}
              note="Application to decision" spark={d.timeline.slice(-14).map((t) => t.decisions)} />
      </div>

      {/* Charts */}
      <div className="stagger grid gap-5 lg:grid-cols-[1.3fr_1fr_1fr]">
        <Card title="Last 30 days" sub="Applications and decisions per day"
              action={<Legend items={[{ label: "Applications", color: C.s1 }, { label: "Decisions", color: C.s2 }]} />}>
          <TimelineChart data={d.timeline} height={260} />
        </Card>
        <Card title="Hiring funnel" sub="Hover a stage for conversion"
              action={<Link href="/hr/analytics" className={more}>Analytics <ArrowRight size={14} /></Link>}>
          <Funnel stages={d.funnel} />
        </Card>
        <Card title="Candidate status" sub="Current decisions"
              action={<Link href="/hr/activity" className={more}>Activity <ArrowRight size={14} /></Link>}>
          <SegmentedBar parts={[
            { label: "Selected", value: d.decisions.hired, color: C.good },
            { label: "Interview", value: d.decisions.interview, color: C.s1 },
            { label: "Shortlisted", value: d.decisions.shortlisted, color: C.s2 },
            { label: "Under review", value: d.decisions.under_review, color: C.neutral, dark: true },
            { label: "Rejected", value: d.decisions.rejected, color: C.critical },
          ]} />
          <ul className="mt-4 space-y-2.5 border-t border-line pt-3">
            {d.activity.slice(0, 3).map((a, i) => {
              const m = ACT_ICON[a.kind] ?? ACT_FALLBACK;
              const Icon = m.icon;
              return (
                <li key={i} className="flex items-center gap-2.5">
                  <span className={`grid h-7 w-7 shrink-0 place-items-center rounded-full ${m.tone}`}><Icon size={14} /></span>
                  <p className="min-w-0 flex-1 truncate text-xs text-ink">
                    {a.text}{a.auto && <Bot size={11} className="ml-1 inline text-maroon-700" aria-label="automatic" />}
                  </p>
                  <span className="shrink-0 text-[11px] text-muted">{ago(a.at)}</span>
                </li>
              );
            })}
            {d.activity.length === 0 && <li className="text-xs text-muted">No activity yet.</li>}
          </ul>
        </Card>
      </div>

      {/* Bottom row: grows to fill the rest of the screen */}
      {/* lg:basis-0 + min-h: on a desktop the row takes exactly the space left (lists clip, the page doesn't grow) */}
      <div className="stagger grid flex-1 gap-5 lg:min-h-[12.5rem] lg:basis-0 lg:grid-cols-[1.3fr_1fr_1fr] [&>section]:lg:min-h-0 [&>section]:lg:overflow-hidden">
        <Card title="Jobs pipeline" sub="Applied → interviewed → filled, per job" className="flex flex-col"
              action={<Link href="/hr/jobs" className={more}>Jobs <ArrowRight size={14} /></Link>}>
          {d.jobs.length === 0 ? (
            <Link href="/hr/jobs/new" className="m-auto inline-flex items-center gap-2 rounded-lg bg-maroon-700 px-4 py-2.5 text-sm font-semibold text-white">
              <Plus size={16} /> Create your first job
            </Link>
          ) : (
            <ul className="-mx-2 flex-1 space-y-1 overflow-hidden [mask-image:linear-gradient(to_bottom,black_82%,transparent)]">
              {d.jobs.slice(0, 5).map((j) => (
                <li key={j.id}>
                  <Link href={`/hr/jobs/${j.id}`} className="group grid grid-cols-[1fr_auto] items-center gap-x-4 gap-y-1.5 rounded-xl px-2 py-2 hover:bg-maroon-50/70">
                    <div className="flex min-w-0 items-center gap-2">
                      <span className="truncate text-sm font-medium text-ink">{j.title}</span>
                      <span className={`inline-flex shrink-0 items-center gap-0.5 rounded-full px-1.5 py-px text-[10px] font-semibold uppercase tracking-wide ${
                        j.auto_enabled ? "bg-emerald-50 text-emerald-700" : "bg-stone-100 text-stone-500"}`}>
                        <Bot size={10} />{j.auto_enabled ? "auto" : "manual"}
                      </span>
                    </div>
                    <span className="flex items-center gap-1.5 text-xs tabular-nums text-muted">
                      <b className="text-ink">{j.applicants}</b>applied<ChevronRight size={12} />
                      <b className="text-ink">{j.interviews_done}</b>interviewed<ChevronRight size={12} />
                      <b className="text-ink">{j.selected}/{j.openings}</b>filled
                    </span>
                    <div className="col-span-2 flex items-center gap-2">
                      <div className="flex-1"><Meter value={j.openings ? Math.min(100, (100 * j.selected) / j.openings) : 0} color={C.good} /></div>
                      <span className="w-20 text-right text-[11px] text-muted">{j.avg_match === null ? "no CVs" : `avg match ${j.avg_match}%`}</span>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card title="Top candidates" sub="Best CV match plus interview" className="flex flex-col"
              action={<Link href="/hr/analytics" className={more}>All <ArrowRight size={14} /></Link>}>
          {d.top_candidates.length === 0 ? <p className="text-sm text-muted">Candidates appear once their CVs are analysed.</p> : (
            <ol className="-mx-2 flex-1 space-y-1 overflow-hidden [mask-image:linear-gradient(to_bottom,black_82%,transparent)]">
              {d.top_candidates.slice(0, 5).map((t, i) => (
                <li key={t.application_id}>
                  <Link href={`/hr/applications/${t.application_id}`} className="flex items-center gap-3 rounded-xl px-2 py-1.5 hover:bg-maroon-50/70">
                    <span className={`grid h-8 w-8 shrink-0 place-items-center rounded-full text-xs font-semibold ${
                      i === 0 ? "bg-gradient-to-br from-maroon-600 to-maroon-800 text-white shadow" : "bg-maroon-50 text-maroon-800"}`}>{i + 1}</span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-ink">{t.name}</p>
                      <p className="truncate text-xs text-muted">{t.job_title}</p>
                    </div>
                    {t.decision !== "under_review" ? <DecisionBadge decision={t.decision} /> : <ScorePill v={t.combined} />}
                  </Link>
                </li>
              ))}
            </ol>
          )}
        </Card>

        <Card title="Needs your attention" sub="What to do next" className="flex flex-col">
          {tasks.length === 0 ? (
            <div className="m-auto flex flex-col items-center gap-2 py-4 text-center">
              <span className="grid h-12 w-12 place-items-center rounded-full bg-emerald-50 text-emerald-700"><CheckCircle2 size={24} /></span>
              <p className="text-sm font-medium text-ink">All caught up</p>
              <p className="text-xs text-muted">Nothing needs you right now.</p>
            </div>
          ) : (
            <ul className="-mx-2 flex-1 space-y-1 overflow-hidden [mask-image:linear-gradient(to_bottom,black_82%,transparent)]">
              {tasks.slice(0, 5).map((t) => {
                const Icon = t.icon;
                return (
                  <li key={t.key}>
                    <Link href={t.href} className="flex items-center gap-3 rounded-xl px-2 py-1.5 hover:bg-maroon-50/70">
                      <span className={`grid h-8 w-8 shrink-0 place-items-center rounded-lg ${t.tone}`}><Icon size={15} /></span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium text-ink">{t.title}</p>
                        <p className="truncate text-xs text-muted">{t.sub}</p>
                      </div>
                      <ChevronRight size={15} className="shrink-0 text-muted" />
                    </Link>
                  </li>
                );
              })}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}
