"use client";

import Link from "next/link";
import { Bot } from "lucide-react";
import { C, Histogram, Meter, Ring } from "@/components/dashboard/charts";
import { Card, Loading, PageTitle, ScorePill, useInsights } from "@/components/dashboard/shared";
import DecisionBadge from "@/components/DecisionBadge";
import StatusBadge from "@/components/StatusBadge";

export default function AnalyticsPage() {
  const { data: d, error } = useInsights();
  if (error) return <p className="text-red-700">{error}</p>;
  if (!d) return <Loading />;
  const k = d.kpis;
  const reach = k.total_applicants ? Math.round((100 * (d.funnel[2]?.count ?? 0)) / k.total_applicants) : null;
  const hire = d.funnel[3]?.count ? Math.round((100 * k.selected) / d.funnel[3].count) : null;
  const auto = k.automation_rate;

  return (
    <div className="space-y-5">
      <PageTitle title="Analytics" sub="Score quality, conversion, jobs and skills across all your hiring" />

      {/* Distributions + conversion */}
      <div className="stagger grid gap-5 lg:grid-cols-[1fr_1fr_0.8fr]">
        <Card title="CV match distribution" sub="Every analysed CV, by match score">
          <Histogram buckets={d.match_histogram} label="CV match score distribution" />
        </Card>
        <Card title="Interview scores" sub="Evaluated interviews, by score">
          <Histogram buckets={d.interview_histogram} color={C.s2} label="Interview score distribution" unit="" />
        </Card>
        <Card title="Conversion" sub="How candidates move through">
          <div className="grid grid-cols-3 gap-2 pt-1 text-center">
            {([[reach, "reach interview", C.s1], [hire, "interview → hire", C.good], [auto, "decided automatically", C.s2]] as const).map(([v, l, c]) => (
              <div key={l} className="flex flex-col items-center">
                <Ring value={v} label={l} color={c} size={76} />
                <p className="mt-1.5 text-[11px] leading-tight text-muted">{l}</p>
              </div>
            ))}
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3 text-center">
            <div className="rounded-xl bg-emerald-50 p-2.5"><p className="text-xl font-semibold text-ink">{k.selected}</p><p className="text-xs text-muted">selected</p></div>
            <div className="rounded-xl bg-red-50 p-2.5"><p className="text-xl font-semibold text-ink">{k.rejected}</p><p className="text-xs text-muted">rejected</p></div>
          </div>
        </Card>
      </div>

      {/* Jobs table */}
      <Card title="Jobs at a glance" sub="Applicants, match quality, openings and automation per job"
            action={<Link href="/hr/jobs" className="text-sm font-medium text-maroon-700 hover:underline">All jobs</Link>}>
        {d.jobs.length === 0 ? <p className="py-6 text-center text-sm text-muted">No jobs yet.</p> : (
          <div className="-mx-5 overflow-x-auto">
            <table className="w-full min-w-[760px] text-sm">
              <thead>
                <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-muted">
                  <th className="px-5 py-2 font-medium">Job</th>
                  <th className="px-3 py-2 text-right font-medium">Applicants</th>
                  <th className="px-3 py-2 font-medium">Avg match</th>
                  <th className="px-3 py-2 font-medium">Best candidate</th>
                  <th className="px-3 py-2 font-medium">Openings</th>
                  <th className="px-5 py-2 font-medium">Automation</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {d.jobs.map((j) => (
                  <tr key={j.id} className="hover:bg-maroon-50/50">
                    <td className="px-5 py-2.5">
                      <Link href={`/hr/jobs/${j.id}`} className="font-medium text-ink hover:text-maroon-700">{j.title}</Link>
                      <div className="mt-1 flex items-center gap-2"><StatusBadge status={j.status} />{j.role_family && <span className="text-xs text-muted">{j.role_family}</span>}</div>
                    </td>
                    <td className="px-3 py-2.5 text-right font-semibold tabular-nums">{j.applicants}</td>
                    <td className="px-3 py-2.5">
                      {j.avg_match === null ? <span className="text-muted">–</span> : (
                        <div className="flex w-32 items-center gap-2"><Meter value={j.avg_match} /><span className="w-9 text-right text-xs tabular-nums">{j.avg_match}%</span></div>
                      )}
                    </td>
                    <td className="px-3 py-2.5">
                      {j.best_candidate ? <span className="flex items-center gap-2"><span className="max-w-[9rem] truncate">{j.best_candidate}</span><ScorePill v={j.best_match} /></span> : <span className="text-muted">–</span>}
                    </td>
                    <td className="px-3 py-2.5 tabular-nums">
                      <span className="font-semibold">{j.selected}</span><span className="text-muted">/{j.openings}</span>
                      <span className="ml-2 text-xs text-muted">{j.interviews_done} interviewed</span>
                    </td>
                    <td className="px-5 py-2.5">
                      <Link href={`/hr/jobs/${j.id}`} className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset ${
                        j.auto_enabled ? "bg-emerald-50 text-emerald-800 ring-emerald-200" : "bg-stone-100 text-stone-600 ring-stone-200"}`}>
                        <Bot size={13} />{j.auto_enabled ? `CV ≥${j.cv_threshold}% · interview ≥${j.interview_threshold}` : "Manual"}
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Candidates + skills */}
      <div className="stagger grid gap-5 lg:grid-cols-2">
        <Card title="Top candidates" sub="CV match, plus interview score when there is one">
          {d.top_candidates.length === 0 ? <p className="text-sm text-muted">Candidates appear once their CVs are analysed.</p> : (
            <ol className="grid gap-2 sm:grid-cols-2">
              {d.top_candidates.map((t, i) => (
                <li key={t.application_id}>
                  <Link href={`/hr/applications/${t.application_id}`} className="flex items-center gap-3 rounded-xl border border-line p-2.5 hover:bg-maroon-50/60">
                    <span className={`grid h-8 w-8 shrink-0 place-items-center rounded-full text-sm font-semibold ${i === 0 ? "bg-maroon-700 text-white" : "bg-maroon-50 text-maroon-800"}`}>{i + 1}</span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-ink">{t.name}</p>
                      <p className="truncate text-xs text-muted">CV {t.match}%{t.interview !== null ? ` · interview ${t.interview}` : ""}</p>
                    </div>
                    {t.decision !== "under_review" ? <DecisionBadge decision={t.decision} /> : <ScorePill v={t.combined} />}
                  </Link>
                </li>
              ))}
            </ol>
          )}
        </Card>

        <Card title="Skills: demand vs supply" sub="Share of applicants who show each required skill. Red = scarce.">
          {d.skills.length === 0 ? <p className="text-sm text-muted">Add required skills to your jobs.</p> : (
            <ul className="grid gap-x-6 gap-y-3 sm:grid-cols-2">
              {d.skills.map((s) => (
                <li key={s.skill}>
                  <div className="mb-1 flex items-baseline justify-between gap-2 text-sm">
                    <span className="truncate font-medium text-ink">{s.skill}</span>
                    <span className="shrink-0 text-xs text-muted">{s.coverage === null ? "–" : `${s.coverage}%`} · {s.jobs} {s.jobs === 1 ? "job" : "jobs"}</span>
                  </div>
                  <Meter value={s.coverage} color={s.coverage !== null && s.coverage < 30 ? C.critical : C.s1} />
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}
