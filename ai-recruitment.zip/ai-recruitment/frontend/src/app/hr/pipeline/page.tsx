"use client";

import { Suspense, useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Bot, GripVertical, Hand, Mic, Trophy, Undo2, X } from "lucide-react";
import { api, errorMessage } from "@/lib/api";
import { C } from "@/components/dashboard/charts";
import { Loading, PageTitle, ScorePill, ago } from "@/components/dashboard/shared";

type Stage = "under_review" | "shortlisted" | "interview" | "hired" | "rejected";

interface PCard {
  application_id: number; name: string; job_id: number; job_title: string; stage: Stage; rank: number | null;
  match: number | null; interview_score: number | null; interview_status: string | null;
  decision_source: string | null; since: string; analysed: boolean; skills: string[];
}
interface PJob { id: number; title: string; status: string; openings: number; selected: number; auto_enabled: boolean }
interface Board { jobs: PJob[]; job_id: number | null; stages: { key: Stage; label: string }[]; cards: PCard[]; email_enabled: boolean }
interface MoveResult {
  card: PCard; previous: Stage; warning: string | null; created_interview: boolean; cancelled_interview: boolean;
  emailed: boolean; job: PJob;
}

const STAGE_STYLE: Record<Stage, { dot: string; ring: string; wash: string }> = {
  under_review: { dot: C.neutral, ring: "ring-stone-300", wash: "bg-stone-50" },
  shortlisted: { dot: C.s2, ring: "ring-blue-300", wash: "bg-blue-50/60" },
  interview: { dot: C.s1, ring: "ring-maroon-300", wash: "bg-maroon-50/70" },
  hired: { dot: C.good, ring: "ring-emerald-300", wash: "bg-emerald-50/70" },
  rejected: { dot: C.critical, ring: "ring-red-300", wash: "bg-red-50/60" },
};

interface Pending { card: PCard; to: Stage; note: string; cancel: boolean }

function BoardInner() {
  const params = useSearchParams();
  const initialJob = params.get("job");
  const [jobId, setJobId] = useState<number | null>(initialJob ? Number(initialJob) : null);
  const [board, setBoard] = useState<Board | null>(null);
  const [error, setError] = useState("");
  const [dragId, setDragId] = useState<number | null>(null);
  const [over, setOver] = useState<Stage | null>(null);
  const [pending, setPending] = useState<Pending | null>(null);
  const [toast, setToast] = useState<{ text: string; tone: "ok" | "warn" | "err"; undo?: () => void } | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const load = useCallback((id: number | null) => {
    api.get<Board>("/api/hr/pipeline", { params: id ? { job_id: id } : {} })
      .then((r) => setBoard(r.data)).catch((e) => setError(errorMessage(e, "Could not load the pipeline")));
  }, []);
  useEffect(() => { load(jobId); }, [jobId, load]);

  function showToast(t: NonNullable<typeof toast>) {
    if (toastTimer.current) clearTimeout(toastTimer.current);
    setToast(t);
    toastTimer.current = setTimeout(() => setToast(null), t.undo ? 7000 : 4500);
  }

  const columns = useMemo(() => {
    const by: Record<Stage, PCard[]> = { under_review: [], shortlisted: [], interview: [], hired: [], rejected: [] };
    for (const c of board?.cards ?? []) by[c.stage]?.push(c);
    for (const k of Object.keys(by) as Stage[]) by[k].sort((a, b) => (a.rank ?? 1e9) - (b.rank ?? 1e9) || (b.match ?? -1) - (a.match ?? -1));
    return by;
  }, [board]);

  const job = board?.jobs.find((j) => j.id === jobId) ?? null;
  const label = (s: Stage) => board?.stages.find((x) => x.key === s)?.label ?? s;

  function patchCard(id: number, upd: Partial<PCard>) {
    setBoard((b) => b && { ...b, cards: b.cards.map((c) => (c.application_id === id ? { ...c, ...upd } : c)) });
  }

  async function commit(card: PCard, to: Stage, note: string | null, cancel: boolean, isUndo = false) {
    const from = card.stage;
    patchCard(card.application_id, { stage: to, decision_source: to === "under_review" ? null : "hr", since: new Date().toISOString() });
    try {
      const r = await api.put<MoveResult>(`/api/hr/applications/${card.application_id}/stage`, { stage: to, note, cancel_interview: cancel });
      const d = r.data;
      patchCard(card.application_id, {
        stage: d.card.stage, decision_source: d.card.decision_source, since: d.card.since,
        interview_status: d.card.interview_status, interview_score: d.card.interview_score,
      });
      setBoard((b) => b && { ...b, jobs: b.jobs.map((j) => (j.id === d.job.id ? d.job : j)) });
      if (isUndo) { showToast({ text: `Undone: ${card.name} is back in ${label(to)}.`, tone: "ok" }); return; }
      const extra = [d.created_interview && "interview invitation sent", d.cancelled_interview && "invitation cancelled",
                     d.emailed && "candidate emailed"].filter(Boolean).join(", ");
      showToast({
        text: d.warning ?? `${card.name} moved to ${label(to)}${extra ? ` · ${extra}` : ""}.`,
        tone: d.warning ? "warn" : "ok",
        undo: () => commit({ ...card, stage: to, interview_status: d.card.interview_status }, from, null, d.created_interview, true),
      });
    } catch (e) {
      patchCard(card.application_id, { stage: from });
      showToast({ text: errorMessage(e, "Could not move the candidate"), tone: "err" });
    }
  }

  /** Some moves ask first: rejecting, and leaving Interview while the invite is untaken. */
  function requestMove(card: PCard, to: Stage) {
    if (card.stage === to) return;
    const leavingInvite = card.stage === "interview" && card.interview_status === "invited" && to !== "interview";
    if (to === "rejected" || leavingInvite) setPending({ card, to, note: "", cancel: leavingInvite });
    else commit(card, to, null, false);
  }

  function onDrop(to: Stage) {
    setOver(null);
    const card = board?.cards.find((c) => c.application_id === dragId);
    setDragId(null);
    if (card) requestMove(card, to);
  }

  if (error) return <p className="text-red-700">{error}</p>;
  if (!board) return <Loading />;

  return (
    <div className="space-y-5">
      <PageTitle
        title="Pipeline"
        sub="Drag candidates between stages, or use Move to on a card. Your moves count as your decision: automation never overrides them."
        action={job && (
          <div className="flex items-center gap-3 rounded-xl border border-line bg-white px-4 py-2.5 text-sm">
            <Trophy size={16} className="text-maroon-700" />
            <span><b>{job.selected}</b> of <b>{job.openings}</b> filled</span>
            <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium ${job.auto_enabled ? "bg-emerald-50 text-emerald-800" : "bg-stone-100 text-stone-600"}`}>
              <Bot size={11} />{job.auto_enabled ? "Automation on" : "Manual"}
            </span>
          </div>
        )}
      />

      {/* Job picker */}
      <div className="flex flex-wrap gap-1.5" role="tablist" aria-label="Job">
        {[{ id: null as number | null, title: "All jobs" }, ...board.jobs].map((j) => (
          <button key={j.id ?? "all"} role="tab" aria-selected={jobId === j.id} onClick={() => setJobId(j.id)}
                  className={`rounded-full px-3.5 py-1.5 text-sm font-medium ${jobId === j.id ? "bg-maroon-700 text-white shadow" : "bg-white text-maroon-800 ring-1 ring-inset ring-line hover:bg-maroon-50"}`}>
            {j.title}
          </button>
        ))}
      </div>

      {/* Board */}
      <div className="-mx-1 overflow-x-auto pb-2">
        <div className="stagger grid min-w-[1050px] grid-cols-5 gap-4 px-1">
          {board.stages.map(({ key, label: title }) => {
            const s = STAGE_STYLE[key];
            const cards = columns[key];
            const isOver = over === key && dragId !== null;
            return (
              <section key={key} aria-label={title}
                       onDragOver={(e) => { e.preventDefault(); if (over !== key) setOver(key); }}
                       onDragLeave={(e) => { if (!e.currentTarget.contains(e.relatedTarget as Node)) setOver(null); }}
                       onDrop={(e) => { e.preventDefault(); onDrop(key); }}
                       className={`flex min-h-[60vh] flex-col rounded-2xl border p-3 transition-all duration-200 ${
                         isOver ? `scale-[1.015] border-transparent ring-2 ${s.ring} ${s.wash} shadow-xl` : "border-line bg-white/70"}`}
                       style={isOver ? { transform: "perspective(900px) translateZ(14px) scale(1.015)" } : undefined}>
                <header className="mb-3 flex items-center gap-2 px-1">
                  <span className="h-2.5 w-2.5 rounded-full" style={{ background: s.dot }} />
                  <h2 className="text-sm font-semibold text-ink">{title}</h2>
                  <span className="ml-auto rounded-full bg-canvas px-2 py-0.5 text-xs font-semibold tabular-nums text-muted">
                    {key === "hired" && job ? `${cards.length}/${job.openings}` : cards.length}
                  </span>
                </header>
                <ul className="flex flex-1 flex-col gap-2.5">
                  {cards.map((c) => (
                    <li key={c.application_id} draggable
                        onDragStart={(e) => { setDragId(c.application_id); e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData("text/plain", String(c.application_id)); }}
                        onDragEnd={() => { setDragId(null); setOver(null); }}
                        className={`group cursor-grab rounded-xl border border-line bg-white p-3 shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md active:cursor-grabbing ${
                          dragId === c.application_id ? "rotate-2 scale-95 opacity-40" : ""}`}
                        style={{ transformStyle: "preserve-3d" }}>
                      <div className="flex items-start gap-2">
                        <GripVertical size={15} className="mt-0.5 shrink-0 text-stone-300 group-hover:text-stone-500" aria-hidden />
                        <div className="min-w-0 flex-1">
                          <Link href={`/hr/applications/${c.application_id}`} className="block truncate text-sm font-semibold text-ink hover:text-maroon-700">
                            {c.rank && <span className="mr-1 text-xs font-medium text-muted">#{c.rank}</span>}{c.name}
                          </Link>
                          {jobId === null && <p className="truncate text-xs text-muted">{c.job_title}</p>}
                        </div>
                        {c.match !== null ? <ScorePill v={c.match} /> : <span className="text-[11px] text-muted">{c.analysed ? "–" : "reading CV"}</span>}
                      </div>
                      <div className="mt-2 flex flex-wrap items-center gap-1.5 pl-6 text-[11px]">
                        {c.interview_score !== null && (
                          <span className="inline-flex items-center gap-1 rounded-md bg-blue-50 px-1.5 py-0.5 font-medium text-blue-800"><Mic size={11} />{c.interview_score}</span>
                        )}
                        {c.interview_status && c.interview_score === null && (
                          <span className="rounded-md bg-stone-100 px-1.5 py-0.5 text-stone-600">interview {c.interview_status.replace("_", " ")}</span>
                        )}
                        {c.decision_source && (
                          <span className={`inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 font-medium ${c.decision_source === "auto" ? "bg-maroon-50 text-maroon-700" : "bg-violet-50 text-violet-700"}`}>
                            {c.decision_source === "auto" ? <Bot size={11} /> : <Hand size={11} />}{c.decision_source === "auto" ? "auto" : "manual"}
                          </span>
                        )}
                        <span className="ml-auto text-muted">{ago(c.since)}</span>
                      </div>
                      <label className="mt-2 flex items-center gap-1.5 whitespace-nowrap pl-6 text-[11px] text-muted">
                        Move to
                        <select value={c.stage} onChange={(e) => requestMove(c, e.target.value as Stage)}
                                className="flex-1 rounded-md border border-line bg-white px-1.5 py-0.5 text-[11px] text-ink">
                          {board.stages.map((st) => <option key={st.key} value={st.key}>{st.label}</option>)}
                        </select>
                      </label>
                    </li>
                  ))}
                  {cards.length === 0 && (
                    <li className={`grid flex-1 place-items-center rounded-xl border-2 border-dashed text-xs ${isOver ? "border-current text-ink" : "border-line text-muted"}`}>
                      {isOver ? "Drop here" : "No candidates"}
                    </li>
                  )}
                </ul>
              </section>
            );
          })}
        </div>
      </div>

      {/* Confirm dialog */}
      {pending && (
        <div className="fixed inset-0 z-40 grid place-items-center bg-maroon-950/40 p-4" role="dialog" aria-modal aria-labelledby="move-title"
             onClick={() => setPending(null)}>
          <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}
               style={{ animation: "page-swing 360ms cubic-bezier(0.16,0.84,0.24,1) both" }}>
            <div className="mb-3 flex items-start justify-between">
              <h2 id="move-title" className="font-display text-xl font-semibold text-maroon-900">
                Move {pending.card.name} to {label(pending.to)}?
              </h2>
              <button onClick={() => setPending(null)} aria-label="Close" className="rounded-lg p-1 text-muted hover:bg-canvas"><X size={18} /></button>
            </div>
            {pending.card.stage === "interview" && pending.card.interview_status === "invited" && (
              <label className="mb-3 flex items-start gap-2 text-sm">
                <input type="checkbox" checked={pending.cancel} onChange={(e) => setPending({ ...pending, cancel: e.target.checked })}
                       className="mt-0.5 h-4 w-4 accent-maroon-700" />
                Cancel the interview invitation (it has not been started yet)
              </label>
            )}
            {pending.to === "rejected" && (
              <label className="block text-sm">
                <span className="mb-1 block text-muted">Note to the candidate (optional)</span>
                <textarea value={pending.note} maxLength={500} rows={3} onChange={(e) => setPending({ ...pending, note: e.target.value })}
                          placeholder="Leave empty for a polite default message"
                          className="w-full rounded-lg border border-line p-2.5 text-sm outline-none focus:border-maroon-600 focus:ring-2 focus:ring-maroon-600/20" />
              </label>
            )}
            <div className="mt-4 flex justify-end gap-2">
              <button onClick={() => setPending(null)} className="rounded-lg px-4 py-2 text-sm font-medium text-muted hover:bg-canvas">Cancel</button>
              <button onClick={() => { const p = pending; setPending(null); commit(p.card, p.to, p.note.trim() || null, p.cancel); }}
                      className={`rounded-lg px-4 py-2 text-sm font-semibold text-white shadow-sm ${pending.to === "rejected" ? "bg-red-700 hover:bg-red-800" : "bg-maroon-700 hover:bg-maroon-800"}`}>
                Move to {label(pending.to)}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast with undo */}
      {toast && (
        <div role="status" className={`fixed bottom-6 left-1/2 z-50 flex -translate-x-1/2 items-center gap-3 rounded-xl px-4 py-3 text-sm text-white shadow-2xl ${
          toast.tone === "err" ? "bg-red-700" : toast.tone === "warn" ? "bg-amber-700" : "bg-maroon-900"}`}
             style={{ animation: "page-swing 320ms cubic-bezier(0.16,0.84,0.24,1) both" }}>
          <span>{toast.text}</span>
          {toast.undo && (
            <button onClick={() => { const u = toast.undo; setToast(null); u?.(); }}
                    className="inline-flex items-center gap-1 rounded-lg bg-white/15 px-2.5 py-1 font-semibold hover:bg-white/25">
              <Undo2 size={14} /> Undo
            </button>
          )}
        </div>
      )}
    </div>
  );
}

export default function PipelinePage() {
  return (
    <Suspense fallback={<Loading />}>
      <BoardInner />
    </Suspense>
  );
}
