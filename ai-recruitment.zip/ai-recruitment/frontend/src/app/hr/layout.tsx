"use client";

import { Suspense, useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { LogOut } from "lucide-react";
import BrandMark from "@/components/BrandMark";
import HRNav from "@/components/HRNav";
import { useAuth } from "@/store/auth";

export default function HRLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const { user, loadUser, logout } = useAuth();
  const [ready, setReady] = useState(false);

  // Route guard: must be logged in AND have the HR role.
  // (The real enforcement is on the backend; this is just for a clean UX.)
  useEffect(() => {
    loadUser().then((u) => {
      if (!u) router.replace("/login");
      else if (u.role !== "hr") router.replace("/candidate");
      else setReady(true);
    });
  }, [loadUser, router]);

  function signOut() {
    logout();
    router.replace("/login");
  }

  if (!ready) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-canvas text-muted">
        Loading...
      </div>
    );
  }

  const initials = (user?.full_name ?? "?")
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  return (
    <div className="min-h-screen bg-canvas md:flex">
      <aside className="flex flex-col gap-4 bg-maroon-900 p-4 text-white md:sticky md:top-0 md:h-screen md:w-64 md:shrink-0 md:gap-8 md:p-6">
        <div className="flex items-center justify-between">
          <BrandMark />
          <button
            onClick={signOut}
            aria-label="Sign out"
            className="rounded-lg p-2 text-maroon-100 hover:bg-white/10 md:hidden"
          >
            <LogOut size={18} />
          </button>
        </div>

        <Suspense fallback={<div className="md:flex-1" />}>
          <HRNav />
        </Suspense>

        <div className="mt-auto hidden border-t border-white/10 pt-5 md:block">
          <div className="mb-4 flex items-center gap-3">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-white text-sm font-semibold text-maroon-800">
              {initials}
            </span>
            <div className="min-w-0">
              <p className="truncate text-sm font-medium">{user?.full_name}</p>
              <p className="truncate text-xs text-maroon-200">{user?.company ?? "HR account"}</p>
            </div>
          </div>
          <button
            onClick={signOut}
            className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-maroon-100 hover:bg-white/10 hover:text-white"
          >
            <LogOut size={16} /> Sign out
          </button>
        </div>
      </aside>

      <main className="min-w-0 flex-1 p-5 sm:p-8 lg:p-10">
        {/* key = path: every page plays the entrance animation when you navigate to it */}
        {/* The pipeline board uses the full width: five columns need the room. */}
        <div key={pathname} className={`page-in mx-auto ${pathname.startsWith("/hr/pipeline") ? "max-w-[1700px]" : "max-w-6xl"}`}>{children}</div>
      </main>
    </div>
  );
}
