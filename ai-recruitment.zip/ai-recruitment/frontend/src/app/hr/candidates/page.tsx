"use client";

import { Suspense, useEffect, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Users } from "lucide-react";
import { api, errorMessage } from "@/lib/api";
import AnalysisBadge from "@/components/AnalysisBadge";
import DecisionBadge from "@/components/DecisionBadge";
import PageHeader from "@/components/PageHeader";
import { DECISIONS, type ApplicationListItem } from "@/types/application";
import type { JobListItem } from "@/types/job";

function CandidatesList() {
  const params = useSearchParams();
  const [jobId, setJobId] = useState(params.get("job") ?? "");
  const [status, setStatus] = useState("");
  const [jobs, setJobs] = useState<JobListItem[]>([]);
  const [items, setItems] = useState<ApplicationListItem[] | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .get<JobListItem[]>("/api/hr/jobs")
      .then((r) => setJobs(r.data))
      .catch(() => {});
  }, []);

  useEffect(() => {
    api
      .get<ApplicationListItem[]>("/api/hr/applications", {
        params: jobId ? { job_id: jobId } : {},
      })
      .then((r) => {
        setItems(r.data);
        setError("");
      })
      .catch((err) => setError(errorMessage(err, "Could not load candidates")));
  }, [jobId]);

  // With a job selected, show the best match first.
  const filtered = items ? items.filter((a) => !status || a.decision === status) : [];
  const sorted = jobId
    ? [...filtered].sort((a, b) => (b.match_percent ?? -1) - (a.match_percent ?? -1))
    : filtered;

  return (
    <div>
      <PageHeader
        title="Candidates"
        subtitle="Everyone who applied for your jobs, with their CV read and organised automatically."
      />

      <div className="mb-5">
        <label htmlFor="job" className="mr-3 text-sm font-medium">
          Job
        </label>
        <select
          id="job"
          value={jobId}
          onChange={(e) => {
            setItems(null);
            setJobId(e.target.value);
          }}
          className="rounded-lg border border-line bg-white px-3 py-2 text-sm outline-none focus:border-maroon-600 focus:ring-2 focus:ring-maroon-600/20"
        >
          <option value="">All jobs</option>
          {jobs.map((j) => (
            <option key={j.id} value={j.id}>
              {j.title}
            </option>
          ))}
        </select>
        <label htmlFor="status" className="ml-6 mr-3 text-sm font-medium">
          Status
        </label>
        <select
          id="status"
          value={status}
          onChange={(e) => setStatus(e.target.value)}
          className="rounded-lg border border-line bg-white px-3 py-2 text-sm outline-none focus:border-maroon-600 focus:ring-2 focus:ring-maroon-600/20"
        >
          <option value="">All</option>
          {DECISIONS.map((d) => (
            <option key={d.value} value={d.value}>
              {d.hr}
            </option>
          ))}
        </select>
        {jobId && (
          <Link
            href={`/hr/jobs/${jobId}/ranking`}
            className="ml-4 text-sm font-medium text-maroon-700 hover:underline"
          >
            See the full ranking
          </Link>
        )}
      </div>

      {error && <p className="text-red-700">{error}</p>}
      {!error && items === null && <p className="text-muted">Loading...</p>}

      {items && items.length === 0 && (
        <div className="rounded-2xl border border-line bg-white px-6 py-16 text-center">
          <span className="mx-auto mb-4 grid h-12 w-12 place-items-center rounded-xl bg-maroon-50 text-maroon-700">
            <Users size={22} />
          </span>
          <p className="font-medium">No applicants yet</p>
          <p className="mx-auto mt-1 max-w-sm text-sm text-muted">
            Publish a job and candidates will be able to apply. Their applications will show up here.
          </p>
        </div>
      )}

      {items && items.length > 0 && sorted.length === 0 && (
        <p className="rounded-2xl border border-line bg-white px-6 py-10 text-center text-muted">
          No candidates with this status.
        </p>
      )}

      {items && sorted.length > 0 && (
        <ul className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-white">
          {sorted.map((a) => (
            <li key={a.id}>
              <Link
                href={`/hr/applications/${a.id}`}
                className="flex flex-wrap items-start justify-between gap-4 px-6 py-5 hover:bg-maroon-50/60"
              >
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="text-lg font-medium">{a.candidate_name}</p>
                    {a.decision !== "under_review" && <DecisionBadge decision={a.decision} />}
                  </div>
                  <p className="text-sm text-muted">
                    {a.candidate_email}. Applied for {a.job_title}
                    {a.total_experience_years !== null ? `, about ${a.total_experience_years} years of experience` : ""}
                  </p>
                  {a.skills.length > 0 && (
                    <ul className="mt-2 flex flex-wrap gap-1.5">
                      {a.skills.slice(0, 6).map((s) => (
                        <li
                          key={s}
                          className="rounded-md bg-maroon-50 px-2 py-0.5 text-xs text-maroon-800 ring-1 ring-inset ring-maroon-200"
                        >
                          {s}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
                <div className="flex flex-col items-end gap-2">
                  {a.match_percent !== null ? (
                    <span className="text-right">
                      <span className="font-display text-2xl font-semibold text-maroon-900">{a.match_percent}%</span>
                      <span className="block text-xs text-muted">{a.match_label}</span>
                    </span>
                  ) : (
                    <AnalysisBadge status={a.analysis_status} />
                  )}
                  <span className="text-xs text-muted">{new Date(a.created_at).toLocaleDateString()}</span>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default function CandidatesPage() {
  return (
    <Suspense fallback={<p className="text-muted">Loading...</p>}>
      <CandidatesList />
    </Suspense>
  );
}
