"use client";

import { useCallback, useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { Check, Pencil, Sparkles } from "lucide-react";
import { api, errorMessage } from "@/lib/api";
import AutomationPanel from "@/components/AutomationPanel";
import JobMeta from "@/components/JobMeta";
import Markdown from "@/components/Markdown";
import StatusBadge from "@/components/StatusBadge";
import {
  EXPERIENCE_LEVELS,
  labelOf,
  type Job,
} from "@/types/job";

function Stepper({ job }: { job: Job }) {
  const steps = [
    { label: "Requirements", done: true },
    { label: "Generate description", done: !!job.jd_text },
    { label: "Edit and approve", done: job.status !== "draft" },
    { label: "Publish", done: job.status === "published" },
  ];
  const current = steps.findIndex((s) => !s.done);
  return (
    <ol className="mb-8 grid grid-cols-2 gap-4 rounded-2xl border border-line bg-white p-5 sm:grid-cols-4">
      {steps.map((s, i) => (
        <li key={s.label} className="flex items-center gap-3">
          <span
            className={`grid h-8 w-8 shrink-0 place-items-center rounded-full text-sm font-semibold ${
              s.done
                ? "bg-maroon-700 text-white"
                : i === current
                  ? "bg-white text-maroon-700 ring-2 ring-maroon-700"
                  : "bg-stone-100 text-stone-400"
            }`}
          >
            {s.done ? <Check size={16} /> : i + 1}
          </span>
          <span
            className={`text-sm ${
              s.done || i === current ? "font-medium text-ink" : "text-muted"
            }`}
          >
            {s.label}
          </span>
        </li>
      ))}
    </ol>
  );
}

function sourceLabel(job: Job): string | null {
  if (!job.jd_text) return null;
  if (job.jd_source === "ai")
    return `AI generated${job.jd_model ? ` (${job.jd_model})` : ""}${job.jd_edited ? ", edited" : ""}`;
  if (job.jd_source === "template")
    return `Built-in template, no AI key configured${job.jd_edited ? ", edited" : ""}`;
  return "Written manually";
}

const btn = "rounded-lg px-4 py-2.5 text-sm font-semibold transition disabled:opacity-50";
const primary = `${btn} bg-maroon-700 text-white shadow-sm hover:bg-maroon-800`;
const outline = `${btn} border border-maroon-700 text-maroon-700 hover:bg-maroon-50`;

export default function JobWorkspacePage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();

  const [job, setJob] = useState<Job | null>(null);
  const [draft, setDraft] = useState("");
  const [tab, setTab] = useState<"edit" | "preview">("edit");
  const [instructions, setInstructions] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const apply = useCallback((j: Job) => {
    setJob(j);
    setDraft(j.jd_text ?? "");
  }, []);

  useEffect(() => {
    api
      .get<Job>(`/api/hr/jobs/${id}`)
      .then((r) => apply(r.data))
      .catch((err) => setError(errorMessage(err, "Could not load the job")));
  }, [id, apply]);

  async function run(name: string, fn: () => Promise<Job | null>, okMsg: string) {
    setBusy(name);
    setError("");
    setNotice("");
    try {
      const updated = await fn();
      if (updated) apply(updated);
      setNotice(okMsg);
    } catch (err) {
      setError(errorMessage(err, "Something went wrong"));
    } finally {
      setBusy(null);
    }
  }

  if (error && !job) return <p className="text-red-700">{error}</p>;
  if (!job) return <p className="text-muted">Loading...</p>;

  const published = job.status === "published";
  const dirty = draft.trim() !== (job.jd_text ?? "").trim();
  const src = sourceLabel(job);

  const generate = () => {
    if (job.jd_text && !window.confirm("Replace the current job description with a new one?"))
      return;
    run(
      "generate",
      async () =>
        (
          await api.post<Job>(`/api/hr/jobs/${id}/generate-jd`, {
            instructions: instructions.trim() || null,
          })
        ).data,
      "Job description generated. Review and edit it, then approve."
    );
  };

  const save = () =>
    run(
      "save",
      async () => (await api.put<Job>(`/api/hr/jobs/${id}/jd`, { jd_text: draft })).data,
      "Changes saved."
    );

  const approve = () => {
    if (dirty) {
      setError("You have unsaved changes. Save them before approving.");
      return;
    }
    run(
      "approve",
      async () => (await api.post<Job>(`/api/hr/jobs/${id}/approve`)).data,
      "Description approved. You can publish the job now."
    );
  };

  const publish = () =>
    run(
      "publish",
      async () => (await api.post<Job>(`/api/hr/jobs/${id}/publish`)).data,
      "Job published. Candidates can now see it."
    );

  const unpublish = () => {
    if (!window.confirm("Unpublish this job? Candidates will no longer see it.")) return;
    run(
      "unpublish",
      async () => (await api.post<Job>(`/api/hr/jobs/${id}/unpublish`)).data,
      "Job unpublished."
    );
  };

  const remove = async () => {
    if (!window.confirm("Delete this job permanently?")) return;
    setBusy("delete");
    setError("");
    try {
      await api.delete(`/api/hr/jobs/${id}`);
      router.push("/hr/jobs");
    } catch (err) {
      setError(errorMessage(err, "Could not delete the job"));
      setBusy(null);
    }
  };

  return (
    <div className="max-w-4xl">
      <Link href="/hr/jobs" className="mb-4 inline-block text-sm text-muted hover:text-maroon-800">
        &larr; Back to jobs
      </Link>

      <div className="mb-2 flex flex-wrap items-center gap-3">
        <h1 className="font-display text-3xl font-semibold tracking-tight text-maroon-900">
          {job.title}
        </h1>
        <StatusBadge status={job.status} />
        <div className="ml-auto flex flex-wrap gap-2">
          <Link
            href={`/hr/jobs/${job.id}/ranking`}
            className="rounded-lg bg-maroon-700 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-maroon-800"
          >
            View ranking
          </Link>
          <Link
            href={`/hr/candidates?job=${job.id}`}
            className="rounded-lg border border-maroon-700 px-4 py-2 text-sm font-semibold text-maroon-700 hover:bg-maroon-50"
          >
            View applicants
          </Link>
        </div>
      </div>
      <div className="mb-8 flex flex-wrap items-center gap-x-5 gap-y-1">
        <JobMeta
          department={job.department}
          location={job.location}
          employmentType={job.employment_type}
          workMode={job.work_mode}
        />
        <span className="text-sm text-muted">
          {labelOf(EXPERIENCE_LEVELS, job.experience_level)}
        </span>
      </div>

      <Stepper job={job} />

      {error && (
        <p role="alert" className="mb-4 rounded-lg bg-red-50 p-3 text-sm text-red-800 ring-1 ring-inset ring-red-200">
          {error}
        </p>
      )}
      {notice && (
        <p role="status" className="mb-4 rounded-lg bg-emerald-50 p-3 text-sm text-emerald-800 ring-1 ring-inset ring-emerald-200">
          {notice}
        </p>
      )}

      <AutomationPanel jobId={job.id} />

      {/* Requirements summary */}
      <section className="mb-6 rounded-2xl border border-line bg-white p-6 sm:p-7">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-xl font-semibold text-maroon-900">Requirements</h2>
          {!published && (
            <Link
              href={`/hr/jobs/${job.id}/edit`}
              className="flex items-center gap-1.5 text-sm font-medium text-maroon-700 hover:underline"
            >
              <Pencil size={14} /> Edit
            </Link>
          )}
        </div>
        <dl className="grid gap-x-10 gap-y-5 text-sm sm:grid-cols-2">
          <div>
            <dt className="mb-1.5 text-muted">Required skills</dt>
            <dd className="flex flex-wrap gap-1.5">
              {job.required_skills.map((s) => (
                <span key={s} className="rounded-md bg-maroon-50 px-2 py-0.5 text-maroon-800 ring-1 ring-inset ring-maroon-200">
                  {s}
                </span>
              ))}
            </dd>
          </div>
          {job.nice_to_have_skills.length > 0 && (
            <div>
              <dt className="mb-1.5 text-muted">Nice to have</dt>
              <dd className="flex flex-wrap gap-1.5">
                {job.nice_to_have_skills.map((s) => (
                  <span key={s} className="rounded-md bg-stone-100 px-2 py-0.5 text-stone-700 ring-1 ring-inset ring-stone-200">
                    {s}
                  </span>
                ))}
              </dd>
            </div>
          )}
          <div>
            <dt className="mb-1 text-muted">Experience</dt>
            <dd className="font-medium">
              {job.min_experience_years !== null || job.max_experience_years !== null
                ? `${job.min_experience_years ?? 0}${
                    job.max_experience_years !== null ? `-${job.max_experience_years}` : "+"
                  } years`
                : "Not specified"}
            </dd>
          </div>
          <div>
            <dt className="mb-1 text-muted">Openings and deadline</dt>
            <dd className="font-medium">
              {job.openings} {job.openings === 1 ? "opening" : "openings"},{" "}
              {job.application_deadline ? `apply by ${job.application_deadline}` : "no deadline"}
            </dd>
          </div>
        </dl>
      </section>

      {/* JD editor */}
      <section className="rounded-2xl border border-line bg-white p-6 sm:p-7">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-display text-xl font-semibold text-maroon-900">
              Job description
            </h2>
            {src && <p className="mt-0.5 text-xs text-muted">{src}</p>}
          </div>
          {!published && (
            <div role="tablist" className="inline-flex rounded-lg border border-line bg-canvas p-1">
              {(["edit", "preview"] as const).map((t) => (
                <button
                  key={t}
                  role="tab"
                  aria-selected={tab === t}
                  onClick={() => setTab(t)}
                  className={`rounded-md px-4 py-1 text-sm font-medium capitalize ${
                    tab === t ? "bg-white text-maroon-800 shadow-sm" : "text-muted"
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          )}
        </div>

        {!published && (
          <div className="mb-4 flex flex-wrap gap-3">
            <input
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              maxLength={1000}
              aria-label="Optional instructions for the AI"
              placeholder="Optional: guide the AI, for example friendly tone or emphasise remote work"
              className="min-w-[16rem] flex-1 rounded-lg border border-line bg-white px-3.5 py-2.5 text-sm outline-none placeholder:text-muted/70 focus:border-maroon-600 focus:ring-2 focus:ring-maroon-600/20"
            />
            <button
              onClick={generate}
              disabled={busy !== null}
              className={`${job.jd_text ? outline : primary} flex items-center gap-2`}
            >
              <Sparkles size={16} />
              {busy === "generate"
                ? "Generating..."
                : job.jd_text
                  ? "Regenerate with AI"
                  : "Generate with AI"}
            </button>
          </div>
        )}

        {published || tab === "preview" ? (
          job.jd_text || draft ? (
            <div className="rounded-xl bg-canvas p-6">
              <Markdown>{published ? (job.jd_text ?? "") : draft}</Markdown>
            </div>
          ) : (
            <p className="text-muted">Nothing to preview yet.</p>
          )
        ) : (
          <textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            rows={22}
            aria-label="Job description (Markdown)"
            placeholder="Click Generate with AI, or write the job description here. Markdown is supported."
            className="w-full rounded-xl border border-line bg-white p-4 font-mono text-sm leading-relaxed outline-none placeholder:text-muted/70 focus:border-maroon-600 focus:ring-2 focus:ring-maroon-600/20"
          />
        )}

        {/* Actions */}
        <div className="mt-5 flex flex-wrap items-center gap-3 border-t border-line pt-5">
          {!published && (
            <>
              <button
                onClick={save}
                disabled={busy !== null || !dirty || draft.trim().length < 20}
                className={outline}
              >
                {busy === "save" ? "Saving..." : "Save changes"}
              </button>
              <button
                onClick={approve}
                disabled={busy !== null || !job.jd_text || job.status === "approved"}
                className={primary}
              >
                {job.status === "approved" ? "Approved" : "Approve description"}
              </button>
            </>
          )}
          {job.status === "approved" && (
            <button onClick={publish} disabled={busy !== null} className={primary}>
              {busy === "publish" ? "Publishing..." : "Publish job"}
            </button>
          )}
          {published && (
            <button onClick={unpublish} disabled={busy !== null} className={outline}>
              Unpublish
            </button>
          )}
          {dirty && !published && (
            <span className="text-sm text-amber-700">Unsaved changes</span>
          )}
          {!published && (
            <button
              onClick={remove}
              disabled={busy !== null}
              className="ml-auto px-3 py-2 text-sm font-medium text-red-700 hover:underline disabled:opacity-50"
            >
              Delete job
            </button>
          )}
        </div>
      </section>
    </div>
  );
}
