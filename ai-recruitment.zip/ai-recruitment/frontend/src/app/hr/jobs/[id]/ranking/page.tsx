"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { KanbanSquare } from "lucide-react";
import { api, errorMessage } from "@/lib/api";
import DecisionBadge from "@/components/DecisionBadge";
import MatchBreakdown, { ScoreBar } from "@/components/MatchBreakdown";
import PageHeader from "@/components/PageHeader";
import SkillChip from "@/components/SkillChip";
import type { Ranking } from "@/types/ranking";

function rankStyle(rank: number): string {
  if (rank === 1) return "bg-maroon-700 text-white";
  if (rank <= 3) return "bg-maroon-100 text-maroon-800";
  return "bg-stone-100 text-stone-600";
}

export default function RankingPage() {
  const { id } = useParams<{ id: string }>();
  const [data, setData] = useState<Ranking | null>(null);
  const [error, setError] = useState("");
  const [openId, setOpenId] = useState<number | null>(null);

  useEffect(() => {
    api
      .get<Ranking>(`/api/hr/jobs/${id}/ranking`)
      .then((r) => setData(r.data))
      .catch((err) => setError(errorMessage(err, "Could not load the ranking")));
  }, [id]);

  if (error) return <p className="text-red-700">{error}</p>;
  if (!data) return <p className="text-muted">Loading...</p>;

  const { job, ranked, unranked } = data;
  const range =
    job.min_experience_years !== null && job.max_experience_years !== null
      ? `${job.min_experience_years} to ${job.max_experience_years} years`
      : job.min_experience_years !== null
        ? `${job.min_experience_years}+ years`
        : job.max_experience_years !== null
          ? `up to ${job.max_experience_years} years`
          : null;

  return (
    <div className="max-w-5xl">
      <div className="mb-4 flex items-center justify-between gap-3">
        <Link href={`/hr/jobs/${job.id}`} className="text-sm text-muted hover:text-maroon-800">
          &larr; Back to job
        </Link>
        <Link href={`/hr/pipeline?job=${job.id}`}
              className="inline-flex items-center gap-2 rounded-lg border border-maroon-700 px-3.5 py-2 text-sm font-semibold text-maroon-700 hover:bg-maroon-50">
          <KanbanSquare size={16} /> Board view
        </Link>
      </div>
      <PageHeader
        title={`Ranking for ${job.title}`}
        subtitle={
          ranked.length > 0
            ? `${ranked.length} ${ranked.length === 1 ? "candidate is" : "candidates are"} compared with this job's requirements, best match first.`
            : "Candidates will be ranked here as soon as they apply and their CVs are read."
        }
      />

      {/* What candidates are compared against */}
      <section className="mb-8 rounded-2xl border border-line bg-white p-6">
        <h2 className="mb-4 font-display text-lg font-semibold text-maroon-900">Compared against</h2>
        <dl className="grid gap-x-10 gap-y-4 text-sm sm:grid-cols-2">
          <div>
            <dt className="mb-1.5 text-muted">Required skills</dt>
            <dd className="flex flex-wrap gap-1.5">
              {job.required_skills.map((s) => (
                <span key={s} className="rounded-md bg-maroon-50 px-2 py-0.5 text-maroon-800 ring-1 ring-inset ring-maroon-200">
                  {s}
                </span>
              ))}
            </dd>
          </div>
          {job.nice_to_have_skills.length > 0 && (
            <div>
              <dt className="mb-1.5 text-muted">Nice to have</dt>
              <dd className="flex flex-wrap gap-1.5">
                {job.nice_to_have_skills.map((s) => (
                  <span key={s} className="rounded-md bg-stone-100 px-2 py-0.5 text-stone-700 ring-1 ring-inset ring-stone-200">
                    {s}
                  </span>
                ))}
              </dd>
            </div>
          )}
          {range && (
            <div>
              <dt className="mb-1 text-muted">Experience</dt>
              <dd className="font-medium">{range}</dd>
            </div>
          )}
          {job.education && (
            <div>
              <dt className="mb-1 text-muted">Education</dt>
              <dd className="font-medium">{job.education}</dd>
            </div>
          )}
        </dl>
        <p className="mt-4 text-xs text-muted">
          Want different requirements? Edit them on the job and the ranking updates straight away.
        </p>
      </section>

      {ranked.length === 0 && (
        <div className="rounded-2xl border border-line bg-white px-6 py-14 text-center">
          <p className="font-medium">No candidates to rank yet</p>
          <p className="mx-auto mt-1 max-w-sm text-sm text-muted">
            When candidates apply and their CVs have been read, they appear here with a match score.
          </p>
        </div>
      )}

      <ol className="space-y-4">
        {ranked.map((c) => {
          const open = openId === c.application_id;
          const m = c.match;
          return (
            <li key={c.application_id} className="overflow-hidden rounded-2xl border border-line bg-white shadow-sm">
              <div className="flex flex-wrap items-start gap-5 p-6">
                <span
                  className={`grid h-12 w-12 shrink-0 place-items-center rounded-full font-display text-xl font-semibold ${rankStyle(c.rank)}`}
                  aria-label={`Rank ${c.rank}`}
                >
                  {c.rank}
                </span>

                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <Link
                      href={`/hr/applications/${c.application_id}`}
                      className="text-lg font-medium text-ink hover:text-maroon-700 hover:underline"
                    >
                      {c.candidate_name}
                    </Link>
                    {c.decision !== "under_review" && <DecisionBadge decision={c.decision} />}
                  </div>
                  <p className="text-sm text-muted">
                    {c.candidate_email}
                    {c.years !== null ? `. About ${c.years} years of experience` : ""}
                  </p>
                  <ul className="mt-3 flex flex-wrap gap-1.5" aria-label="Required skills">
                    {m.required.items.map((i) => (
                      <SkillChip key={i.skill} item={i} />
                    ))}
                  </ul>
                  {c.gap && c.gap.verdict !== "none" && (
                    <p
                      className={`mt-3 text-sm ${c.gap.verdict === "critical" ? "font-medium text-red-700" : "text-muted"}`}
                    >
                      {c.gap.verdict === "critical"
                        ? `${c.gap.critical} critical ${c.gap.critical === 1 ? "gap" : "gaps"}`
                        : c.gap.missing.length === 1
                          ? "1 gap, trainable"
                          : `${c.gap.missing.length} gaps, all trainable`}
                      : {c.gap.missing.join(", ")}
                    </p>
                  )}
                </div>

                <div className="w-full sm:w-44">
                  <p className="font-display text-4xl font-semibold leading-none text-maroon-900">{m.overall}%</p>
                  <p className="mb-2 mt-1 text-sm font-medium text-maroon-800">{m.label}</p>
                  <ScoreBar percent={m.overall} />
                  <p className="mt-2 text-xs text-muted">
                    {m.required.matched} of {m.required.total} required skills
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-between border-t border-line px-6 py-3">
                <button
                  onClick={() => setOpenId(open ? null : c.application_id)}
                  aria-expanded={open}
                  className="text-sm font-medium text-maroon-700 hover:underline"
                >
                  {open ? "Hide the details" : "Why this score"}
                </button>
                <Link
                  href={`/hr/applications/${c.application_id}`}
                  className="text-sm font-medium text-maroon-700 hover:underline"
                >
                  Open full CV
                </Link>
              </div>

              {open && (
                <div className="border-t border-line bg-canvas/60 p-6 sm:p-8">
                  <MatchBreakdown match={m} />
                </div>
              )}
            </li>
          );
        })}
      </ol>

      {unranked.length > 0 && (
        <section className="mt-10">
          <h2 className="mb-3 font-display text-lg font-semibold text-maroon-900">Not ranked yet</h2>
          <ul className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-white">
            {unranked.map((u) => (
              <li key={u.application_id}>
                <Link
                  href={`/hr/applications/${u.application_id}`}
                  className="flex flex-wrap items-center justify-between gap-2 px-6 py-4 hover:bg-maroon-50/60"
                >
                  <span className="font-medium">{u.candidate_name}</span>
                  <span className="text-sm text-muted">{u.reason}</span>
                </Link>
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}
