"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import JobForm from "@/components/JobForm";
import PageHeader from "@/components/PageHeader";
import { api, errorMessage } from "@/lib/api";
import type { Job, JobInput } from "@/types/job";

export default function EditJobPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [job, setJob] = useState<Job | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .get<Job>(`/api/hr/jobs/${id}`)
      .then((r) => setJob(r.data))
      .catch((err) => setError(errorMessage(err, "Could not load the job")));
  }, [id]);

  async function save(data: JobInput) {
    await api.put(`/api/hr/jobs/${id}`, data);
    router.push(`/hr/jobs/${id}`);
  }

  if (error) return <p className="text-red-700">{error}</p>;
  if (!job) return <p className="text-muted">Loading...</p>;

  if (job.status === "published") {
    return (
      <div className="rounded-2xl border border-line bg-white p-8">
        <p className="mb-3">
          This job is published. Unpublish it first if you want to change the requirements.
        </p>
        <Link href={`/hr/jobs/${id}`} className="font-medium text-maroon-700 hover:underline">
          Back to the job
        </Link>
      </div>
    );
  }

  const {
    title, department, location, employment_type, work_mode, experience_level,
    min_experience_years, max_experience_years, education, salary_min, salary_max,
    salary_currency, show_salary, openings, application_deadline, required_skills,
    nice_to_have_skills, responsibilities, company_about,
  } = job;
  const initial: JobInput = {
    title, department, location, employment_type, work_mode, experience_level,
    min_experience_years, max_experience_years, education, salary_min, salary_max,
    salary_currency, show_salary, openings, application_deadline, required_skills,
    nice_to_have_skills, responsibilities, company_about,
  };

  return (
    <div>
      <Link href={`/hr/jobs/${id}`} className="mb-4 inline-block text-sm text-muted hover:text-maroon-800">
        &larr; Back to job
      </Link>
      <PageHeader title="Edit requirements" />
      <JobForm
        initial={initial}
        submitLabel="Save changes"
        notice={
          job.status === "approved"
            ? "This job's description is approved. Saving changes means you will need to approve it again."
            : undefined
        }
        onSubmit={save}
      />
    </div>
  );
}
