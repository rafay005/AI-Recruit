"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Plus } from "lucide-react";
import { api, errorMessage } from "@/lib/api";
import JobMeta from "@/components/JobMeta";
import PageHeader from "@/components/PageHeader";
import StatusBadge from "@/components/StatusBadge";
import type { JobListItem } from "@/types/job";

const filters = [
  { value: "", label: "All" },
  { value: "draft", label: "Draft" },
  { value: "approved", label: "Approved" },
  { value: "published", label: "Published" },
];

export default function JobsPage() {
  const [jobs, setJobs] = useState<JobListItem[] | null>(null);
  const [filter, setFilter] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .get("/api/hr/jobs", { params: filter ? { status: filter } : {} })
      .then((r) => {
        setJobs(r.data);
        setError("");
      })
      .catch((err) => setError(errorMessage(err, "Could not load jobs")));
  }, [filter]);

  return (
    <div>
      <PageHeader
        title="Jobs"
        subtitle="Create, review and publish the roles you are hiring for."
        actions={
          <Link
            href="/hr/jobs/new"
            className="flex items-center gap-2 rounded-lg bg-maroon-700 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-maroon-800"
          >
            <Plus size={16} /> New job
          </Link>
        }
      />

      <div role="tablist" aria-label="Filter by status" className="mb-5 inline-flex rounded-lg border border-line bg-white p-1">
        {filters.map((f) => (
          <button
            key={f.value}
            role="tab"
            aria-selected={filter === f.value}
            onClick={() => {
              setJobs(null);
              setFilter(f.value);
            }}
            className={`rounded-md px-4 py-1.5 text-sm font-medium transition ${
              filter === f.value
                ? "bg-maroon-700 text-white shadow-sm"
                : "text-muted hover:text-maroon-800"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {error && <p className="text-red-700">{error}</p>}
      {!error && jobs === null && <p className="text-muted">Loading...</p>}

      {jobs && jobs.length === 0 && (
        <div className="rounded-2xl border border-line bg-white px-6 py-14 text-center">
          <p className="mb-4 text-muted">
            {filter ? "No jobs with this status." : "You have not created any jobs yet."}
          </p>
          {!filter && (
            <Link
              href="/hr/jobs/new"
              className="inline-flex items-center gap-2 rounded-lg bg-maroon-700 px-4 py-2.5 text-sm font-semibold text-white hover:bg-maroon-800"
            >
              <Plus size={16} /> Create your first job
            </Link>
          )}
        </div>
      )}

      {jobs && jobs.length > 0 && (
        <ul className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-white">
          {jobs.map((j) => (
            <li key={j.id}>
              <Link
                href={`/hr/jobs/${j.id}`}
                className="flex flex-wrap items-center justify-between gap-3 px-6 py-5 hover:bg-maroon-50/60"
              >
                <div className="min-w-0">
                  <p className="truncate text-lg font-medium">{j.title}</p>
                  <div className="mt-1.5">
                    <JobMeta
                      department={j.department}
                      location={j.location}
                      employmentType={j.employment_type}
                      workMode={j.work_mode}
                    />
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  {j.applicant_count > 0 && (
                    <span className="text-sm font-medium text-maroon-800">
                      {j.applicant_count} {j.applicant_count === 1 ? "applicant" : "applicants"}
                    </span>
                  )}
                  <span className="text-xs text-muted">
                    Updated {new Date(j.updated_at).toLocaleDateString()}
                  </span>
                  <StatusBadge status={j.status} />
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
