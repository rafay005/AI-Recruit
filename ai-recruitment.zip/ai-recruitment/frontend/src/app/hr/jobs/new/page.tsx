"use client";

import { useRouter } from "next/navigation";
import Link from "next/link";
import JobForm from "@/components/JobForm";
import PageHeader from "@/components/PageHeader";
import { api } from "@/lib/api";
import type { Job, JobInput } from "@/types/job";

export default function NewJobPage() {
  const router = useRouter();

  async function create(data: JobInput) {
    const { data: job } = await api.post<Job>("/api/hr/jobs", data);
    router.push(`/hr/jobs/${job.id}`);
  }

  return (
    <div>
      <Link href="/hr/jobs" className="mb-4 inline-block text-sm text-muted hover:text-maroon-800">
        &larr; Back to jobs
      </Link>
      <PageHeader
        title="Create a job"
        subtitle="Enter the requirements. In the next step, AI will draft the job description for you."
      />
      <JobForm submitLabel="Save and continue" onSubmit={create} />
    </div>
  );
}
