"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import HRInterviewPanel from "@/components/interview/HRInterviewPanel";

export default function HRInterviewPage() {
  const params = useParams<{ id: string }>();
  const id = Number(params.id);
  if (!Number.isInteger(id) || id <= 0) return <p className="py-20 text-center text-neutral-500">This link is not valid.</p>;
  return (
    <main className="mx-auto max-w-3xl space-y-4 p-6">
      <Link href={`/hr/applications/${id}`} className="text-sm text-[#7a1f3d] hover:underline">← Back to the candidate</Link>
      <HRInterviewPanel applicationId={id} />
    </main>
  );
}
