"use client";

import { useCallback, useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { Download, Mail, Phone, RotateCcw } from "lucide-react";
import { api, errorMessage } from "@/lib/api";
import AnalysisBadge from "@/components/AnalysisBadge";
import CVDetails from "@/components/CVDetails";
import DecisionPanel from "@/components/DecisionPanel";
import SkillGapPanel from "@/components/SkillGapPanel";
import MatchBreakdown from "@/components/MatchBreakdown";
import InterviewSection from "@/components/interview/InterviewSection";
import { methodLabel, type HRApplication } from "@/types/application";
import type { CandidateMatch } from "@/types/ranking";

export default function HRApplicationPage() {
  const { id } = useParams<{ id: string }>();
  const [app, setApp] = useState<HRApplication | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [showText, setShowText] = useState(false);
  const [match, setMatch] = useState<CandidateMatch | null>(null);

  const load = useCallback(async () => {
    const r = await api.get<HRApplication>(`/api/hr/applications/${id}`);
    setApp(r.data);
  }, [id]);

  useEffect(() => {
    api
      .get<HRApplication>(`/api/hr/applications/${id}`)
      .then((r) => setApp(r.data))
      .catch((err) => setError(errorMessage(err, "Could not load this application")));
  }, [id]);

  const working = app?.analysis_status === "processing" || app?.analysis_status === "pending";
  useEffect(() => {
    if (!working) return;
    const t = setInterval(() => {
      load().catch(() => {});
    }, 3000);
    return () => clearInterval(t);
  }, [working, load]);

  // The decision panel keeps its own copy of the decision, so check the server every few
  // seconds until the decision becomes "interview". Then the AI interview card appears by itself.
  const decision = app?.decision;
  useEffect(() => {
    if (!decision || decision === "interview") return;
    const t = setInterval(() => {
      load().catch(() => {});
    }, 5000);
    return () => clearInterval(t);
  }, [decision, load]);

  const doneNow = app?.analysis_status === "done";
  useEffect(() => {
    if (!doneNow) return;
    api
      .get<CandidateMatch>(`/api/hr/applications/${id}/match`)
      .then((r) => setMatch(r.data))
      .catch(() => {});
  }, [id, doneNow]);

  async function download() {
    if (!app) return;
    setBusy(true);
    setError("");
    try {
      const res = await api.get(`/api/hr/applications/${id}/cv`, { responseType: "blob" });
      const url = URL.createObjectURL(res.data);
      const a = document.createElement("a");
      a.href = url;
      a.download = app.cv_filename;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      setError(errorMessage(err, "Could not download the CV"));
    } finally {
      setBusy(false);
    }
  }

  async function reanalyze() {
    setBusy(true);
    setError("");
    try {
      const r = await api.post<HRApplication>(`/api/hr/applications/${id}/reanalyze`);
      setApp(r.data);
    } catch (err) {
      setError(errorMessage(err, "Could not start the analysis"));
    } finally {
      setBusy(false);
    }
  }

  if (error && !app) return <p className="text-red-700">{error}</p>;
  if (!app) return <p className="text-muted">Loading...</p>;

  const ex = app.extracted;
  const name = ex?.name ?? app.candidate_account_name;
  const email = ex?.email ?? app.candidate_account_email;
  const phone = app.phone ?? ex?.phone;

  const btn =
    "inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-semibold transition disabled:opacity-60";

  return (
    <div className="max-w-4xl">
      <Link
        href={`/hr/candidates?job=${app.job.id}`}
        className="mb-4 inline-block text-sm text-muted hover:text-maroon-800"
      >
        &larr; Back to candidates
      </Link>

      <header className="mb-8 flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="font-display text-3xl font-semibold tracking-tight text-maroon-900">{name}</h1>
            <AnalysisBadge status={app.analysis_status} />
          </div>
          <p className="mt-1.5 text-muted">
            Applied for {app.job.title} on {new Date(app.created_at).toLocaleDateString()}
          </p>
          <ul className="mt-3 flex flex-wrap gap-x-6 gap-y-1 text-sm">
            <li className="flex items-center gap-1.5">
              <Mail size={14} className="text-maroon-500" /> {email}
            </li>
            {phone && (
              <li className="flex items-center gap-1.5">
                <Phone size={14} className="text-maroon-500" /> {phone}
              </li>
            )}
            {ex?.total_experience_years != null && (
              <li className="text-muted">About {ex.total_experience_years} years of experience</li>
            )}
          </ul>
        </div>
        <div className="flex flex-wrap gap-3">
          <button
            onClick={download}
            disabled={busy}
            className={`${btn} bg-maroon-700 text-white shadow-sm hover:bg-maroon-800`}
          >
            <Download size={16} /> Download CV
          </button>
          <button
            onClick={reanalyze}
            disabled={busy || working}
            className={`${btn} border border-maroon-700 text-maroon-700 hover:bg-maroon-50`}
          >
            <RotateCcw size={16} /> Analyse again
          </button>
        </div>
      </header>

      {error && (
        <p role="alert" className="mb-4 rounded-lg bg-red-50 p-3 text-sm text-red-800 ring-1 ring-inset ring-red-200">
          {error}
        </p>
      )}

      {working && (
        <p className="mb-6 rounded-xl bg-amber-50 p-4 text-sm text-amber-900 ring-1 ring-inset ring-amber-200">
          The CV is being read. This page updates by itself.
        </p>
      )}
      {app.analysis_status === "failed" && (
        <p className="mb-6 rounded-xl bg-red-50 p-4 text-sm text-red-900 ring-1 ring-inset ring-red-200">
          {app.analysis_error ?? "This CV could not be read."} You can still download the original file.
        </p>
      )}

      <DecisionPanel
        applicationId={app.id}
        initialDecision={app.decision}
        initialNote={app.decision_note}
      />

      {/* AI interview: shown only for candidates whose decision is "Interview" */}
      <div className="mb-6">
        <InterviewSection
          applicationId={app.id}
          decision={app.decision}
          analysisStatus={app.analysis_status}
          onChanged={() => {
            load().catch(() => {});
          }}
        />
      </div>

      {app.cover_note && (
        <section className="mb-6 rounded-2xl border border-line bg-white p-6">
          <h2 className="mb-2 font-display text-lg font-semibold text-maroon-900">Cover note</h2>
          <p className="whitespace-pre-line leading-relaxed">{app.cover_note}</p>
        </section>
      )}

      {match?.match && (
        <section className="mb-6 rounded-2xl border border-line bg-white p-6 sm:p-8">
          <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
            <h2 className="font-display text-2xl font-semibold text-maroon-900">Match with this job</h2>
            {match.rank !== null && (
              <Link
                href={`/hr/jobs/${match.job.id}/ranking`}
                className="rounded-full bg-maroon-50 px-4 py-1.5 text-sm font-semibold text-maroon-800 ring-1 ring-inset ring-maroon-200 hover:bg-maroon-100"
              >
                Rank {match.rank} of {match.total_ranked}
              </Link>
            )}
          </div>
          <MatchBreakdown match={match.match} jobTitle={match.job.title} />
        </section>
      )}

      {app.analysis_status === "done" && <SkillGapPanel applicationId={app.id} />}

      {ex && (
        <section className="rounded-2xl border border-line bg-white p-6 sm:p-8">
          <p className="mb-6 text-sm text-muted">
            {methodLabel(app.extraction_method)}
            {app.analysis_model === "built-in" ? ", built-in extractor (approximate)" : app.analysis_model ? `, ${app.analysis_model}` : ""}.
            {app.analysis_note ? ` ${app.analysis_note}` : ""} Check the original CV for anything important.
          </p>
          <CVDetails data={ex} />
        </section>
      )}

      {app.parsed_text && (
        <section className="mt-6 rounded-2xl border border-line bg-white p-6">
          <button
            onClick={() => setShowText(!showText)}
            aria-expanded={showText}
            className="text-sm font-medium text-maroon-700 hover:underline"
          >
            {showText ? "Hide the text read from the CV" : "Show the text read from the CV"}
          </button>
          {showText && (
            <pre className="mt-4 max-h-96 overflow-auto whitespace-pre-wrap rounded-xl bg-canvas p-4 text-xs leading-relaxed">
              {app.parsed_text}
            </pre>
          )}
        </section>
      )}
    </div>
  );
}