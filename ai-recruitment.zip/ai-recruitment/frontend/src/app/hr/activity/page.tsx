"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Bot } from "lucide-react";
import { ACT_FALLBACK, ACT_ICON, Card, Loading, PageTitle, ago, useInsights } from "@/components/dashboard/shared";

const FILTERS = [
  { key: "all", label: "All" },
  { key: "auto", label: "Automatic decisions" },
  { key: "applied", label: "Applications" },
  { key: "interviewed", label: "Interviews" },
] as const;

export default function ActivityPage() {
  const { data: d, error } = useInsights();
  const [filter, setFilter] = useState<(typeof FILTERS)[number]["key"]>("all");
  const [job, setJob] = useState("all");

  const items = useMemo(() => (d?.activity ?? []).filter((a) =>
    (filter === "all" || (filter === "auto" ? a.auto : a.kind === filter)) && (job === "all" || a.job_title === job)
  ), [d, filter, job]);

  if (error) return <p className="text-red-700">{error}</p>;
  if (!d) return <Loading />;
  const k = d.kpis;
  const counts = {
    all: d.activity.length,
    auto: d.activity.filter((a) => a.auto).length,
    applied: d.activity.filter((a) => a.kind === "applied").length,
    interviewed: d.activity.filter((a) => a.kind === "interviewed").length,
  };
  const jobTitles = Array.from(new Set(d.activity.map((a) => a.job_title).filter(Boolean))) as string[];

  return (
    <div className="space-y-5">
      <PageTitle title="Activity" sub="Everything that happened across your jobs, including every automatic decision and why" />

      {/* Automation summary per job */}
      <div className="stagger grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {d.jobs.map((j) => (
          <Link key={j.id} href={`/hr/jobs/${j.id}`} className="rounded-2xl border border-line bg-white p-4 hover:border-maroon-300">
            <div className="flex items-start justify-between gap-2">
              <p className="truncate font-medium text-ink">{j.title}</p>
              <span className={`inline-flex shrink-0 items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium ring-1 ring-inset ${
                j.auto_enabled ? "bg-emerald-50 text-emerald-800 ring-emerald-200" : "bg-stone-100 text-stone-600 ring-stone-200"}`}>
                <Bot size={11} />{j.auto_enabled ? "Automatic" : "Manual"}
              </span>
            </div>
            <p className="mt-1 text-xs text-muted">
              {j.auto_enabled ? `Invite at CV ≥${j.cv_threshold}% · select at interview ≥${j.interview_threshold}` : "You decide every candidate"}
            </p>
            <div className="mt-3 flex gap-4 text-sm">
              <span><b>{j.applicants}</b> <span className="text-muted">applied</span></span>
              <span><b>{j.interviews_done}</b> <span className="text-muted">interviewed</span></span>
              <span><b>{j.selected}/{j.openings}</b> <span className="text-muted">filled</span></span>
            </div>
          </Link>
        ))}
      </div>

      <Card title="Timeline" sub={`${k.automated_decisions} decisions made automatically so far`}
            action={jobTitles.length > 1 ? (
              <select value={job} onChange={(e) => setJob(e.target.value)} aria-label="Filter by job"
                      className="rounded-lg border border-line bg-white px-2.5 py-1.5 text-sm">
                <option value="all">All jobs</option>
                {jobTitles.map((t) => <option key={t} value={t}>{t}</option>)}
              </select>
            ) : undefined}>
        <div role="tablist" className="mb-4 flex flex-wrap gap-1.5">
          {FILTERS.map((f) => (
            <button key={f.key} role="tab" aria-selected={filter === f.key} onClick={() => setFilter(f.key)}
                    className={`rounded-full px-3 py-1 text-sm font-medium transition ${
                      filter === f.key ? "bg-maroon-700 text-white" : "bg-maroon-50 text-maroon-800 hover:bg-maroon-100"}`}>
              {f.label} <span className="opacity-70">{counts[f.key]}</span>
            </button>
          ))}
        </div>

        {items.length === 0 ? <p className="py-6 text-center text-sm text-muted">Nothing here yet.</p> : (
          <ul className="relative space-y-4 before:absolute before:bottom-2 before:left-[15px] before:top-2 before:w-px before:bg-line">
            {items.map((a, i) => {
              const m = ACT_ICON[a.kind] ?? ACT_FALLBACK;
              const Icon = m.icon;
              return (
                <li key={i} className="relative flex gap-3">
                  <span className={`relative z-[1] grid h-8 w-8 shrink-0 place-items-center rounded-full ring-4 ring-white ${m.tone}`}><Icon size={15} /></span>
                  <div className="min-w-0 flex-1 pt-0.5">
                    <p className="text-sm text-ink">
                      {a.text}
                      {a.auto && <span className="ml-1.5 inline-flex items-center gap-0.5 rounded bg-maroon-50 px-1.5 py-px align-middle text-[10px] font-semibold uppercase tracking-wide text-maroon-700"><Bot size={10} />auto</span>}
                    </p>
                    {a.detail && <p className="text-xs text-muted">{a.detail}</p>}
                    <p className="text-xs text-muted">{a.job_title} · {ago(a.at)}</p>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </Card>
    </div>
  );
}
