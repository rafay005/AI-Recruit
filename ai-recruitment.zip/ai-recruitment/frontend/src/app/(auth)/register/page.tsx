"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import AuthShell from "@/components/AuthShell";
import { api, errorMessage } from "@/lib/api";

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    full_name: "",
    email: "",
    password: "",
    role: "candidate",
    company: "",
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const set =
    (key: string) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
      setForm({ ...form, [key]: e.target.value });

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await api.post("/api/auth/register", {
        ...form,
        company: form.role === "hr" && form.company ? form.company : null,
      });
      router.push("/login");
    } catch (err) {
      setError(errorMessage(err, "Registration failed"));
    } finally {
      setLoading(false);
    }
  }

  const input =
    "w-full rounded-lg border border-line bg-white px-3.5 py-2.5 text-ink outline-none transition focus:border-maroon-600 focus:ring-2 focus:ring-maroon-600/20";
  const label = "mb-1.5 block text-sm font-medium";

  return (
    <AuthShell>
      <h1 className="font-display text-3xl font-semibold text-maroon-900">Create your account</h1>
      <p className="mb-8 mt-2 text-muted">It takes less than a minute.</p>

      <form onSubmit={onSubmit} className="space-y-4">
        {error && (
          <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-800 ring-1 ring-inset ring-red-200">
            {error}
          </p>
        )}
        <div>
          <label htmlFor="full_name" className={label}>
            Full name
          </label>
          <input
            id="full_name"
            required
            minLength={2}
            className={input}
            value={form.full_name}
            onChange={set("full_name")}
          />
        </div>
        <div>
          <label htmlFor="reg_email" className={label}>
            Email
          </label>
          <input
            id="reg_email"
            required
            type="email"
            autoComplete="email"
            className={input}
            value={form.email}
            onChange={set("email")}
          />
        </div>
        <div>
          <label htmlFor="reg_password" className={label}>
            Password
          </label>
          <input
            id="reg_password"
            required
            type="password"
            minLength={8}
            maxLength={72}
            autoComplete="new-password"
            className={input}
            value={form.password}
            onChange={set("password")}
          />
          <p className="mt-1 text-xs text-muted">At least 8 characters.</p>
        </div>
        <div>
          <label htmlFor="role" className={label}>
            I am a
          </label>
          <select id="role" className={input} value={form.role} onChange={set("role")}>
            <option value="candidate">Candidate looking for a job</option>
            <option value="hr">HR manager or recruiter</option>
          </select>
        </div>
        {form.role === "hr" && (
          <div>
            <label htmlFor="company" className={label}>
              Company name
            </label>
            <input
              id="company"
              className={input}
              value={form.company}
              onChange={set("company")}
            />
          </div>
        )}
        <button
          disabled={loading}
          className="w-full rounded-lg bg-maroon-700 py-2.5 font-medium text-white shadow-sm transition hover:bg-maroon-800 disabled:opacity-60"
        >
          {loading ? "Creating account..." : "Create account"}
        </button>
      </form>

      <p className="mt-8 text-sm text-muted">
        Already registered?{" "}
        <Link href="/login" className="font-medium text-maroon-700 underline-offset-4 hover:underline">
          Sign in
        </Link>
      </p>
    </AuthShell>
  );
}
