"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import AuthShell from "@/components/AuthShell";
import { useAuth } from "@/store/auth";
import { errorMessage } from "@/lib/api";

export default function LoginPage() {
  const router = useRouter();
  const login = useAuth((s) => s.login);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const user = await login(email, password);
      router.push(user.role === "hr" ? "/hr/dashboard" : "/candidate");
    } catch (err) {
      setError(errorMessage(err, "Login failed"));
    } finally {
      setLoading(false);
    }
  }

  const input =
    "w-full rounded-lg border border-line bg-white px-3.5 py-2.5 text-ink outline-none transition focus:border-maroon-600 focus:ring-2 focus:ring-maroon-600/20";

  return (
    <AuthShell>
      <h1 className="font-display text-3xl font-semibold text-maroon-900">Welcome back</h1>
      <p className="mb-8 mt-2 text-muted">Sign in to continue to your account.</p>

      <form onSubmit={onSubmit} className="space-y-5">
        {error && (
          <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-800 ring-1 ring-inset ring-red-200">
            {error}
          </p>
        )}
        <div>
          <label htmlFor="email" className="mb-1.5 block text-sm font-medium">
            Email
          </label>
          <input
            id="email"
            type="email"
            required
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className={input}
          />
        </div>
        <div>
          <label htmlFor="password" className="mb-1.5 block text-sm font-medium">
            Password
          </label>
          <input
            id="password"
            type="password"
            required
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className={input}
          />
        </div>
        <button
          disabled={loading}
          className="w-full rounded-lg bg-maroon-700 py-2.5 font-medium text-white shadow-sm transition hover:bg-maroon-800 disabled:opacity-60"
        >
          {loading ? "Signing in..." : "Sign in"}
        </button>
      </form>

      <p className="mt-8 text-sm text-muted">
        New here?{" "}
        <Link href="/register" className="font-medium text-maroon-700 underline-offset-4 hover:underline">
          Create an account
        </Link>
      </p>
    </AuthShell>
  );
}
