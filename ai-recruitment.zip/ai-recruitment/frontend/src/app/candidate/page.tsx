"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { api, errorMessage } from "@/lib/api";
import JobMeta from "@/components/JobMeta";
import Markdown from "@/components/Markdown";
import PageHeader from "@/components/PageHeader";
import type { Application } from "@/types/application";
import type { PublicJob } from "@/types/job";

export default function CandidateJobsPage() {
  const [jobs, setJobs] = useState<PublicJob[] | null>(null);
  const [applied, setApplied] = useState<Set<number>>(new Set());
  const [openId, setOpenId] = useState<number | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([api.get<PublicJob[]>("/api/jobs"), api.get<Application[]>("/api/applications/mine")])
      .then(([j, a]) => {
        setJobs(j.data);
        setApplied(new Set(a.data.map((x) => x.job.id)));
      })
      .catch((err) => setError(errorMessage(err, "Could not load jobs")));
  }, []);

  return (
    <div>
      <PageHeader
        title="Open positions"
        subtitle="Read the description and apply with your CV. We read it automatically, so you do not have to fill in long forms."
      />

      {error && <p className="rounded-xl bg-white p-5 text-red-700">{error}</p>}
      {!error && jobs === null && <p className="text-muted">Loading jobs...</p>}
      {jobs && jobs.length === 0 && (
        <div className="rounded-2xl border border-line bg-white px-6 py-14 text-center">
          <p className="font-medium">No open positions right now</p>
          <p className="mt-1 text-sm text-muted">New roles appear here as soon as they are published.</p>
        </div>
      )}

      <ul className="space-y-4">
        {jobs?.map((j) => {
          const open = openId === j.id;
          const hasApplied = applied.has(j.id);
          return (
            <li key={j.id} className="overflow-hidden rounded-2xl border border-line bg-white shadow-sm">
              <div className="p-6">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <p className="font-display text-2xl font-semibold text-maroon-900">{j.title}</p>
                    <div className="mt-2">
                      <JobMeta
                        company={j.company}
                        location={j.location}
                        employmentType={j.employment_type}
                        workMode={j.work_mode}
                      />
                    </div>
                  </div>
                  {hasApplied ? (
                    <Link
                      href="/candidate/applications"
                      className="rounded-lg bg-emerald-50 px-4 py-2.5 text-sm font-semibold text-emerald-800 ring-1 ring-inset ring-emerald-300"
                    >
                      Applied, view status
                    </Link>
                  ) : (
                    <Link
                      href={`/candidate/jobs/${j.id}/apply`}
                      className="rounded-lg bg-maroon-700 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-maroon-800"
                    >
                      Apply now
                    </Link>
                  )}
                </div>

                {j.required_skills.length > 0 && (
                  <ul className="mt-4 flex flex-wrap gap-1.5">
                    {j.required_skills.slice(0, 8).map((s) => (
                      <li
                        key={s}
                        className="rounded-md bg-maroon-50 px-2 py-0.5 text-xs text-maroon-800 ring-1 ring-inset ring-maroon-200"
                      >
                        {s}
                      </li>
                    ))}
                  </ul>
                )}

                <button
                  onClick={() => setOpenId(open ? null : j.id)}
                  aria-expanded={open}
                  className="mt-4 text-sm font-medium text-maroon-700 hover:underline"
                >
                  {open ? "Hide description" : "Read description"}
                </button>
              </div>
              {open && j.jd_text && (
                <div className="border-t border-line bg-canvas/60 p-6 sm:p-8">
                  <Markdown>{j.jd_text}</Markdown>
                </div>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
