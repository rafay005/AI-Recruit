"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { ShieldCheck } from "lucide-react";
import { api, errorMessage } from "@/lib/api";
import FileDrop from "@/components/FileDrop";
import JobMeta from "@/components/JobMeta";
import PageHeader from "@/components/PageHeader";
import { useAuth } from "@/store/auth";
import type { Application } from "@/types/application";
import type { PublicJob } from "@/types/job";

const input =
  "w-full rounded-lg border border-line bg-white px-3.5 py-2.5 text-ink outline-none transition placeholder:text-muted/70 focus:border-maroon-600 focus:ring-2 focus:ring-maroon-600/20";

export default function ApplyPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const user = useAuth((s) => s.user);

  const [job, setJob] = useState<PublicJob | null>(null);
  const [loadError, setLoadError] = useState("");
  const [alreadyApplied, setAlreadyApplied] = useState(false);

  const [phone, setPhone] = useState("");
  const [note, setNote] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [consent, setConsent] = useState(false);
  const [error, setError] = useState("");
  const [sending, setSending] = useState(false);

  useEffect(() => {
    Promise.all([
      api.get<PublicJob>(`/api/jobs/${id}`),
      api.get<Application[]>("/api/applications/mine"),
    ])
      .then(([j, a]) => {
        setJob(j.data);
        setAlreadyApplied(a.data.some((x) => x.job.id === Number(id)));
      })
      .catch((err) => setLoadError(errorMessage(err, "This job is no longer open.")));
  }, [id]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (!file) {
      setError("Please attach your CV.");
      return;
    }
    if (!consent) {
      setError("Please confirm that you agree to your CV being analysed.");
      return;
    }
    const body = new FormData();
    body.append("cv", file);
    if (phone.trim()) body.append("phone", phone.trim());
    if (note.trim()) body.append("cover_note", note.trim());
    setSending(true);
    try {
      await api.post(`/api/jobs/${id}/apply`, body);
      router.push("/candidate/applications");
    } catch (err) {
      setError(errorMessage(err, "Could not submit your application"));
      setSending(false);
    }
  }

  if (loadError)
    return (
      <div className="rounded-2xl border border-line bg-white p-8">
        <p className="mb-3">{loadError}</p>
        <Link href="/candidate" className="font-medium text-maroon-700 hover:underline">
          Back to open jobs
        </Link>
      </div>
    );
  if (!job) return <p className="text-muted">Loading...</p>;

  if (alreadyApplied)
    return (
      <div className="rounded-2xl border border-line bg-white p-8">
        <p className="mb-3">You have already applied for {job.title}.</p>
        <Link href="/candidate/applications" className="font-medium text-maroon-700 hover:underline">
          View your application
        </Link>
      </div>
    );

  return (
    <div>
      <Link href="/candidate" className="mb-4 inline-block text-sm text-muted hover:text-maroon-800">
        &larr; Back to open jobs
      </Link>
      <PageHeader title={`Apply for ${job.title}`} />

      <div className="grid gap-8 lg:grid-cols-[1fr_1.4fr]">
        <aside className="h-fit rounded-2xl bg-maroon-800 p-6 text-white">
          <p className="font-display text-2xl font-semibold">{job.title}</p>
          <div className="mt-3 text-maroon-100 [&_svg]:text-maroon-200 [&_li]:text-maroon-100">
            <JobMeta
              company={job.company}
              location={job.location}
              employmentType={job.employment_type}
              workMode={job.work_mode}
            />
          </div>
          {job.required_skills.length > 0 && (
            <>
              <p className="mb-2 mt-6 text-sm text-maroon-200">Skills they are looking for</p>
              <ul className="flex flex-wrap gap-1.5">
                {job.required_skills.map((s) => (
                  <li key={s} className="rounded-md bg-white/10 px-2 py-0.5 text-sm">
                    {s}
                  </li>
                ))}
              </ul>
            </>
          )}
          {job.application_deadline && (
            <p className="mt-6 text-sm text-maroon-200">Apply by {job.application_deadline}</p>
          )}
        </aside>

        <form onSubmit={submit} className="space-y-6 rounded-2xl border border-line bg-white p-6 sm:p-8">
          {error && (
            <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-800 ring-1 ring-inset ring-red-200">
              {error}
            </p>
          )}

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1.5 block text-sm font-medium">Name</label>
              <input className={`${input} bg-canvas`} value={user?.full_name ?? ""} readOnly />
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-medium">Email</label>
              <input className={`${input} bg-canvas`} value={user?.email ?? ""} readOnly />
            </div>
          </div>

          <div>
            <label htmlFor="phone" className="mb-1.5 block text-sm font-medium">
              Phone (optional)
            </label>
            <input
              id="phone"
              className={input}
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+92 300 1234567"
              maxLength={40}
              inputMode="tel"
            />
          </div>

          <div>
            <p className="mb-1.5 text-sm font-medium">Your CV *</p>
            <FileDrop file={file} onChange={setFile} />
          </div>

          <div>
            <label htmlFor="note" className="mb-1.5 block text-sm font-medium">
              Cover note (optional)
            </label>
            <textarea
              id="note"
              rows={4}
              maxLength={2000}
              className={input}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Tell the hiring team why you are a good fit."
            />
            <p className="mt-1 text-right text-xs text-muted">{note.length} / 2000</p>
          </div>

          <label className="flex items-start gap-3 rounded-xl bg-canvas p-4 text-sm">
            <input
              type="checkbox"
              checked={consent}
              onChange={(e) => setConsent(e.target.checked)}
              className="mt-0.5 h-4 w-4 accent-maroon-700"
            />
            <span>
              <span className="flex items-center gap-1.5 font-medium">
                <ShieldCheck size={15} className="text-maroon-600" /> Automatic CV analysis
              </span>
              <span className="text-muted">
                I agree that my CV will be read and analysed automatically, possibly using AI, to help the
                hiring team review my application. I can withdraw my application at any time, which also
                deletes my CV.
              </span>
            </span>
          </label>

          <button
            disabled={sending}
            className="w-full rounded-lg bg-maroon-700 py-3 font-semibold text-white shadow-sm hover:bg-maroon-800 disabled:opacity-60"
          >
            {sending ? "Uploading your CV..." : "Submit application"}
          </button>
        </form>
      </div>
    </div>
  );
}
