"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { RotateCcw } from "lucide-react";
import { api, errorMessage } from "@/lib/api";
import AnalysisBadge from "@/components/AnalysisBadge";
import CVDetails from "@/components/CVDetails";
import DecisionBadge from "@/components/DecisionBadge";
import PageHeader from "@/components/PageHeader";
import CandidateInterviewButton from "@/components/interview/CandidateInterviewButton";
import { methodLabel, type Application, type Decision } from "@/types/application";

const DECISION_COPY: Record<Decision, { title: string; text: string; box: string }> = {
  under_review: {
    title: "Your application is being reviewed",
    text: "The hiring team has not made a decision yet. We will show it here as soon as they do.",
    box: "bg-stone-50 text-stone-800 ring-stone-200",
  },
  shortlisted: {
    title: "Good news: you have been shortlisted",
    text: "The hiring team liked your profile and is moving you forward.",
    box: "bg-maroon-50 text-maroon-900 ring-maroon-200",
  },
  interview: {
    title: "You have moved to the interview stage",
    text: "The hiring team would like to speak with you.",
    box: "bg-maroon-50 text-maroon-900 ring-maroon-300",
  },
  rejected: {
    title: "Thank you for applying",
    text: "You were not selected for this role this time. We appreciate the time you took to apply.",
    box: "bg-stone-50 text-stone-800 ring-stone-300",
  },
  hired: {
    title: "Congratulations, you have been selected",
    text: "The hiring team has chosen you for this role.",
    box: "bg-emerald-50 text-emerald-900 ring-emerald-300",
  },
};

export default function MyApplicationsPage() {
  const [apps, setApps] = useState<Application[] | null>(null);
  const [openId, setOpenId] = useState<number | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState<number | null>(null);

  const load = useCallback(async () => {
    const r = await api.get<Application[]>("/api/applications/mine");
    setApps(r.data);
  }, []);

  useEffect(() => {
    api
      .get<Application[]>("/api/applications/mine")
      .then((r) => setApps(r.data))
      .catch((err) => setError(errorMessage(err, "Could not load your applications")));
  }, []);

  // While a CV is being read, check again every few seconds.
  const working = !!apps?.some((a) => a.analysis_status === "processing" || a.analysis_status === "pending");
  useEffect(() => {
    if (!working) return;
    const t = setInterval(() => {
      load().catch(() => {});
    }, 3000);
    return () => clearInterval(t);
  }, [working, load]);

  async function retry(id: number) {
    setBusy(id);
    setError("");
    try {
      await api.post(`/api/applications/${id}/retry`);
      await load();
    } catch (err) {
      setError(errorMessage(err, "Could not retry"));
    } finally {
      setBusy(null);
    }
  }

  async function withdraw(a: Application) {
    if (!window.confirm(`Withdraw your application for ${a.job.title}? Your CV will be deleted.`)) return;
    setBusy(a.id);
    setError("");
    try {
      await api.delete(`/api/applications/${a.id}`);
      await load();
    } catch (err) {
      setError(errorMessage(err, "Could not withdraw the application"));
    } finally {
      setBusy(null);
    }
  }

  return (
    <div>
      <PageHeader
        title="My applications"
        subtitle="Track your applications and see what we found in your CV."
      />

      {error && (
        <p role="alert" className="mb-4 rounded-lg bg-red-50 p-3 text-sm text-red-800 ring-1 ring-inset ring-red-200">
          {error}
        </p>
      )}
      {apps === null && !error && <p className="text-muted">Loading...</p>}
      {apps && apps.length === 0 && (
        <div className="rounded-2xl border border-line bg-white px-6 py-14 text-center">
          <p className="font-medium">You have not applied for any jobs yet</p>
          <Link href="/candidate" className="mt-3 inline-block font-medium text-maroon-700 hover:underline">
            Browse open positions
          </Link>
        </div>
      )}

      <ul className="space-y-4">
        {apps?.map((a) => {
          const open = openId === a.id;
          return (
            <li key={a.id} className="overflow-hidden rounded-2xl border border-line bg-white shadow-sm">
              <div className="p-6">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="font-display text-xl font-semibold text-maroon-900">{a.job.title}</p>
                    <p className="mt-1 text-sm text-muted">
                      {a.job.company ? `${a.job.company}. ` : ""}Applied{" "}
                      {new Date(a.created_at).toLocaleDateString()} with {a.cv_filename}
                    </p>
                  </div>
                  <DecisionBadge decision={a.decision} audience="candidate" />
                </div>

                <div className={`mt-4 rounded-xl p-4 text-sm ring-1 ring-inset ${DECISION_COPY[a.decision].box}`}>
                  <p className="font-semibold">{DECISION_COPY[a.decision].title}</p>
                  <p className="mt-0.5">{DECISION_COPY[a.decision].text}</p>
                  {a.decision !== "under_review" && a.decision_note && (
                    <p className="mt-3 border-t border-current/15 pt-3">
                      <span className="font-semibold">Message from the hiring team: </span>
                      {a.decision_note}
                    </p>
                  )}
                </div>

                {/* AI interview: appears here as soon as the hiring team invites the candidate */}
                <CandidateInterviewButton applicationId={a.id} />

                <div className="mt-3">
                  <AnalysisBadge status={a.analysis_status} />
                </div>

                {(a.analysis_status === "processing" || a.analysis_status === "pending") && (
                  <p className="mt-4 text-sm text-muted">
                    We are reading your CV. This usually takes under a minute, and this page updates by itself.
                  </p>
                )}

                {a.analysis_status === "failed" && (
                  <div className="mt-4 rounded-lg bg-red-50 p-4 text-sm text-red-900 ring-1 ring-inset ring-red-200">
                    <p>{a.analysis_error ?? "We could not read this CV."}</p>
                    <button
                      onClick={() => retry(a.id)}
                      disabled={busy === a.id}
                      className="mt-3 inline-flex items-center gap-2 rounded-lg bg-white px-3 py-1.5 font-medium text-maroon-800 ring-1 ring-inset ring-maroon-300 hover:bg-maroon-50 disabled:opacity-60"
                    >
                      <RotateCcw size={14} /> Try again
                    </button>
                    <p className="mt-2 text-red-800/80">
                      If it keeps failing, withdraw this application and apply again with a different file.
                    </p>
                  </div>
                )}

                <div className="mt-4 flex flex-wrap items-center gap-4">
                  {a.analysis_status === "done" && a.extracted && (
                    <button
                      onClick={() => setOpenId(open ? null : a.id)}
                      aria-expanded={open}
                      className="text-sm font-medium text-maroon-700 hover:underline"
                    >
                      {open ? "Hide what we found" : "See what we found in your CV"}
                    </button>
                  )}
                  <button
                    onClick={() => withdraw(a)}
                    disabled={busy === a.id}
                    className="ml-auto text-sm font-medium text-red-700 hover:underline disabled:opacity-60"
                  >
                    Withdraw application
                  </button>
                </div>
              </div>

              {open && a.extracted && (
                <div className="border-t border-line bg-canvas/60 p-6 sm:p-8">
                  <p className="mb-6 text-sm text-muted">
                    {methodLabel(a.extraction_method)}. Automatic reading can make mistakes, and your original CV is
                    what the hiring team can open.
                    {a.analysis_note ? ` ${a.analysis_note}` : ""}
                  </p>
                  <CVDetails data={a.extracted} />
                </div>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}