"use client";

import { useParams } from "next/navigation";
import InterviewRoom from "@/components/interview/InterviewRoom";

export default function CandidateInterviewPage() {
  const params = useParams<{ id: string }>();
  const id = Number(params.id);
  if (!Number.isInteger(id) || id <= 0) return <p className="py-20 text-center text-neutral-500">This interview link is not valid.</p>;
  return (
    <main className="px-4 py-8 sm:px-6">
      <InterviewRoom interviewId={id} />
    </main>
  );
}
