"use client";

import { Suspense, useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { LogOut } from "lucide-react";
import BrandMark from "@/components/BrandMark";
import CandidateNav from "@/components/CandidateNav";
import { useAuth } from "@/store/auth";

export default function CandidateLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const { user, loadUser, logout } = useAuth();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    loadUser().then((u) => {
      if (!u) router.replace("/login");
      else if (u.role === "hr") router.replace("/hr/dashboard");
      else setReady(true);
    });
  }, [loadUser, router]);

  if (!ready) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-canvas text-muted">
        Loading...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-canvas">
      <header className="bg-maroon-900 text-white">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3 px-5 py-3 sm:px-8">
          <BrandMark />
          <div className="order-3 w-full sm:order-none sm:w-auto">
            <Suspense fallback={null}>
              <CandidateNav />
            </Suspense>
          </div>
          <div className="flex items-center gap-3">
            <span className="hidden text-sm text-maroon-100 md:inline">{user?.full_name}</span>
            <button
              onClick={() => {
                logout();
                router.replace("/login");
              }}
              className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-maroon-100 hover:bg-white/10 hover:text-white"
            >
              <LogOut size={16} /> Sign out
            </button>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-5xl px-5 py-8 sm:px-8 sm:py-10">
        <div key={pathname} className="page-in">{children}</div>
      </main>
    </div>
  );
}
