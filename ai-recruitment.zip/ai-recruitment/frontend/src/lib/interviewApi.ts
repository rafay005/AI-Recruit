import type { AxiosInstance } from "axios";
import * as apiModule from "@/lib/api";
import type {
  CandidateInterview,
  HRInterview,
  InputMode,
  InterviewStatus,
  TurnsResult,
} from "@/types/interview";

// The project's axios instance (adds the login token). It is exported as the
// default export or as `api`; this picks whichever your src/lib/api.ts has.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const api: AxiosInstance = ((apiModule as any).default ?? (apiModule as any).api) as AxiosInstance;

export function errorMessage(err: unknown, fallback = "Something went wrong. Please try again."): string {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const e = err as any;
  const detail = e?.response?.data?.detail;
  if (typeof detail === "string") return detail;
  if (Array.isArray(detail) && detail[0]?.msg) return String(detail[0].msg);
  if (e?.code === "ERR_NETWORK" || e?.message === "Network Error") {
    return "Cannot reach the server. Check your connection and try again.";
  }
  return fallback;
}

async function saveText(url: string, filename: string) {
  const res = await api.get(url, { responseType: "blob" });
  const href = URL.createObjectURL(res.data as Blob);
  const a = document.createElement("a");
  a.href = href;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(href);
}

export const candidateInterview = {
  /** The candidate's own applications, only to find out whether HR has invited them. */
  mine: async () =>
    (await api.get<{ id: number; interview?: { id: number; status: InterviewStatus } | null }[]>("/api/applications/mine")).data,
  get: async (id: number) => (await api.get<CandidateInterview>(`/api/interviews/${id}`)).data,
  start: async (id: number, consent: boolean) =>
    (await api.post<TurnsResult>(`/api/interviews/${id}/start`, { consent })).data,
  answer: async (id: number, text: string, input_mode: InputMode) =>
    (await api.post<TurnsResult>(`/api/interviews/${id}/answer`, { text, input_mode })).data,
  resume: async (id: number) => (await api.post<TurnsResult>(`/api/interviews/${id}/continue`)).data,
  end: async (id: number) => (await api.post<TurnsResult>(`/api/interviews/${id}/end`)).data,
  downloadTranscript: (id: number) => saveText(`/api/interviews/${id}/transcript`, "interview-transcript.txt"),
};

export const hrInterview = {
  forApplication: async (applicationId: number) =>
    (await api.get<HRInterview | null>(`/api/hr/applications/${applicationId}/interview`)).data,
  invite: async (applicationId: number, body: { questions?: number; focus?: string }) =>
    (await api.post<HRInterview>(`/api/hr/applications/${applicationId}/interview`, body)).data,
  reset: async (interviewId: number) => {
    await api.delete(`/api/hr/interviews/${interviewId}`);
  },
  reevaluate: async (interviewId: number) =>
    (await api.post<HRInterview>(`/api/hr/interviews/${interviewId}/reevaluate`)).data,
  downloadTranscript: (interviewId: number) =>
    saveText(`/api/hr/interviews/${interviewId}/transcript.txt`, "interview-transcript.txt"),
};
