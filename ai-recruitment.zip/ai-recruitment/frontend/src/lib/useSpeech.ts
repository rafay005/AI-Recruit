"use client";

import { useCallback, useEffect, useRef, useState } from "react";

/* Minimal typings for the browser Web Speech API (not in lib.dom for every TS version). */
interface SRAlternative { transcript: string }
interface SRResult { isFinal: boolean; 0: SRAlternative; length: number }
interface SREvent { resultIndex: number; results: ArrayLike<SRResult> }
interface SRErrorEvent { error: string }
interface SRInstance {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((e: SREvent) => void) | null;
  onerror: ((e: SRErrorEvent) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
}
type SRCtor = new () => SRInstance;

function getRecognitionCtor(): SRCtor | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as { SpeechRecognition?: SRCtor; webkitSpeechRecognition?: SRCtor };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

export type SpeechProblem = "not-allowed" | "no-mic" | "network" | "no-speech" | "unsupported" | "other";

export const PROBLEM_TEXT: Record<SpeechProblem, string> = {
  "not-allowed": "Microphone access is blocked. Allow the microphone in your browser, or type your answer instead.",
  "no-mic": "No microphone was found. You can type your answer instead.",
  network: "The browser's speech service could not be reached. You can type your answer instead.",
  "no-speech": "I did not hear anything. Tap the microphone to try again, or type your answer.",
  unsupported: "This browser cannot turn speech into text. Please type your answers (Chrome, Edge or Safari support voice).",
  other: "The microphone stopped unexpectedly. Tap it to try again, or type your answer.",
};

/** Split long text into sentences: Chrome silently stops speaking after ~15 s of one utterance. */
export function splitForSpeech(text: string): string[] {
  const parts = text.replace(/\s+/g, " ").trim().match(/[^.!?]+[.!?]+["')\]]*|[^.!?]+$/g) ?? [];
  const out: string[] = [];
  let cur = "";
  for (const p of parts.map((s) => s.trim()).filter(Boolean)) {
    if ((cur + " " + p).trim().length > 180 && cur) {
      out.push(cur);
      cur = p;
    } else {
      cur = (cur + " " + p).trim();
    }
  }
  if (cur) out.push(cur);
  return out;
}

interface Options {
  lang: string;
  /** Called once when the candidate has been quiet for a while after saying something. */
  onSilence?: (text: string) => void;
  silenceMs?: number;
}

export function useSpeech({ lang, onSilence, silenceMs = 2200 }: Options) {
  const [sttSupported, setSttSupported] = useState(false);
  const [ttsSupported, setTtsSupported] = useState(false);
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [liveText, setLiveText] = useState(""); // final + interim words of the current recording
  const [problem, setProblem] = useState<SpeechProblem | null>(null);

  const recRef = useRef<SRInstance | null>(null);
  const wantListening = useRef(false);
  const finalRef = useRef("");
  const interimRef = useRef("");
  const silenceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const onSilenceRef = useRef(onSilence);
  const speakToken = useRef(0);
  const restarts = useRef(0);

  useEffect(() => {
    onSilenceRef.current = onSilence;
  }, [onSilence]);

  useEffect(() => {
    // Feature detection can only happen in the browser.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setSttSupported(!!getRecognitionCtor());
    setTtsSupported(typeof window !== "undefined" && "speechSynthesis" in window);
  }, []);

  const clearSilence = () => {
    if (silenceTimer.current) clearTimeout(silenceTimer.current);
    silenceTimer.current = null;
  };

  const currentText = () => `${finalRef.current} ${interimRef.current}`.replace(/\s+/g, " ").trim();

  /* ------------------------------------------------------------ speaking */
  const stopSpeaking = useCallback(() => {
    speakToken.current += 1;
    if (typeof window !== "undefined" && "speechSynthesis" in window) window.speechSynthesis.cancel();
    setSpeaking(false);
  }, []);

  const speak = useCallback(
    (text: string): Promise<void> => {
      return new Promise((resolve) => {
        if (typeof window === "undefined" || !("speechSynthesis" in window)) return resolve();
        const synth = window.speechSynthesis;
        try {
          synth.cancel();
        } catch {
          /* ignore */
        }
        const token = ++speakToken.current;
        const chunks = splitForSpeech(text);
        if (!chunks.length) return resolve();
        setSpeaking(true);

        const finish = () => {
          if (speakToken.current === token) setSpeaking(false);
          resolve();
        };
        const next = (i: number) => {
          if (speakToken.current !== token) return resolve(); // cancelled by something newer
          if (i >= chunks.length) return finish();
          let done = false;
          const go = () => {
            if (done) return;
            done = true;
            clearTimeout(guard);
            next(i + 1);
          };
          // onend sometimes never fires; this timer moves on anyway.
          const guard = setTimeout(go, Math.max(3000, chunks[i].length * 120));
          try {
            const u = new SpeechSynthesisUtterance(chunks[i]);
            u.lang = lang;
            u.rate = 1;
            u.onend = go;
            u.onerror = go;
            synth.speak(u);
          } catch {
            // Speaking is a nicety: if the browser refuses, the question is still on screen.
            go();
          }
        };
        next(0);
      });
    },
    [lang],
  );

  /* ------------------------------------------------------------ listening */
  const armSilence = () => {
    clearSilence();
    if (!onSilenceRef.current) return;
    silenceTimer.current = setTimeout(() => {
      const text = currentText();
      if (text && wantListening.current) onSilenceRef.current?.(text);
    }, silenceMs);
  };

  const startRecognition = useCallback(() => {
    const Ctor = getRecognitionCtor();
    if (!Ctor) {
      setProblem("unsupported");
      return;
    }
    const rec = new Ctor();
    rec.lang = lang;
    rec.continuous = true;
    rec.interimResults = true;
    rec.onresult = (e) => {
      let interim = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const r = e.results[i];
        if (r.isFinal) finalRef.current = `${finalRef.current} ${r[0].transcript}`.trim();
        else interim += r[0].transcript;
      }
      interimRef.current = interim;
      restarts.current = 0;
      setLiveText(currentText());
      armSilence();
    };
    rec.onerror = (e) => {
      if (e.error === "not-allowed" || e.error === "service-not-allowed") setProblem("not-allowed");
      else if (e.error === "audio-capture") setProblem("no-mic");
      else if (e.error === "network") setProblem("network");
      else if (e.error === "no-speech") setProblem("no-speech");
      else if (e.error !== "aborted") setProblem("other");
      if (e.error !== "no-speech" && e.error !== "aborted") wantListening.current = false;
    };
    rec.onend = () => {
      // Browsers end recognition on their own after a pause. Restart while we still want it.
      if (wantListening.current && restarts.current < 8) {
        restarts.current += 1;
        try {
          startRecognition();
          return;
        } catch {
          /* fall through */
        }
      }
      if (wantListening.current) setProblem((p) => p ?? "no-speech");
      wantListening.current = false;
      clearSilence();
      setListening(false);
    };
    recRef.current = rec;
    try {
      rec.start();
      setListening(true);
    } catch {
      setProblem("other");
      wantListening.current = false;
      setListening(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lang, silenceMs]);

  const startListening = useCallback(() => {
    stopSpeaking(); // never listen while the interviewer is talking
    setProblem(null);
    finalRef.current = "";
    interimRef.current = "";
    restarts.current = 0;
    setLiveText("");
    wantListening.current = true;
    startRecognition();
  }, [startRecognition, stopSpeaking]);

  /** Stops the microphone and returns everything that was heard. */
  const stopListening = useCallback((): string => {
    wantListening.current = false;
    clearSilence();
    const text = currentText();
    const rec = recRef.current;
    recRef.current = null;
    if (rec) {
      rec.onend = null;
      rec.onresult = null;
      rec.onerror = null;
      try {
        rec.stop();
      } catch {
        /* already stopped */
      }
    }
    setListening(false);
    return text;
  }, []);

  useEffect(
    () => () => {
      wantListening.current = false;
      clearSilence();
      try {
        recRef.current?.abort();
      } catch {
        /* ignore */
      }
      if (typeof window !== "undefined" && "speechSynthesis" in window) window.speechSynthesis.cancel();
    },
    [],
  );

  return {
    sttSupported,
    ttsSupported,
    listening,
    speaking,
    liveText,
    problem,
    clearProblem: () => setProblem(null),
    speak,
    stopSpeaking,
    startListening,
    stopListening,
  };
}
