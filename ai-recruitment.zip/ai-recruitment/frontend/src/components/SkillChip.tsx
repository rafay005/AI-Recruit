import { Check, X } from "lucide-react";
import type { SkillMatch } from "@/types/ranking";

const styles = {
  match: "bg-emerald-50 text-emerald-800 ring-emerald-300",
  related: "bg-amber-50 text-amber-800 ring-amber-300",
  missing: "bg-red-50 text-red-700 ring-red-200",
};

const words = {
  match: "has",
  related: "has a similar skill for",
  missing: "does not have",
};

export default function SkillChip({ item }: { item: SkillMatch }) {
  return (
    <li
      title={item.status === "related" && item.via ? `Has ${item.via}` : undefined}
      className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-xs font-medium ring-1 ring-inset ${styles[item.status]}`}
    >
      {item.status === "match" && <Check size={12} aria-hidden />}
      {item.status === "missing" && <X size={12} aria-hidden />}
      {item.status === "related" && <span aria-hidden>≈</span>}
      <span className="sr-only">Candidate {words[item.status]}</span>
      {item.skill}
    </li>
  );
}
