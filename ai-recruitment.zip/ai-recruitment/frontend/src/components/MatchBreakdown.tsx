import { Check, X } from "lucide-react";
import type { MatchBreakdown as Match, SkillsBlock } from "@/types/ranking";

export function ScoreBar({ percent }: { percent: number }) {
  return (
    <div
      role="meter"
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={percent}
      aria-label={`${percent} percent match`}
      className="h-2.5 w-full overflow-hidden rounded-full bg-maroon-100"
    >
      <div className="h-full rounded-full bg-maroon-700" style={{ width: `${percent}%` }} />
    </div>
  );
}

function Mark({ kind }: { kind: "yes" | "partial" | "no" | "unknown" }) {
  if (kind === "yes")
    return (
      <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-emerald-100 text-emerald-700">
        <Check size={14} aria-label="Yes" />
      </span>
    );
  if (kind === "no")
    return (
      <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-red-100 text-red-700">
        <X size={14} aria-label="No" />
      </span>
    );
  return (
    <span
      className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-amber-100 text-sm font-semibold text-amber-800"
      aria-label={kind === "partial" ? "Partly" : "Not found in the CV"}
    >
      {kind === "partial" ? "≈" : "?"}
    </span>
  );
}

function SkillList({ title, block }: { title: string; block: SkillsBlock }) {
  return (
    <section>
      <div className="mb-3 flex items-baseline justify-between">
        <h3 className="font-display text-lg font-semibold text-maroon-900">{title}</h3>
        <p className="text-sm text-muted">
          {block.matched} of {block.total}
          {block.related > 0 ? `, plus ${block.related} similar` : ""}
        </p>
      </div>
      <ul className="divide-y divide-line rounded-xl border border-line bg-white">
        {block.items.map((i) => (
          <li key={i.skill} className="px-4 py-2.5">
            <div className="flex items-center gap-3">
              <Mark kind={i.status === "match" ? "yes" : i.status === "related" ? "partial" : "no"} />
              <span className="font-medium">{i.skill}</span>
              {i.method === "meaning" && (
                <span className="rounded-full bg-maroon-50 px-2 py-0.5 text-[11px] font-medium text-maroon-800">
                  matched by meaning
                </span>
              )}
              <span className="ml-auto text-right text-xs text-muted">
                {i.status === "match" && i.evidence}
                {i.status === "related" && (i.via ? `Similar: has ${i.via}` : "Related experience")}
                {i.status === "missing" && "Not found in the CV"}
              </span>
            </div>
            {i.snippet && i.status !== "missing" && (
              <p className="mt-1 pl-9 text-xs leading-relaxed text-muted">
                “{i.snippet}”{i.source ? ` · ${i.source}` : ""}
              </p>
            )}
          </li>
        ))}
      </ul>
    </section>
  );
}

const PART_NAMES: Record<string, string> = {
  required: "Required skills",
  relevance: "Role relevance",
  nice_to_have: "Nice-to-have skills",
  experience: "Experience",
  education: "Education",
};

function Relevance({ block }: { block: NonNullable<Match["relevance"]> }) {
  return (
    <section>
      <div className="mb-3 flex items-baseline justify-between">
        <h3 className="font-display text-lg font-semibold text-maroon-900">Role relevance</h3>
        <p className="text-sm text-muted">{Math.round((block.score ?? 0) * 100)}%</p>
      </div>
      <p className="mb-3 text-xs text-muted">
        How closely the candidate&apos;s actual work matches what this job involves, compared by meaning.
      </p>
      <ul className="divide-y divide-line rounded-xl border border-line bg-white">
        {block.items.map((r) => (
          <li key={r.text} className="px-4 py-2.5">
            <div className="flex items-center gap-3">
              <Mark kind={r.status === "strong" ? "yes" : r.status === "partial" ? "partial" : "no"} />
              <span className="text-sm">{r.text}</span>
            </div>
            {r.snippet && (
              <p className="mt-1 pl-9 text-xs leading-relaxed text-muted">
                “{r.snippet}”{r.source ? ` · ${r.source}` : ""}
              </p>
            )}
          </li>
        ))}
      </ul>
    </section>
  );
}

export default function MatchBreakdown({ match, jobTitle }: { match: Match; jobTitle?: string }) {
  const { experience: ex, education: ed } = match;

  const partScore: Record<string, number | null> = {
    required: match.required.score,
    relevance: match.relevance?.score ?? null,
    nice_to_have: match.nice_to_have?.score ?? null,
    experience: ex.score,
    education: ed.score,
  };

  return (
    <div className="space-y-7">
      <div>
        <div className="mb-2 flex flex-wrap items-end justify-between gap-2">
          <p className="text-sm text-muted">Overall match{jobTitle ? ` with ${jobTitle}` : ""}</p>
          <p className="text-sm font-medium text-maroon-800">{match.label}</p>
        </div>
        <p className="mb-3 font-display text-5xl font-semibold leading-none text-maroon-900">
          {match.overall}%
        </p>
        <ScoreBar percent={match.overall} />
      </div>

      <SkillList title="Required skills" block={match.required} />
      {match.relevance?.applicable && <Relevance block={match.relevance} />}
      {match.nice_to_have && <SkillList title="Nice to have" block={match.nice_to_have} />}

      {(ex.applicable || ed.applicable) && (
        <section className="grid gap-3 sm:grid-cols-2">
          {ex.applicable && (
            <div className="flex items-start gap-3 rounded-xl border border-line bg-white p-4">
              <Mark kind={ex.status === "meets" ? "yes" : ex.status === "below" ? "no" : "unknown"} />
              <div>
                <p className="font-medium">
                  Experience:{" "}
                  {ex.candidate_years !== null
                    ? `${ex.candidate_years} ${ex.candidate_years === 1 ? "year" : "years"}`
                    : "not found in the CV"}
                </p>
                <p className="text-sm text-muted">
                  Needs{" "}
                  {ex.required_min !== null && ex.required_max !== null
                    ? `${ex.required_min} to ${ex.required_max} years`
                    : ex.required_min !== null
                      ? `${ex.required_min}+ years`
                      : `up to ${ex.required_max} years`}
                </p>
              </div>
            </div>
          )}
          {ed.applicable && (
            <div className="flex items-start gap-3 rounded-xl border border-line bg-white p-4">
              <Mark kind={ed.status === "meets" ? "yes" : ed.status === "below" ? "no" : "unknown"} />
              <div>
                <p className="font-medium">Education: {ed.candidate ?? "not found in the CV"}</p>
                <p className="text-sm text-muted">Needs a {ed.required}</p>
              </div>
            </div>
          )}
        </section>
      )}

      <section>
        <h3 className="mb-3 font-display text-lg font-semibold text-maroon-900">How this score is built</h3>
        <ul className="space-y-2.5">
          {Object.entries(match.weights).map(([key, weight]) => {
            const s = partScore[key];
            const pct = s === null ? 0 : Math.round(s * 100);
            return (
              <li key={key} className="grid grid-cols-[7.5rem_1fr_9rem] items-center gap-3 text-sm">
                <span>{PART_NAMES[key] ?? key}</span>
                <ScoreBar percent={pct} />
                <span className="whitespace-nowrap text-right text-xs text-muted">
                  {pct}% × {Math.round(weight)}% weight
                </span>
              </li>
            );
          })}
        </ul>
        <p className="mt-3 text-xs leading-relaxed text-muted">
          {match.search_mode === "hybrid"
            ? "Hybrid search: each requirement is checked by keywords and by meaning, so a CV that says “edited YouTube videos” counts for “video editing”. A named tool needs to be on the CV itself; a similar one (for example Flask for FastAPI) counts as half. "
            : "Keyword search only (the meaning model is not available). A similar skill (for example MySQL for PostgreSQL) counts as half. "}
          Names, gender, age and university are never used. Automatic reading can make mistakes, so check the CV
          before deciding.
        </p>
      </section>
    </div>
  );
}
