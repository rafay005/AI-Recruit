import type { JobStatus } from "@/types/job";

const styles: Record<JobStatus, string> = {
  draft: "bg-stone-100 text-stone-700 ring-stone-300",
  approved: "bg-amber-50 text-amber-800 ring-amber-300",
  published: "bg-emerald-50 text-emerald-800 ring-emerald-300",
};

const dots: Record<JobStatus, string> = {
  draft: "bg-stone-400",
  approved: "bg-amber-500",
  published: "bg-emerald-500",
};

const labels: Record<JobStatus, string> = {
  draft: "Draft",
  approved: "Approved",
  published: "Published",
};

export default function StatusBadge({ status }: { status: JobStatus }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset ${styles[status]}`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${dots[status]}`} />
      {labels[status]}
    </span>
  );
}
