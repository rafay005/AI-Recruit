import { Award, Briefcase, FolderGit2, GraduationCap, Sparkles } from "lucide-react";
import type { ExtractedCV } from "@/types/application";

function Section({
  title,
  icon: Icon,
  empty,
  children,
}: {
  title: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  empty: boolean;
  children: React.ReactNode;
}) {
  return (
    <section>
      <h3 className="mb-3 flex items-center gap-2 font-display text-lg font-semibold text-maroon-900">
        <Icon size={18} className="text-maroon-600" /> {title}
      </h3>
      {empty ? <p className="text-sm text-muted">Nothing found in the CV.</p> : children}
    </section>
  );
}

const range = (a: string | null, b: string | null) =>
  a && b ? `${a} to ${b}` : (a ?? b ?? "");

export default function CVDetails({ data }: { data: ExtractedCV }) {
  return (
    <div className="space-y-8">
      {data.summary && <p className="leading-relaxed">{data.summary}</p>}

      <Section title="Skills" icon={Sparkles} empty={data.skills.length === 0}>
        <ul className="flex flex-wrap gap-1.5">
          {data.skills.map((s) => (
            <li
              key={s}
              className="rounded-md bg-maroon-50 px-2 py-0.5 text-sm text-maroon-800 ring-1 ring-inset ring-maroon-200"
            >
              {s}
            </li>
          ))}
        </ul>
      </Section>

      <Section title="Experience" icon={Briefcase} empty={data.experience.length === 0}>
        <ul className="space-y-5">
          {data.experience.map((e, i) => (
            <li key={i} className="border-l-2 border-maroon-200 pl-4">
              <p className="font-medium">{e.title ?? e.company}</p>
              <p className="text-sm text-muted">
                {[e.title ? e.company : null, range(e.start, e.end)].filter(Boolean).join(", ")}
              </p>
              {e.description && (
                <p className="mt-2 whitespace-pre-line text-sm leading-relaxed">{e.description}</p>
              )}
            </li>
          ))}
        </ul>
      </Section>

      <Section title="Education" icon={GraduationCap} empty={data.education.length === 0}>
        <ul className="space-y-4">
          {data.education.map((e, i) => (
            <li key={i} className="border-l-2 border-maroon-200 pl-4">
              <p className="font-medium">
                {[e.degree, e.field].filter(Boolean).join(" in ") || e.institution}
              </p>
              <p className="text-sm text-muted">
                {[e.degree || e.field ? e.institution : null, range(e.start, e.end), e.grade ? `Grade ${e.grade}` : null]
                  .filter(Boolean)
                  .join(", ")}
              </p>
            </li>
          ))}
        </ul>
      </Section>

      <Section title="Projects" icon={FolderGit2} empty={data.projects.length === 0}>
        <ul className="space-y-4">
          {data.projects.map((p, i) => (
            <li key={i} className="border-l-2 border-maroon-200 pl-4">
              <p className="font-medium">{p.name}</p>
              {p.description && (
                <p className="mt-1 whitespace-pre-line text-sm leading-relaxed">{p.description}</p>
              )}
              {p.technologies.length > 0 && (
                <ul className="mt-2 flex flex-wrap gap-1.5">
                  {p.technologies.map((t) => (
                    <li key={t} className="rounded-md bg-stone-100 px-2 py-0.5 text-xs text-stone-700">
                      {t}
                    </li>
                  ))}
                </ul>
              )}
            </li>
          ))}
        </ul>
      </Section>

      <Section title="Certifications" icon={Award} empty={data.certifications.length === 0}>
        <ul className="space-y-2">
          {data.certifications.map((c, i) => (
            <li key={i} className="border-l-2 border-maroon-200 pl-4">
              <p className="font-medium">{c.name}</p>
              <p className="text-sm text-muted">
                {[c.issuer, c.date].filter(Boolean).join(", ")}
              </p>
            </li>
          ))}
        </ul>
      </Section>
    </div>
  );
}
