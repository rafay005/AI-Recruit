import { Building2, Laptop, MapPin, Clock } from "lucide-react";
import {
  EMPLOYMENT_TYPES,
  WORK_MODES,
  labelOf,
} from "@/types/job";

interface Props {
  company?: string | null;
  department?: string | null;
  location?: string | null;
  employmentType: string;
  workMode: string;
}

/** Icon + text meta line for a job (no dotted strings). */
export default function JobMeta({
  company,
  department,
  location,
  employmentType,
  workMode,
}: Props) {
  const items = [
    { icon: Building2, text: company || department },
    { icon: MapPin, text: location },
    { icon: Clock, text: labelOf(EMPLOYMENT_TYPES, employmentType) },
    { icon: Laptop, text: labelOf(WORK_MODES, workMode) },
  ].filter((i) => i.text);

  return (
    <ul className="flex flex-wrap gap-x-5 gap-y-1 text-sm text-muted">
      {items.map(({ icon: Icon, text }) => (
        <li key={text} className="flex items-center gap-1.5">
          <Icon size={14} className="text-maroon-500" />
          {text}
        </li>
      ))}
    </ul>
  );
}
