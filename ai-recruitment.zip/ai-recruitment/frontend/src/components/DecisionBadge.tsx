import { DECISIONS, type Decision } from "@/types/application";

const styles: Record<Decision, string> = {
  under_review: "bg-stone-100 text-stone-700 ring-stone-300",
  shortlisted: "bg-maroon-50 text-maroon-800 ring-maroon-300",
  interview: "bg-maroon-700 text-white ring-maroon-700",
  rejected: "bg-red-50 text-red-800 ring-red-300",
  hired: "bg-emerald-50 text-emerald-800 ring-emerald-300",
};

export default function DecisionBadge({
  decision,
  audience = "hr",
}: {
  decision: Decision;
  audience?: "hr" | "candidate";
}) {
  const label = DECISIONS.find((d) => d.value === decision)?.[audience] ?? decision;
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ring-inset ${styles[decision]}`}
    >
      {label}
    </span>
  );
}
