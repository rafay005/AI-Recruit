"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Activity, BarChart3, Briefcase, KanbanSquare, LayoutDashboard, Users } from "lucide-react";

const nav = [
  { href: "/hr/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/hr/jobs", label: "Jobs", icon: Briefcase },
  { href: "/hr/candidates", label: "Candidates", icon: Users },
  { href: "/hr/pipeline", label: "Pipeline", icon: KanbanSquare },
  { href: "/hr/analytics", label: "Analytics", icon: BarChart3 },
  { href: "/hr/activity", label: "Activity", icon: Activity },
];

export default function HRNav() {
  const pathname = usePathname();
  return (
    <nav aria-label="Main" className="flex gap-1 overflow-x-auto md:flex-col md:overflow-visible">
      {nav.map(({ href, label, icon: Icon }) => {
        const active = pathname === href || pathname.startsWith(href + "/");
        return (
          <Link
            key={href}
            href={href}
            aria-current={active ? "page" : undefined}
            className={`flex shrink-0 items-center gap-3 rounded-lg px-3.5 py-2.5 text-sm font-medium transition ${
              active
                ? "bg-white text-maroon-800 shadow-sm"
                : "text-maroon-100 hover:bg-white/10 hover:text-white"
            }`}
          >
            <Icon size={18} />
            {label}
          </Link>
        );
      })}
    </nav>
  );
}
