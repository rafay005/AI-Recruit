import BrandMark from "@/components/BrandMark";

const points = [
  "Write a job once and let AI draft the description",
  "Review, approve and publish in minutes",
  "Rank candidates and interview with AI support",
];

export default function AuthShell({ children }: { children: React.ReactNode }) {
  return (
    <main className="grid min-h-screen lg:grid-cols-[1.05fr_1fr]">
      <section className="relative hidden flex-col justify-between overflow-hidden bg-maroon-900 p-12 text-white lg:flex">
        <div
          aria-hidden
          className="pointer-events-none absolute -right-24 -top-24 h-96 w-96 rounded-full bg-maroon-700/60"
        />
        <div
          aria-hidden
          className="pointer-events-none absolute -bottom-32 -left-20 h-96 w-96 rounded-full bg-maroon-950/70"
        />
        <div className="relative">
          <BrandMark />
        </div>
        <div className="relative max-w-md">
          <h2 className="font-display text-4xl font-semibold leading-tight">
            From job post to hiring decision, in one place.
          </h2>
          <ul className="mt-8 space-y-4 text-maroon-100">
            {points.map((p) => (
              <li key={p} className="flex gap-3">
                <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-white" />
                {p}
              </li>
            ))}
          </ul>
        </div>
        <p className="relative text-sm text-maroon-200/80">AI-assisted recruitment platform</p>
      </section>

      <section className="flex items-center justify-center bg-white p-6 sm:p-12">
        <div className="w-full max-w-sm">
          <div className="mb-10 lg:hidden">
            <BrandMark tone="dark" />
          </div>
          {children}
        </div>
      </section>
    </main>
  );
}
