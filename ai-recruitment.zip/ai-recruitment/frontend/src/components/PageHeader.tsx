interface Props {
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
}

export default function PageHeader({ title, subtitle, actions }: Props) {
  return (
    <header className="mb-8 flex flex-wrap items-start justify-between gap-4">
      <div>
        <h1 className="font-display text-3xl font-semibold tracking-tight text-maroon-900">
          {title}
        </h1>
        {subtitle && <p className="mt-1.5 max-w-xl text-muted">{subtitle}</p>}
      </div>
      {actions}
    </header>
  );
}
