"use client";

import { useEffect, useMemo, useState } from "react";
import { Bot, CheckCircle2, Mail, Play, XCircle, Clock, Trophy, UserCheck } from "lucide-react";
import { api, errorMessage } from "@/lib/api";
import { C, Histogram } from "@/components/dashboard/charts";

interface AutoEvent {
  id: number;
  action: string;
  score: number | null;
  threshold: number | null;
  detail: string | null;
  candidate_name: string | null;
  created_at: string;
}

interface Automation {
  enabled: boolean;
  cv_threshold: number;
  interview_threshold: number;
  reject_below_cv: boolean;
  questions: number;
  openings: number;
  selected: number;
  email_enabled: boolean;
  cv_scores: number[];
  interview_scores: number[];
  pending_review: number;
  events: AutoEvent[];
  last_run: Record<string, number> | null;
}

const ACTION: Record<string, { label: string; icon: typeof Bot; tone: string }> = {
  invited: { label: "Invited to interview", icon: UserCheck, tone: "text-maroon-700 bg-maroon-50" },
  cv_rejected: { label: "Rejected at CV stage", icon: XCircle, tone: "text-red-700 bg-red-50" },
  cv_held: { label: "Held for HR review", icon: Clock, tone: "text-amber-800 bg-amber-50" },
  selected: { label: "Selected", icon: Trophy, tone: "text-emerald-700 bg-emerald-50" },
  interview_rejected: { label: "Rejected after interview", icon: XCircle, tone: "text-red-700 bg-red-50" },
  openings_full: { label: "Passed, openings full", icon: CheckCircle2, tone: "text-stone-700 bg-stone-100" },
  manual_move: { label: "Moved by HR on the pipeline board", icon: UserCheck, tone: "text-violet-700 bg-violet-50" },
};

function hist(values: number[]) {
  const b = Array.from({ length: 10 }, (_, i) => ({ from: i * 10, to: i === 9 ? 100 : i * 10 + 9, count: 0 }));
  values.forEach((v) => (b[Math.min(9, Math.floor(v / 10))].count += 1));
  return b;
}

function ago(s: string) {
  const d = (Date.now() - new Date(s).getTime()) / 1000;
  if (d < 60) return "just now";
  if (d < 3600) return `${Math.floor(d / 60)} min ago`;
  if (d < 86400) return `${Math.floor(d / 3600)} h ago`;
  return new Date(s).toLocaleDateString();
}

export default function AutomationPanel({ jobId }: { jobId: number | string }) {
  const [a, setA] = useState<Automation | null>(null);
  const [form, setForm] = useState({ enabled: false, cv_threshold: 60, interview_threshold: 65, reject_below_cv: true, questions: 5 });
  const [busy, setBusy] = useState<"save" | "run" | null>(null);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  function load(d: Automation) {
    setA(d);
    setForm({ enabled: d.enabled, cv_threshold: d.cv_threshold, interview_threshold: d.interview_threshold,
              reject_below_cv: d.reject_below_cv, questions: d.questions });
  }

  useEffect(() => {
    api.get<Automation>(`/api/hr/jobs/${jobId}/automation`).then((r) => load(r.data))
      .catch((e) => setMsg({ ok: false, text: errorMessage(e, "Could not load automation settings") }));
  }, [jobId]);

  const preview = useMemo(() => {
    const s = a?.cv_scores ?? [];
    const pass = s.filter((v) => v >= form.cv_threshold).length;
    const ivs = a?.interview_scores ?? [];
    return { pass, fail: s.length - pass, total: s.length, ivPass: ivs.filter((v) => v >= form.interview_threshold).length, ivTotal: ivs.length };
  }, [a, form.cv_threshold, form.interview_threshold]);

  function summary(r: Record<string, number> | null) {
    if (!r) return "Settings saved.";
    const parts = [
      r.invited && `${r.invited} invited`, r.cv_rejected && `${r.cv_rejected} rejected at CV stage`,
      r.cv_held && `${r.cv_held} held for review`, r.selected && `${r.selected} selected`,
      r.interview_rejected && `${r.interview_rejected} rejected after interview`, r.openings_full && `${r.openings_full} passed with openings full`,
    ].filter(Boolean);
    return parts.length ? `Automation ran: ${parts.join(", ")}.` : "Automation is on. Nobody was waiting, so nothing changed yet.";
  }

  async function save() {
    if (form.enabled && !a?.enabled && preview.total > 0 &&
        !window.confirm(`Turn on automation? It will act on the ${a?.pending_review ?? 0} candidate(s) still under review right now, then on every new application.`)) return;
    setBusy("save"); setMsg(null);
    try {
      const r = await api.put<Automation>(`/api/hr/jobs/${jobId}/automation`, form);
      load(r.data);
      setMsg({ ok: true, text: form.enabled ? summary(r.data.last_run) : "Automation is off. Candidates wait for your decision." });
    } catch (e) {
      setMsg({ ok: false, text: errorMessage(e, "Could not save") });
    } finally { setBusy(null); }
  }

  async function run() {
    setBusy("run"); setMsg(null);
    try {
      const r = await api.post<Automation>(`/api/hr/jobs/${jobId}/automation/run`);
      load(r.data);
      setMsg({ ok: true, text: summary(r.data.last_run) });
    } catch (e) {
      setMsg({ ok: false, text: errorMessage(e, "Could not run") });
    } finally { setBusy(null); }
  }

  if (!a) return msg ? <p className="text-sm text-red-700">{msg.text}</p> : null;
  const dirty = form.enabled !== a.enabled || form.cv_threshold !== a.cv_threshold || form.interview_threshold !== a.interview_threshold
    || form.reject_below_cv !== a.reject_below_cv || form.questions !== a.questions;

  return (
    <section className="mb-6 overflow-hidden rounded-2xl border border-line bg-white">
      <div className="flex flex-wrap items-center gap-4 border-b border-line bg-gradient-to-r from-maroon-900 to-maroon-700 px-6 py-5 text-white sm:px-7">
        <span className="grid h-11 w-11 place-items-center rounded-xl bg-white/15"><Bot size={22} /></span>
        <div className="min-w-0 flex-1">
          <h2 className="font-display text-xl font-semibold">Hands-free hiring</h2>
          <p className="text-sm text-maroon-100">
            CV above the threshold: interview invite. Interview above the threshold: selected, first come first served
            until {a.openings} {a.openings === 1 ? "opening is" : "openings are"} filled.
          </p>
        </div>
        <label className="flex cursor-pointer items-center gap-3">
          <span className="text-sm font-medium">{form.enabled ? "On" : "Off"}</span>
          <button type="button" role="switch" aria-checked={form.enabled} aria-label="Automation"
                  onClick={() => setForm({ ...form, enabled: !form.enabled })}
                  className={`relative h-7 w-12 rounded-full transition ${form.enabled ? "bg-emerald-500" : "bg-white/30"}`}>
            <span className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-all ${form.enabled ? "left-6" : "left-1"}`} />
          </button>
        </label>
      </div>

      <div className="grid gap-6 p-6 sm:p-7 lg:grid-cols-2">
        {/* CV stage */}
        <div className="rounded-xl border border-line p-5">
          <div className="mb-1 flex items-baseline justify-between">
            <h3 className="font-semibold text-maroon-900">1 · CV match threshold</h3>
            <span className="font-display text-3xl font-semibold text-maroon-900">{form.cv_threshold}%</span>
          </div>
          <input type="range" min={0} max={100} step={1} value={form.cv_threshold} aria-label="CV match threshold"
                 onChange={(e) => setForm({ ...form, cv_threshold: +e.target.value })} className="w-full accent-maroon-700" />
          <Histogram buckets={hist(a.cv_scores)} threshold={form.cv_threshold} label="CV match scores of current applicants" />
          <p className="mt-2 text-sm">
            {preview.total === 0 ? <span className="text-muted">No analysed CVs yet.</span> : (
              <><b className="text-emerald-700">{preview.pass}</b> of {preview.total} current applicants would be invited,{" "}
                <b className="text-red-700">{preview.fail}</b> {form.reject_below_cv ? "rejected" : "held for review"}.</>
            )}
          </p>
          <label className="mt-3 flex items-center gap-2 text-sm">
            <input type="checkbox" checked={form.reject_below_cv} onChange={(e) => setForm({ ...form, reject_below_cv: e.target.checked })}
                   className="h-4 w-4 accent-maroon-700" />
            Reject CVs below the threshold automatically (off: they wait for you)
          </label>
          <label className="mt-2 flex items-center gap-2 text-sm">
            Interview length
            <select value={form.questions} onChange={(e) => setForm({ ...form, questions: +e.target.value })}
                    className="rounded-md border border-line px-2 py-1 text-sm">
              {[3, 4, 5, 6, 7, 8].map((n) => <option key={n} value={n}>{n} questions</option>)}
            </select>
          </label>
        </div>

        {/* Interview stage */}
        <div className="rounded-xl border border-line p-5">
          <div className="mb-1 flex items-baseline justify-between">
            <h3 className="font-semibold text-maroon-900">2 · Interview score threshold</h3>
            <span className="font-display text-3xl font-semibold text-maroon-900">{form.interview_threshold}</span>
          </div>
          <input type="range" min={0} max={100} step={1} value={form.interview_threshold} aria-label="Interview score threshold"
                 onChange={(e) => setForm({ ...form, interview_threshold: +e.target.value })} className="w-full accent-maroon-700" />
          <Histogram buckets={hist(a.interview_scores)} threshold={form.interview_threshold} color={C.s2} label="Interview scores so far" unit="" />
          <p className="mt-2 text-sm">
            {preview.ivTotal === 0 ? <span className="text-muted">No evaluated interviews yet.</span> : (
              <><b className="text-emerald-700">{preview.ivPass}</b> of {preview.ivTotal} interviews so far score at or above it.</>
            )}
          </p>
          <div className="mt-3 flex items-center gap-3 rounded-lg bg-canvas p-3 text-sm">
            <Trophy size={18} className="text-maroon-700" />
            <span><b>{a.selected}</b> of <b>{a.openings}</b> {a.openings === 1 ? "opening" : "openings"} filled</span>
            <div className="ml-auto h-2 w-28 overflow-hidden rounded-full bg-maroon-100">
              <div className="h-full rounded-full bg-emerald-600" style={{ width: `${Math.min(100, (100 * a.selected) / Math.max(1, a.openings))}%` }} />
            </div>
          </div>
          <p className="mt-3 flex items-center gap-2 text-xs text-muted">
            <Mail size={14} />
            {a.email_enabled ? "Candidates are emailed and see the update in their portal."
              : "Candidates see invitations and decisions in their portal. Add SMTP settings to also email them."}
          </p>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-3 border-t border-line px-6 py-4 sm:px-7">
        <button onClick={save} disabled={busy !== null || !dirty}
                className="rounded-lg bg-maroon-700 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-maroon-800 disabled:opacity-50">
          {busy === "save" ? "Saving..." : "Save automation"}
        </button>
        {a.enabled && (
          <button onClick={run} disabled={busy !== null}
                  className="flex items-center gap-2 rounded-lg border border-maroon-700 px-4 py-2.5 text-sm font-semibold text-maroon-700 hover:bg-maroon-50 disabled:opacity-50">
            <Play size={15} /> {busy === "run" ? "Running..." : "Run now"}
          </button>
        )}
        {msg && <p role="status" className={`text-sm ${msg.ok ? "text-emerald-700" : "text-red-700"}`}>{msg.text}</p>}
        <p className="ml-auto text-xs text-muted">Decisions you make by hand are never overridden.</p>
      </div>

      {a.events.length > 0 && (
        <div className="border-t border-line px-6 py-5 sm:px-7">
          <h3 className="mb-3 text-sm font-semibold text-maroon-900">Automation log</h3>
          <ul className="max-h-72 space-y-2 overflow-y-auto pr-1">
            {a.events.map((e) => {
              const m = ACTION[e.action] ?? { label: e.action, icon: Bot, tone: "bg-stone-100 text-stone-700" };
              const Icon = m.icon;
              return (
                <li key={e.id} className="flex items-start gap-3 text-sm">
                  <span className={`mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-lg ${m.tone}`}><Icon size={15} /></span>
                  <div className="min-w-0 flex-1">
                    <p><b>{e.candidate_name ?? "Candidate"}</b> · {m.label}</p>
                    {e.detail && <p className="text-xs text-muted">{e.detail}</p>}
                  </div>
                  <span className="shrink-0 text-xs text-muted">{ago(e.created_at)}</span>
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </section>
  );
}
