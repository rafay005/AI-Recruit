import { Loader2 } from "lucide-react";
import type { AnalysisStatus } from "@/types/application";

const styles: Record<AnalysisStatus, string> = {
  pending: "bg-stone-100 text-stone-700 ring-stone-300",
  processing: "bg-amber-50 text-amber-800 ring-amber-300",
  done: "bg-emerald-50 text-emerald-800 ring-emerald-300",
  failed: "bg-red-50 text-red-800 ring-red-300",
};

const labels: Record<AnalysisStatus, string> = {
  pending: "Queued",
  processing: "Reading CV",
  done: "CV analysed",
  failed: "Needs attention",
};

export default function AnalysisBadge({ status }: { status: AnalysisStatus }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset ${styles[status]}`}
    >
      {status === "processing" || status === "pending" ? (
        <Loader2 size={12} className="animate-spin motion-reduce:animate-none" />
      ) : (
        <span
          className={`h-1.5 w-1.5 rounded-full ${status === "done" ? "bg-emerald-500" : "bg-red-500"}`}
        />
      )}
      {labels[status]}
    </span>
  );
}
