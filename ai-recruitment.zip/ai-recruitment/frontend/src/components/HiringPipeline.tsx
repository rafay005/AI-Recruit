interface Props {
  openJobs: number;
  applicants: number;
}

/** The real hiring flow of the platform, shown as it is built. */
export default function HiringPipeline({ openJobs, applicants }: Props) {
  const stages = [
    { label: "Job posted", note: openJobs > 0 ? `${openJobs} live` : "Start here", level: "active" },
    { label: "Applications", note: applicants > 0 ? `${applicants} received` : "Open", level: "active" },
    { label: "CV analysis", note: "Automatic", level: "active" },
    { label: "Ranking", note: "Automatic", level: "active" },
    { label: "Skill gap", note: "Automatic", level: "active" },
    { label: "AI interview", note: "Next up", level: "next" },
    { label: "Evaluation", note: "Planned", level: "planned" },
    { label: "Recommendation", note: "Planned", level: "planned" },
  ] as const;

  const bar = { active: "bg-white", next: "bg-white/55", planned: "bg-white/20" };
  const text = { active: "text-white", next: "text-maroon-100", planned: "text-maroon-300" };

  return (
    <ol className="grid grid-cols-2 gap-x-4 gap-y-5 sm:grid-cols-4 xl:grid-cols-8">
      {stages.map((s, i) => (
        <li
          key={s.label}
          className="stage-in"
          style={{ animationDelay: `${i * 90}ms` }}
          aria-label={`${s.label}: ${s.note}`}
        >
          <div className={`mb-3 h-1 rounded-full ${bar[s.level]}`} />
          <p className={`text-sm font-medium ${text[s.level]}`}>{s.label}</p>
          <p className={`mt-0.5 text-xs ${s.level === "active" ? "text-maroon-100" : "text-maroon-300/80"}`}>
            {s.note}
          </p>
        </li>
      ))}
    </ol>
  );
}
