"use client";

import { useEffect, useRef, useState } from "react";
import { Check, Sparkles, X } from "lucide-react";
import { api, errorMessage } from "@/lib/api";
import type { GapItem, SkillGap } from "@/types/gap";

const verdictStyle = {
  none: "bg-emerald-50 text-emerald-900 ring-emerald-300",
  trainable: "bg-amber-50 text-amber-900 ring-amber-300",
  critical: "bg-red-50 text-red-900 ring-red-300",
};
const verdictTitle = { none: "No skill gaps", trainable: "Trainable gaps", critical: "Critical gaps" };

function Chip({ kind, children }: { kind: "has" | "missing" | "similar" | "plain"; children: React.ReactNode }) {
  const styles = {
    has: "bg-emerald-50 text-emerald-800 ring-emerald-300",
    missing: "bg-red-50 text-red-700 ring-red-200",
    similar: "bg-amber-50 text-amber-800 ring-amber-300",
    plain: "bg-maroon-50 text-maroon-800 ring-maroon-200",
  };
  return (
    <li className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-sm font-medium ring-1 ring-inset ${styles[kind]}`}>
      {kind === "has" && <Check size={13} aria-hidden />}
      {kind === "missing" && <X size={13} aria-hidden />}
      {kind === "similar" && <span aria-hidden>≈</span>}
      {children}
    </li>
  );
}

function Severity({ item }: { item: GapItem }) {
  return item.severity === "critical" ? (
    <span className="rounded-full bg-red-100 px-2.5 py-0.5 text-xs font-semibold text-red-800">Critical</span>
  ) : (
    <span className="rounded-full bg-amber-100 px-2.5 py-0.5 text-xs font-semibold text-amber-900">Trainable</span>
  );
}

export default function SkillGapPanel({ applicationId }: { applicationId: number }) {
  const [gap, setGap] = useState<SkillGap | null>(null);
  const [error, setError] = useState("");
  const [aiBusy, setAiBusy] = useState(false);
  const [aiError, setAiError] = useState("");
  const autoRan = useRef(false);

  async function explain() {
    setAiBusy(true);
    setAiError("");
    try {
      const r = await api.post<SkillGap>(`/api/hr/applications/${applicationId}/skill-gap/explain`);
      setGap(r.data);
    } catch (err) {
      setAiError(errorMessage(err, "The AI explanation failed"));
    } finally {
      setAiBusy(false);
    }
  }

  useEffect(() => {
    api
      .get<SkillGap>(`/api/hr/applications/${applicationId}/skill-gap`)
      .then((r) => {
        setGap(r.data);
        // First visit with an AI key configured: ask the AI once, then it is cached.
        if (r.data.ai_available && !r.data.ai_cached && r.data.assessment.items.length > 0 && !autoRan.current) {
          autoRan.current = true;
          setAiBusy(true);
          api
            .post<SkillGap>(`/api/hr/applications/${applicationId}/skill-gap/explain`)
            .then((x) => setGap(x.data))
            .catch((err) => setAiError(errorMessage(err, "The AI explanation failed")))
            .finally(() => setAiBusy(false));
        }
      })
      .catch((err) => setError(errorMessage(err, "Could not load the skill gap")));
  }, [applicationId]);

  if (error) return null; // not analysed yet or not available: the page already explains that
  if (!gap) return <p className="mb-6 text-sm text-muted">Loading skill gap...</p>;

  const a = gap.assessment;
  const similar = new Set(gap.similar);

  return (
    <section className="mb-6 rounded-2xl border border-line bg-white p-6 sm:p-8">
      <div className="mb-6">
        <h2 className="font-display text-2xl font-semibold text-maroon-900">Skill gap</h2>
        <p className="mt-1 text-sm text-muted">What {gap.job.title} needs, what this candidate has, and what is missing.</p>
      </div>

      <div className="grid gap-5 md:grid-cols-3">
        <div>
          <h3 className="mb-2 text-sm font-medium text-muted">Required</h3>
          <ul className="flex flex-wrap gap-1.5">
            {gap.required.map((s) => (
              <Chip key={s} kind="plain">
                {s}
              </Chip>
            ))}
          </ul>
        </div>
        <div>
          <h3 className="mb-2 text-sm font-medium text-muted">Candidate</h3>
          {gap.candidate_has.length === 0 ? (
            <p className="text-sm text-muted">None of the required skills.</p>
          ) : (
            <ul className="flex flex-wrap gap-1.5">
              {gap.candidate_has.map((s) => (
                <Chip key={s} kind="has">
                  {s}
                </Chip>
              ))}
            </ul>
          )}
        </div>
        <div>
          <h3 className="mb-2 text-sm font-medium text-muted">Missing</h3>
          {gap.missing.length + gap.similar.length === 0 ? (
            <p className="text-sm text-muted">Nothing missing.</p>
          ) : (
            <ul className="flex flex-wrap gap-1.5">
              {[...gap.missing, ...gap.similar].map((s) => (
                <Chip key={s} kind={similar.has(s) ? "similar" : "missing"}>
                  {s}
                </Chip>
              ))}
            </ul>
          )}
        </div>
      </div>

      {gap.candidate_extra.length > 0 && (
        <p className="mt-4 text-sm text-muted">Also on the CV: {gap.candidate_extra.join(", ")}.</p>
      )}

      {/* Verdict */}
      <div className={`mt-6 rounded-xl p-5 ring-1 ring-inset ${verdictStyle[a.verdict]}`}>
        <div className="mb-1 flex flex-wrap items-center justify-between gap-2">
          <p className="font-display text-lg font-semibold">{verdictTitle[a.verdict]}</p>
          <p className="flex items-center gap-1.5 text-xs">
            {aiBusy ? (
              "AI is reviewing the gaps..."
            ) : a.source === "ai" ? (
              <>
                <Sparkles size={13} aria-hidden /> AI explanation
              </>
            ) : (
              "Built-in assessment"
            )}
          </p>
        </div>
        <p className="text-sm leading-relaxed">{a.summary}</p>
      </div>

      {/* Per-gap explanation */}
      {a.items.length > 0 && (
        <ul className="mt-5 space-y-3">
          {a.items.map((i) => (
            <li key={i.skill} className="rounded-xl border border-line p-4">
              <div className="mb-2 flex flex-wrap items-center gap-2">
                <span className="font-medium">{i.skill}</span>
                <Severity item={i} />
                <span className="text-xs text-muted">Roughly: {i.effort}</span>
                {i.status === "related" && i.similar_skill && (
                  <span className="text-xs text-amber-800">Has a similar skill: {i.similar_skill}</span>
                )}
              </div>
              <p className="text-sm leading-relaxed">{i.reason}</p>
              <p className="mt-2 text-sm text-muted">
                <span className="font-medium text-ink">How to close it:</span> {i.how_to_close}
              </p>
            </li>
          ))}
        </ul>
      )}

      {gap.nice_missing.length > 0 && (
        <p className="mt-4 text-sm text-muted">Nice-to-have skills not found: {gap.nice_missing.join(", ")}.</p>
      )}

      {/* AI controls */}
      <div className="mt-5 flex flex-wrap items-center gap-3 border-t border-line pt-4">
        {!gap.ai_available && (
          <p className="text-xs text-muted">
            This is the built-in assessment (rules, no AI). Add an AI key in the backend settings to get an AI
            explanation for each gap.
          </p>
        )}
        {gap.ai_available && a.items.length > 0 && (
          <button
            onClick={explain}
            disabled={aiBusy}
            className="flex items-center gap-2 rounded-lg border border-maroon-700 px-4 py-2 text-sm font-semibold text-maroon-700 hover:bg-maroon-50 disabled:opacity-60"
          >
            <Sparkles size={14} /> {a.source === "ai" ? "Ask the AI again" : "Explain with AI"}
          </button>
        )}
        {aiError && (
          <span role="alert" className="text-sm text-red-700">
            {aiError} Showing the built-in assessment.
          </span>
        )}
        <p className="ml-auto text-xs text-muted">Time estimates are rough guides, not promises.</p>
      </div>
    </section>
  );
}
