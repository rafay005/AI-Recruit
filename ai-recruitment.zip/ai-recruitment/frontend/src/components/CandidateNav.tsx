"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const nav = [
  { href: "/candidate", label: "Open jobs", exact: true },
  { href: "/candidate/applications", label: "My applications", exact: false },
];

export default function CandidateNav() {
  const pathname = usePathname();
  return (
    <nav aria-label="Main" className="flex gap-1">
      {nav.map(({ href, label, exact }) => {
        const active = exact ? pathname === href || pathname.startsWith("/candidate/jobs") : pathname.startsWith(href);
        return (
          <Link
            key={href}
            href={href}
            aria-current={active ? "page" : undefined}
            className={`rounded-lg px-3.5 py-2 text-sm font-medium transition ${
              active ? "bg-white text-maroon-800" : "text-maroon-100 hover:bg-white/10 hover:text-white"
            }`}
          >
            {label}
          </Link>
        );
      })}
    </nav>
  );
}
