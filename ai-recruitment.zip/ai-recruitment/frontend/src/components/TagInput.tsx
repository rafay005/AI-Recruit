"use client";

import { useState } from "react";
import { X } from "lucide-react";

interface Props {
  label: string;
  values: string[];
  onChange: (values: string[]) => void;
  placeholder?: string;
  hint?: string;
}

export default function TagInput({ label, values, onChange, placeholder, hint }: Props) {
  const [text, setText] = useState("");

  function addFromText(raw: string) {
    const parts = raw
      .split(",")
      .map((p) => p.trim())
      .filter(Boolean);
    if (parts.length === 0) return;
    const existing = new Set(values.map((v) => v.toLowerCase()));
    const next = [...values];
    for (const p of parts) {
      if (!existing.has(p.toLowerCase())) {
        existing.add(p.toLowerCase());
        next.push(p);
      }
    }
    onChange(next);
    setText("");
  }

  return (
    <div>
      <label className="mb-1.5 block text-sm font-medium text-ink">{label}</label>
      <div className="flex flex-wrap gap-2 rounded-lg border border-line bg-white p-2 focus-within:border-maroon-600 focus-within:ring-2 focus-within:ring-maroon-600/20">
        {values.map((v) => (
          <span
            key={v}
            className="flex items-center gap-1 rounded-md bg-maroon-50 px-2 py-1 text-sm text-maroon-800 ring-1 ring-inset ring-maroon-200"
          >
            {v}
            <button
              type="button"
              aria-label={`Remove ${v}`}
              onClick={() => onChange(values.filter((x) => x !== v))}
              className="text-maroon-500 hover:text-maroon-800"
            >
              <X size={14} />
            </button>
          </span>
        ))}
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === ",") {
              e.preventDefault();
              addFromText(text);
            } else if (e.key === "Backspace" && !text && values.length) {
              onChange(values.slice(0, -1));
            }
          }}
          onBlur={() => addFromText(text)}
          placeholder={values.length ? "" : placeholder}
          className="min-w-[8rem] flex-1 bg-transparent px-1 py-1 text-ink outline-none placeholder:text-muted/70"
        />
      </div>
      {hint && <p className="mt-1.5 text-xs text-muted">{hint}</p>}
    </div>
  );
}
