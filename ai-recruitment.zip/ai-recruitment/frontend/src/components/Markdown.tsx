import ReactMarkdown from "react-markdown";

export default function Markdown({ children }: { children: string }) {
  return (
    <div
      className="space-y-3 leading-relaxed text-ink
        [&_h1]:font-display [&_h1]:text-2xl [&_h1]:font-semibold [&_h1]:text-maroon-900
        [&_h2]:mt-6 [&_h2]:font-display [&_h2]:text-lg [&_h2]:font-semibold [&_h2]:text-maroon-800
        [&_h3]:font-semibold [&_h3]:text-maroon-800
        [&_ul]:list-disc [&_ul]:space-y-1 [&_ul]:pl-6 [&_ul]:marker:text-maroon-500
        [&_ol]:list-decimal [&_ol]:space-y-1 [&_ol]:pl-6
        [&_strong]:font-semibold
        [&_a]:text-maroon-700 [&_a]:underline"
    >
      <ReactMarkdown>{children}</ReactMarkdown>
    </div>
  );
}
