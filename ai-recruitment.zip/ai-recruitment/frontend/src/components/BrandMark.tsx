export default function BrandMark({ tone = "light" }: { tone?: "light" | "dark" }) {
  const light = tone === "light";
  return (
    <div className="flex items-center gap-3">
      <span
        className={`grid h-9 w-9 place-items-center rounded-lg font-display text-[0.95rem] font-bold tracking-tight ${
          light ? "bg-white text-maroon-800" : "bg-maroon-700 text-white"
        }`}
        aria-hidden
      >
        AR
      </span>
      <span
        className={`font-display text-xl font-semibold tracking-tight ${
          light ? "text-white" : "text-maroon-800"
        }`}
      >
        AI Recruit
      </span>
    </div>
  );
}
