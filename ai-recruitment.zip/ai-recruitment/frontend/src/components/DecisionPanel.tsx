"use client";

import { useState } from "react";
import { api, errorMessage } from "@/lib/api";
import DecisionBadge from "@/components/DecisionBadge";
import { DECISIONS, type Decision } from "@/types/application";

interface Props {
  applicationId: number;
  initialDecision: Decision;
  initialNote: string | null;
}

export default function DecisionPanel({ applicationId, initialDecision, initialNote }: Props) {
  const [saved, setSaved] = useState<Decision>(initialDecision);
  const [decision, setDecision] = useState<Decision>(initialDecision);
  const [note, setNote] = useState(initialNote ?? "");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const dirty = decision !== saved || (decision !== "under_review" && note.trim() !== (initialNote ?? "").trim());

  async function save() {
    if (decision === "rejected" && !window.confirm("Mark this candidate as rejected? They will see this on their application.")) {
      return;
    }
    setBusy(true);
    setError("");
    setMessage("");
    try {
      const r = await api.put(`/api/hr/applications/${applicationId}/decision`, {
        decision,
        note: decision === "under_review" ? null : note.trim() || null,
      });
      setSaved(r.data.decision);
      setNote(r.data.decision_note ?? "");
      setMessage("Saved. The candidate can now see this status.");
    } catch (err) {
      setError(errorMessage(err, "Could not save the decision"));
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="mb-6 rounded-2xl border border-line bg-white p-6 sm:p-8">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h2 className="font-display text-2xl font-semibold text-maroon-900">Decision</h2>
        <DecisionBadge decision={saved} />
      </div>

      <div role="radiogroup" aria-label="Decision" className="flex flex-wrap gap-2">
        {DECISIONS.map((d) => (
          <button
            key={d.value}
            role="radio"
            aria-checked={decision === d.value}
            onClick={() => {
              setDecision(d.value);
              setMessage("");
            }}
            className={`rounded-lg px-4 py-2 text-sm font-semibold transition ${
              decision === d.value
                ? "bg-maroon-700 text-white shadow-sm"
                : "border border-line bg-white text-ink hover:border-maroon-300 hover:bg-maroon-50"
            }`}
          >
            {d.hr}
          </button>
        ))}
      </div>

      {decision !== "under_review" && (
        <div className="mt-5">
          <label htmlFor="decision-note" className="mb-1.5 block text-sm font-medium">
            Message to the candidate (optional)
          </label>
          <textarea
            id="decision-note"
            rows={3}
            maxLength={500}
            value={note}
            onChange={(e) => {
              setNote(e.target.value);
              setMessage("");
            }}
            placeholder={
              decision === "rejected"
                ? "A short, kind message helps. For example: thank you for applying, we went with a candidate whose experience was a closer fit."
                : "For example: we will contact you this week to arrange a time."
            }
            className="w-full rounded-lg border border-line bg-white px-3.5 py-2.5 text-sm outline-none placeholder:text-muted/70 focus:border-maroon-600 focus:ring-2 focus:ring-maroon-600/20"
          />
          <p className="mt-1 text-right text-xs text-muted">{note.length} / 500</p>
        </div>
      )}

      <div className="mt-4 flex flex-wrap items-center gap-4">
        <button
          onClick={save}
          disabled={busy || !dirty}
          className="rounded-lg bg-maroon-700 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-maroon-800 disabled:opacity-50"
        >
          {busy ? "Saving..." : "Save decision"}
        </button>
        {message && (
          <span role="status" className="text-sm text-emerald-700">
            {message}
          </span>
        )}
        {error && (
          <span role="alert" className="text-sm text-red-700">
            {error}
          </span>
        )}
      </div>
      <p className="mt-4 text-xs text-muted">
        The ranking and skill gap are advice for you, nothing changes automatically. The candidate sees only the status
        and your message.
      </p>
    </section>
  );
}
