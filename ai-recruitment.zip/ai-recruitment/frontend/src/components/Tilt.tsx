"use client";

import { useRef } from "react";

/**
 * Tilts an element toward the mouse in 3D, with a soft glare that follows the cursor.
 * Usage: const { ref, onMouseMove, onMouseLeave } = useTilt<HTMLDivElement>(6);
 *        <div ref={ref} onMouseMove={onMouseMove} onMouseLeave={onMouseLeave} className="tilt ...">
 * Writes CSS variables straight to the element, so moving the mouse never re-renders React.
 * The styles live in globals.css (.tilt) and are off for reduced-motion users.
 */
export function useTilt<T extends HTMLElement>(max = 6) {
  const ref = useRef<T>(null);
  function onMouseMove(e: React.MouseEvent<T>) {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width;
    const py = (e.clientY - r.top) / r.height;
    el.style.setProperty("--ry", `${((px - 0.5) * 2 * max).toFixed(2)}deg`);
    el.style.setProperty("--rx", `${((0.5 - py) * 2 * max).toFixed(2)}deg`);
    el.style.setProperty("--gx", `${(px * 100).toFixed(1)}%`);
    el.style.setProperty("--gy", `${(py * 100).toFixed(1)}%`);
  }
  function onMouseLeave() {
    const el = ref.current;
    if (!el) return;
    el.style.setProperty("--rx", "0deg");
    el.style.setProperty("--ry", "0deg");
  }
  return { ref, onMouseMove, onMouseLeave };
}
