"use client";

import { useState } from "react";
import TagInput from "@/components/TagInput";
import { errorMessage } from "@/lib/api";
import {
  EMPLOYMENT_TYPES,
  EXPERIENCE_LEVELS,
  WORK_MODES,
  type JobInput,
} from "@/types/job";

interface Props {
  initial?: JobInput;
  submitLabel: string;
  notice?: string;
  onSubmit: (data: JobInput) => Promise<void>;
}

const EMPTY: JobInput = {
  title: "",
  department: null,
  location: null,
  employment_type: "full_time",
  work_mode: "onsite",
  experience_level: "mid",
  min_experience_years: null,
  max_experience_years: null,
  education: null,
  salary_min: null,
  salary_max: null,
  salary_currency: "PKR",
  show_salary: false,
  openings: 1,
  application_deadline: null,
  required_skills: [],
  nice_to_have_skills: [],
  responsibilities: null,
  company_about: null,
};

const input =
  "w-full rounded-lg border border-line bg-white px-3.5 py-2.5 text-ink outline-none transition placeholder:text-muted/70 focus:border-maroon-600 focus:ring-2 focus:ring-maroon-600/20";
const label = "mb-1.5 block text-sm font-medium text-ink";
const card = "space-y-5 rounded-2xl border border-line bg-white p-6 sm:p-7";
const heading = "font-display text-xl font-semibold text-maroon-900";

const toNum = (v: string): number | null => (v.trim() === "" ? null : Number(v));
const toStr = (v: number | null): string => (v === null ? "" : String(v));

export default function JobForm({ initial, submitLabel, notice, onSubmit }: Props) {
  const [v, setV] = useState<JobInput>(initial ?? EMPTY);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  function patch<K extends keyof JobInput>(key: K, value: JobInput[K]) {
    setV((prev) => ({ ...prev, [key]: value }));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (v.required_skills.length === 0) {
      setError("Add at least one required skill (type it and press Enter).");
      return;
    }
    setSaving(true);
    try {
      await onSubmit(v);
    } catch (err) {
      setError(errorMessage(err, "Could not save the job"));
      setSaving(false);
    }
  }

  return (
    <form onSubmit={submit} className="max-w-3xl space-y-6">
      {notice && (
        <p className="rounded-lg bg-amber-50 p-3 text-sm text-amber-900 ring-1 ring-inset ring-amber-200">{notice}</p>
      )}
      {error && <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-800 ring-1 ring-inset ring-red-200">{error}</p>}

      <section className={card}>
        <h2 className={heading}>Role basics</h2>
        <div>
          <label className={label}>Job title *</label>
          <input
            required
            minLength={3}
            maxLength={200}
            className={input}
            placeholder="e.g. Senior Python Developer"
            value={v.title}
            onChange={(e) => patch("title", e.target.value)}
          />
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className={label}>Department</label>
            <input
              className={input}
              maxLength={120}
              value={v.department ?? ""}
              onChange={(e) => patch("department", e.target.value || null)}
            />
          </div>
          <div>
            <label className={label}>Location</label>
            <input
              className={input}
              maxLength={160}
              placeholder="City, Country"
              value={v.location ?? ""}
              onChange={(e) => patch("location", e.target.value || null)}
            />
          </div>
          <div>
            <label className={label}>Employment type</label>
            <select
              className={input}
              value={v.employment_type}
              onChange={(e) => patch("employment_type", e.target.value)}
            >
              {EMPLOYMENT_TYPES.map((o) => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className={label}>Work mode</label>
            <select
              className={input}
              value={v.work_mode}
              onChange={(e) => patch("work_mode", e.target.value)}
            >
              {WORK_MODES.map((o) => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className={label}>Openings</label>
            <input
              type="number"
              min={1}
              max={1000}
              className={input}
              value={v.openings}
              onChange={(e) => patch("openings", Number(e.target.value) || 1)}
            />
          </div>
          <div>
            <label className={label}>Application deadline</label>
            <input
              type="date"
              className={input}
              value={v.application_deadline ?? ""}
              onChange={(e) => patch("application_deadline", e.target.value || null)}
            />
          </div>
        </div>
      </section>

      <section className={card}>
        <h2 className={heading}>Requirements</h2>
        <div className="grid gap-4 sm:grid-cols-3">
          <div>
            <label className={label}>Seniority</label>
            <select
              className={input}
              value={v.experience_level}
              onChange={(e) => patch("experience_level", e.target.value)}
            >
              {EXPERIENCE_LEVELS.map((o) => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className={label}>Min. experience (years)</label>
            <input
              type="number"
              min={0}
              max={50}
              className={input}
              value={toStr(v.min_experience_years)}
              onChange={(e) => patch("min_experience_years", toNum(e.target.value))}
            />
          </div>
          <div>
            <label className={label}>Max. experience (years)</label>
            <input
              type="number"
              min={0}
              max={50}
              className={input}
              value={toStr(v.max_experience_years)}
              onChange={(e) => patch("max_experience_years", toNum(e.target.value))}
            />
          </div>
        </div>
        <div>
          <label className={label}>Education</label>
          <input
            className={input}
            maxLength={200}
            placeholder="e.g. BS in Computer Science or equivalent"
            value={v.education ?? ""}
            onChange={(e) => patch("education", e.target.value || null)}
          />
        </div>
        <TagInput
          label="Required skills *"
          values={v.required_skills}
          onChange={(x) => patch("required_skills", x)}
          placeholder="Type a skill and press Enter"
          hint="These are also used later to match and rank candidates."
        />
        <TagInput
          label="Nice-to-have skills"
          values={v.nice_to_have_skills}
          onChange={(x) => patch("nice_to_have_skills", x)}
          placeholder="Type a skill and press Enter"
        />
      </section>

      <section className={card}>
        <h2 className={heading}>Details for the AI</h2>
        <div>
          <label className={label}>Key responsibilities (rough notes are fine)</label>
          <textarea
            rows={5}
            maxLength={4000}
            className={input}
            placeholder={"One per line, e.g.\nBuild and maintain REST APIs\nReview code and mentor juniors"}
            value={v.responsibilities ?? ""}
            onChange={(e) => patch("responsibilities", e.target.value || null)}
          />
        </div>
        <div>
          <label className={label}>About the company (optional)</label>
          <textarea
            rows={3}
            maxLength={2000}
            className={input}
            placeholder="A short blurb the AI can use. It will not invent company facts."
            value={v.company_about ?? ""}
            onChange={(e) => patch("company_about", e.target.value || null)}
          />
        </div>
      </section>

      <section className={card}>
        <h2 className={heading}>Salary (optional)</h2>
        <div className="grid gap-4 sm:grid-cols-3">
          <div>
            <label className={label}>Currency</label>
            <input
              className={input}
              maxLength={8}
              value={v.salary_currency ?? ""}
              onChange={(e) => patch("salary_currency", e.target.value || null)}
            />
          </div>
          <div>
            <label className={label}>Min</label>
            <input
              type="number"
              min={0}
              className={input}
              value={toStr(v.salary_min)}
              onChange={(e) => patch("salary_min", toNum(e.target.value))}
            />
          </div>
          <div>
            <label className={label}>Max</label>
            <input
              type="number"
              min={0}
              className={input}
              value={toStr(v.salary_max)}
              onChange={(e) => patch("salary_max", toNum(e.target.value))}
            />
          </div>
        </div>
        <label className="flex items-center gap-2 text-sm text-ink">
          <input
            type="checkbox"
            className="h-4 w-4 accent-maroon-700"
            checked={v.show_salary}
            onChange={(e) => patch("show_salary", e.target.checked)}
          />
          Show this salary range to candidates in the job description
        </label>
      </section>

      <button
        disabled={saving}
        className="rounded-lg bg-maroon-700 px-6 py-2.5 font-semibold text-white shadow-sm hover:bg-maroon-800 disabled:opacity-60"
      >
        {saving ? "Saving..." : submitLabel}
      </button>
    </form>
  );
}
