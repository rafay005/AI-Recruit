"use client";

import { useEffect, useState } from "react";
import {
  ArrowDownRight, ArrowUpRight, Bot, Briefcase, CalendarClock, CheckCircle2, ClipboardList, Mic, MousePointerClick, Trophy,
  UserPlus, XCircle,
} from "lucide-react";
import { api, errorMessage } from "@/lib/api";
import type { Bucket, TimePoint } from "@/components/dashboard/charts";
import { Sparkline } from "@/components/dashboard/charts";
import { useTilt } from "@/components/Tilt";
import type { Decision } from "@/types/application";
import type { JobStatus } from "@/types/job";

export interface Insights {
  hr_name: string;
  company: string | null;
  kpis: {
    open_jobs: number; draft_jobs: number; total_applicants: number; applicants_7d: number; applicants_prev_7d: number;
    avg_match: number | null; interviews_completed: number; interviews_pending: number; avg_interview: number | null;
    selected: number; rejected: number; openings: number; automated_decisions: number; automation_rate: number | null;
    avg_days_to_decision: number | null; jobs_automated: number;
  };
  funnel: { stage: string; count: number }[];
  timeline: TimePoint[];
  match_histogram: Bucket[];
  interview_histogram: Bucket[];
  decisions: Record<"under_review" | "shortlisted" | "interview" | "hired" | "rejected", number>;
  jobs: {
    id: number; title: string; status: JobStatus; role_family: string | null; applicants: number; avg_match: number | null;
    best_match: number | null; best_candidate: string | null; interviews_done: number; selected: number; openings: number;
    auto_enabled: boolean; cv_threshold: number; interview_threshold: number;
  }[];
  top_candidates: {
    application_id: number; name: string; job_title: string; match: number; interview: number | null; combined: number;
    decision: Decision; decision_source: string | null;
  }[];
  skills: { skill: string; jobs: number; applicants: number; coverage: number | null }[];
  activity: ActivityItem[];
}

export interface ActivityItem {
  at: string; kind: string; auto: boolean; text: string; detail: string | null; job_title: string | null;
}

/** Loads /api/hr/dashboard/insights once. */
export function useInsights() {
  const [data, setData] = useState<Insights | null>(null);
  const [error, setError] = useState("");
  useEffect(() => {
    api.get<Insights>("/api/hr/dashboard/insights").then((r) => setData(r.data))
      .catch((err) => setError(errorMessage(err, "Could not load the data")));
  }, []);
  return { data, error };
}

export function ago(s: string) {
  const d = (Date.now() - new Date(s).getTime()) / 1000;
  if (d < 60) return "just now";
  if (d < 3600) return `${Math.floor(d / 60)}m ago`;
  if (d < 86400) return `${Math.floor(d / 3600)}h ago`;
  if (d < 7 * 86400) return `${Math.floor(d / 86400)}d ago`;
  return new Date(s).toLocaleDateString();
}

export const ACT_ICON: Record<string, { icon: typeof Bot; tone: string }> = {
  applied: { icon: UserPlus, tone: "bg-maroon-50 text-maroon-700" },
  interviewed: { icon: Mic, tone: "bg-blue-50 text-blue-700" },
  invited: { icon: CalendarClock, tone: "bg-maroon-50 text-maroon-700" },
  selected: { icon: Trophy, tone: "bg-emerald-50 text-emerald-700" },
  cv_rejected: { icon: XCircle, tone: "bg-red-50 text-red-700" },
  interview_rejected: { icon: XCircle, tone: "bg-red-50 text-red-700" },
  openings_full: { icon: CheckCircle2, tone: "bg-stone-100 text-stone-700" },
  cv_held: { icon: ClipboardList, tone: "bg-amber-50 text-amber-800" },
  manual_move: { icon: MousePointerClick, tone: "bg-violet-50 text-violet-700" },
};
export const ACT_FALLBACK = { icon: Briefcase, tone: "bg-stone-100 text-stone-700" };

export function Card({ title, sub, action, children, className = "", tilt = 2.5 }: {
  title: string; sub?: string; action?: React.ReactNode; children: React.ReactNode; className?: string; tilt?: number;
}) {
  const { ref, onMouseMove, onMouseLeave } = useTilt<HTMLElement>(tilt);
  return (
    <section ref={ref} onMouseMove={onMouseMove} onMouseLeave={onMouseLeave}
             className={`tilt rounded-2xl border border-line bg-white p-5 shadow-[0_1px_2px_rgba(46,7,18,0.04)] ${className}`}>
      <div className="mb-3 flex items-start justify-between gap-3">
        <div>
          <h2 className="font-display text-lg font-semibold text-maroon-900">{title}</h2>
          {sub && <p className="mt-0.5 text-xs text-muted">{sub}</p>}
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}

export function Stat({ icon: Icon, label, value, note, delta, spark }: {
  icon: typeof Bot; label: string; value: string | number; note?: string;
  delta?: { value: number; label: string } | null; spark?: number[];
}) {
  const up = delta && delta.value > 0, down = delta && delta.value < 0;
  const { ref, onMouseMove, onMouseLeave } = useTilt<HTMLDivElement>(8);
  return (
    <div ref={ref} onMouseMove={onMouseMove} onMouseLeave={onMouseLeave}
         className="tilt @container flex items-center gap-4 rounded-2xl border border-line bg-white p-4 shadow-[0_1px_2px_rgba(46,7,18,0.04)]">
      <span className="pop grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-maroon-50 text-maroon-700"><Icon size={19} /></span>
      <div className="min-w-0 flex-1">
        <p className="text-2xl font-semibold leading-none text-ink">{value}</p>
        <p className="mt-1.5 truncate text-sm font-medium text-ink">{label}</p>
        <div className="flex items-center gap-1.5 truncate text-xs text-muted">
          {delta && (
            <span className={`inline-flex items-center font-medium ${up ? "text-emerald-700" : down ? "text-red-700" : "text-muted"}`}>
              {up ? <ArrowUpRight size={13} /> : down ? <ArrowDownRight size={13} /> : null}
              {delta.value > 0 ? "+" : ""}{delta.value}
            </span>
          )}
          <span className="truncate">{delta ? delta.label : note}</span>
        </div>
      </div>
      {/* Only when the tile itself is wide enough, so the label is never cut off. */}
      {spark && spark.some((v) => v > 0) && <div className="hidden shrink-0 @[21rem]:block"><Sparkline values={spark} /></div>}
    </div>
  );
}

export function ScorePill({ v }: { v: number | null }) {
  if (v === null) return <span className="text-muted">–</span>;
  const tone = v >= 75 ? "bg-emerald-50 text-emerald-800 ring-emerald-200" : v >= 50 ? "bg-amber-50 text-amber-800 ring-amber-200" : "bg-red-50 text-red-800 ring-red-200";
  return <span className={`rounded-md px-2 py-0.5 text-xs font-semibold tabular-nums ring-1 ring-inset ${tone}`}>{v}%</span>;
}

export function PageTitle({ title, sub, action }: { title: string; sub: string; action?: React.ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="font-display text-3xl font-semibold tracking-tight text-maroon-900">{title}</h1>
        <p className="mt-1 text-sm text-muted">{sub}</p>
      </div>
      {action}
    </div>
  );
}

export function Loading() {
  return (
    <div className="space-y-5" aria-busy>
      <div className="h-24 animate-pulse rounded-2xl bg-maroon-100/60" />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[0, 1, 2, 3].map((i) => <div key={i} className="h-24 animate-pulse rounded-2xl bg-white" />)}
      </div>
      <div className="h-72 animate-pulse rounded-2xl bg-white" />
    </div>
  );
}
