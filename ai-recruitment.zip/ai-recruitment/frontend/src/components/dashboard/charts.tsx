"use client";

/**
 * Small SVG chart kit for the HR dashboard. No chart library.
 * Colours are validated (dataviz validator, white surface):
 *   two series: maroon #a53456 + blue #2a78d6
 *   decisions:  selected #0ca30c, interview #a53456, shortlisted #2a78d6, under review #c3c2b7, rejected #d03b3b
 * Text always uses ink tokens, never a series colour. Every chart has a hover layer.
 */
import { useId, useMemo, useState } from "react";

export const C = {
  s1: "#a53456",
  s2: "#2a78d6",
  grid: "#ece7e8",
  axis: "#d9d0d3",
  muted: "#898781",
  good: "#0ca30c",
  critical: "#d03b3b",
  neutral: "#c3c2b7",
};

/** Tooltip placed in % of the chart box (the SVG scales with its container). */
function Tip({ x, y, children }: { x: number; y: number; children: React.ReactNode }) {
  return (
    <div
      className="pointer-events-none absolute z-10 -translate-x-1/2 -translate-y-full whitespace-nowrap rounded-lg border border-line bg-white px-3 py-2 text-xs shadow-lg"
      style={{ left: `clamp(70px, ${x}%, calc(100% - 70px))`, top: `calc(${y}% - 10px)` }}
    >
      {children}
    </div>
  );
}

// ------------------------------------------------------------------ sparkline

export function Sparkline({ values, color = C.s1, height = 36 }: { values: number[]; color?: string; height?: number }) {
  const w = 120;
  const max = Math.max(1, ...values);
  const pts = values.map((v, i) => [(i / Math.max(1, values.length - 1)) * w, height - 4 - (v / max) * (height - 8)]);
  const d = pts.map((p, i) => `${i ? "L" : "M"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");
  const last = pts[pts.length - 1];
  return (
    <svg viewBox={`0 0 ${w} ${height}`} className="h-9 w-28" aria-hidden>
      <path d={`${d} L${w},${height} L0,${height} Z`} fill={color} opacity={0.1} />
      <path d={d} fill="none" stroke={color} strokeWidth={2} strokeLinejoin="round" strokeLinecap="round" />
      {last && <circle cx={last[0]} cy={last[1]} r={3.5} fill={color} stroke="#fff" strokeWidth={2} />}
    </svg>
  );
}

// ------------------------------------------------------------------ timeline (two lines, crosshair tooltip)

export interface TimePoint {
  date: string;
  applications: number;
  decisions: number;
}

export function TimelineChart({ data, height = 220 }: { data: TimePoint[]; height?: number }) {
  const W = 640, H = height, L = 30, R = 12, T = 14, B = 26;
  const [hover, setHover] = useState<number | null>(null);
  const max = Math.max(2, ...data.map((d) => Math.max(d.applications, d.decisions)));
  const step = max <= 4 ? 1 : Math.ceil(max / 4);
  const top = step * Math.ceil(max / step);
  // Daily counts are discrete and small, so paired columns (not lines that zig-zag between 0 and 1).
  const band = (W - L - R) / Math.max(1, data.length);
  const bw = Math.max(3, Math.min(9, band / 2 - 2));
  const x = (i: number) => L + band * i + band / 2;
  const y = (v: number) => T + (1 - v / top) * (H - T - B);
  const col = (cx: number, v: number) => {
    const h = H - B - y(v);
    if (h <= 0) return "";
    const r = Math.min(2, h);
    return `M${cx},${H - B} v${-(h - r)} q0,-${r} ${r},-${r} h${bw - 2 * r} q${r},0 ${r},${r} v${h - r} z`;
  };
  const ticks = Array.from({ length: Math.floor(top / step) + 1 }, (_, i) => i * step);
  const fmt = (s: string) => new Date(s + "T00:00:00").toLocaleDateString(undefined, { month: "short", day: "numeric" });

  function move(e: React.MouseEvent<SVGSVGElement>) {
    const r = e.currentTarget.getBoundingClientRect();
    const px = ((e.clientX - r.left) / r.width) * W;
    setHover(Math.max(0, Math.min(data.length - 1, Math.floor((px - L) / band))));
  }

  const h = hover !== null ? data[hover] : null;
  return (
    <div className="relative">
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" onMouseMove={move} onMouseLeave={() => setHover(null)} role="img"
           aria-label="Applications and decisions per day over the last 30 days">
        {ticks.map((t) => (
          <g key={t}>
            <line x1={L} x2={W - R} y1={y(t)} y2={y(t)} stroke={t === 0 ? C.axis : C.grid} strokeWidth={1} />
            <text x={L - 8} y={y(t) + 4} textAnchor="end" fontSize={11} fill={C.muted} className="tabular-nums">{t}</text>
          </g>
        ))}
        {[0, 7, 14, 21, 29].map((i) => data[i] && (
          <text key={i} x={i === 0 ? L : i === 29 ? W - R : x(i)} y={H - 6} textAnchor={i === 0 ? "start" : i === 29 ? "end" : "middle"} fontSize={11} fill={C.muted}>
            {fmt(data[i].date)}
          </text>
        ))}
        {hover !== null && (
          <rect x={L + band * hover} y={T} width={band} height={H - T - B} fill="#241619" opacity={0.04} rx={3} />
        )}
        {data.map((d, i) => (
          <g key={d.date}>
            <path d={col(x(i) - bw - 1, d.applications)} fill={C.s1} className="grow-y" style={{ animationDelay: `${120 + i * 18}ms` }} />
            <path d={col(x(i) + 1, d.decisions)} fill={C.s2} className="grow-y" style={{ animationDelay: `${160 + i * 18}ms` }} />
          </g>
        ))}
      </svg>
      {hover !== null && h && (
        <Tip x={(100 * x(hover)) / W} y={(100 * y(Math.max(h.applications, h.decisions))) / H}>
          <p className="mb-1 font-medium text-ink">{fmt(h.date)}</p>
          <p className="flex items-center gap-2 text-muted"><span className="h-2 w-2 rounded-full" style={{ background: C.s1 }} />Applications <b className="ml-auto pl-3 text-ink">{h.applications}</b></p>
          <p className="flex items-center gap-2 text-muted"><span className="h-2 w-2 rounded-full" style={{ background: C.s2 }} />Decisions <b className="ml-auto pl-3 text-ink">{h.decisions}</b></p>
        </Tip>
      )}
    </div>
  );
}

export function Legend({ items }: { items: { label: string; color: string; value?: string | number }[] }) {
  return (
    <ul className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted">
      {items.map((i) => (
        <li key={i.label} className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-sm" style={{ background: i.color }} />
          {i.label}
          {i.value !== undefined && <span className="font-medium text-ink">{i.value}</span>}
        </li>
      ))}
    </ul>
  );
}

// ------------------------------------------------------------------ histogram (score distribution + threshold)

export interface Bucket {
  from: number;
  to: number;
  count: number;
}

export function Histogram({ buckets, threshold, color = C.s1, label, unit = "%" }: {
  buckets: Bucket[]; threshold?: number | null; color?: string; label: string; unit?: string;
}) {
  const W = 320, H = 150, L = 4, R = 4, T = 18, B = 22;
  const [hover, setHover] = useState<number | null>(null);
  const max = Math.max(1, ...buckets.map((b) => b.count));
  const band = (W - L - R) / buckets.length;
  const bw = Math.min(24, band - 6);
  const y = (v: number) => T + (1 - v / max) * (H - T - B);
  const total = buckets.reduce((s, b) => s + b.count, 0);
  const tx = threshold !== null && threshold !== undefined ? L + (threshold / 100) * (W - L - R) : null;
  return (
    <div className="relative">
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label={label} onMouseLeave={() => setHover(null)}>
        <line x1={L} x2={W - R} y1={H - B} y2={H - B} stroke={C.axis} />
        {buckets.map((b, i) => {
          const cx = L + band * i + band / 2;
          const h = H - B - y(b.count);
          const below = threshold !== null && threshold !== undefined && b.to < threshold;
          return (
            <g key={i} onMouseEnter={() => setHover(i)}>
              <rect x={L + band * i} y={T} width={band} height={H - T - B} fill="transparent" />
              {b.count > 0 && (
                <path
                  d={`M${cx - bw / 2},${H - B} v${-(h - 4)} q0,-4 4,-4 h${bw - 8} q4,0 4,4 v${h - 4} z`}
                  fill={color}
                  opacity={below ? 0.35 : hover === i ? 1 : 0.85}
                  className="grow-y"
                  style={{ animationDelay: `${150 + i * 45}ms`, transition: "opacity 200ms" }}
                />
              )}
              {(i % 2 === 0 || i === 9) && (
                <text x={cx} y={H - 6} textAnchor="middle" fontSize={10} fill={C.muted}>{b.from}</text>
              )}
            </g>
          );
        })}
        {tx !== null && (
          <g>
            <line x1={tx} x2={tx} y1={T - 6} y2={H - B} stroke="#241619" strokeWidth={1.5} strokeDasharray="3 3" />
            <text x={tx > W * 0.62 ? tx - 4 : tx + 4} y={T - 8} textAnchor={tx > W * 0.62 ? "end" : "start"}
                  fontSize={10} fill="#241619" fontWeight={600}>threshold {threshold}{unit}</text>
          </g>
        )}
      </svg>
      {hover !== null && (
        <Tip x={(100 * (L + band * hover + band / 2)) / W} y={(100 * y(buckets[hover].count)) / H}>
          <p className="font-medium text-ink">{buckets[hover].from}–{buckets[hover].to}%</p>
          <p className="text-muted">{buckets[hover].count} of {total} {total === 1 ? "candidate" : "candidates"}</p>
        </Tip>
      )}
    </div>
  );
}

// ------------------------------------------------------------------ funnel (stage bars with conversion)

export function Funnel({ stages }: { stages: { stage: string; count: number }[] }) {
  const first = Math.max(1, stages[0]?.count ?? 1);
  const [hover, setHover] = useState<number | null>(null);
  return (
    <ol className="space-y-2.5">
      {stages.map((s, i) => {
        const pct = Math.round((100 * s.count) / first);
        const prev = i > 0 ? stages[i - 1].count : null;
        const conv = prev ? Math.round((100 * s.count) / prev) : null;
        return (
          <li key={s.stage} className="grid grid-cols-[minmax(5.5rem,8rem)_1fr_2rem] items-center gap-2.5 text-sm"
              onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}>
            <span className="truncate text-ink">{s.stage}</span>
            <div className="relative h-7 rounded-md bg-maroon-50">
              <div
                className="grow-x h-full rounded-md"
                style={{ width: `${Math.max(s.count ? 3 : 0, pct)}%`, background: C.s1, opacity: 1 - i * 0.13, animationDelay: `${200 + i * 90}ms` }}
              />
              {hover === i && (
                <span className="absolute inset-y-0 right-2 flex items-center text-xs text-muted">
                  {pct}% of applicants{conv !== null ? ` · ${conv}% from previous` : ""}
                </span>
              )}
            </div>
            <span className="text-right font-semibold tabular-nums text-ink">{s.count}</span>
          </li>
        );
      })}
    </ol>
  );
}

// ------------------------------------------------------------------ segmented bar (decision mix)

export function SegmentedBar({ parts }: { parts: { label: string; value: number; color: string; dark?: boolean }[] }) {
  const total = parts.reduce((s, p) => s + p.value, 0);
  const [hover, setHover] = useState<string | null>(null);
  const id = useId();
  if (!total) return <p className="text-sm text-muted">No candidates yet.</p>;
  return (
    <div>
      <div className="flex h-7 w-full gap-[2px]" role="img" aria-labelledby={id}>
        {parts.filter((p) => p.value > 0).map((p) => {
          const share = Math.round((100 * p.value) / total);
          return (
            <div key={p.label} className="relative flex items-center rounded px-2 text-xs font-semibold"
                 style={{ width: `${(100 * p.value) / total}%`, background: p.color, color: p.dark ? "#0b0b0b" : "#fff" }}
                 onMouseEnter={() => setHover(p.label)} onMouseLeave={() => setHover(null)}>
              {share >= 12 ? `${share}%` : ""}
              {hover === p.label && (
                <span className="pointer-events-none absolute -top-9 left-1/2 z-10 -translate-x-1/2 whitespace-nowrap rounded-lg border border-line bg-white px-2.5 py-1 text-xs font-normal text-ink shadow-lg">
                  {p.label}: {p.value} ({share}%)
                </span>
              )}
            </div>
          );
        })}
      </div>
      <p id={id} className="sr-only">{parts.map((p) => `${p.label} ${p.value}`).join(", ")}</p>
      <div className="mt-3">
        <Legend items={parts.map((p) => ({ label: p.label, color: p.color, value: p.value }))} />
      </div>
    </div>
  );
}

// ------------------------------------------------------------------ ring gauge (one share)

export function Ring({ value, label, color = C.s1, size = 112 }: { value: number | null; label: string; color?: string; size?: number }) {
  const r = 42, c = 2 * Math.PI * r;
  const v = value ?? 0;
  const dash = useMemo(() => (c * Math.max(0, Math.min(100, v))) / 100, [c, v]);
  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90" role="img" aria-label={`${label}: ${value ?? "no data"}%`}>
        <circle cx={50} cy={50} r={r} fill="none" stroke="#f3e6e9" strokeWidth={9} />
        {dash > 0 && (
          <circle cx={50} cy={50} r={r} fill="none" stroke={color} strokeWidth={9} strokeLinecap="round"
                  strokeDasharray={`${dash} ${c}`} className="ring-draw"
                  style={{ "--len": `${dash}px`, animationDelay: "250ms" } as React.CSSProperties} />
        )}
      </svg>
      <p className="absolute text-xl font-semibold leading-none text-ink">{value === null ? "–" : `${value}%`}</p>
    </div>
  );
}

// ------------------------------------------------------------------ meter (one share, labelled)

export function Meter({ value, color = C.s1 }: { value: number | null; color?: string }) {
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-maroon-100">
      <div className="h-full rounded-full transition-[width] duration-700" style={{ width: `${value ?? 0}%`, background: color }} />
    </div>
  );
}
