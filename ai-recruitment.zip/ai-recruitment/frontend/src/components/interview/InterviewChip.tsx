import type { InterviewChipData } from "@/types/interview";

/** Small pill for HR lists (ranking page, candidates list). */
export default function InterviewChip({ interview }: { interview?: InterviewChipData | null }) {
  if (!interview) return null;
  const base = "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium";
  if (interview.status === "completed") {
    if (interview.score == null) return <span className={`${base} bg-neutral-100 text-neutral-600`}>Interview done · scoring…</span>;
    const tone = interview.score >= 65 ? "bg-emerald-50 text-emerald-700" : interview.score >= 45 ? "bg-amber-50 text-amber-700" : "bg-red-50 text-red-700";
    return <span className={`${base} ${tone}`} title={interview.label ?? undefined}>Interview {interview.score}{interview.label ? ` · ${interview.label.replace(" interview", "")}` : ""}</span>;
  }
  if (interview.status === "in_progress") return <span className={`${base} bg-blue-50 text-blue-700`}>Interviewing now</span>;
  return <span className={`${base} bg-[#fbf3f5] text-[#7a1f3d]`}>Interview invited</span>;
}
