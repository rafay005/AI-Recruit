import Link from "next/link";
import { Mic } from "lucide-react";
import type { InterviewBrief } from "@/types/interview";

/** Shown on "My applications" when HR has invited the candidate to an AI interview. */
export default function CandidateInterviewCard({ interview }: { interview?: InterviewBrief | null }) {
  if (!interview) return null;
  if (interview.status === "completed") {
    return <p className="mt-3 rounded-lg bg-neutral-50 p-3 text-sm text-neutral-600">Your interview is complete. Thank you. The hiring team will review it.</p>;
  }
  const resume = interview.status === "in_progress";
  return (
    <div className="mt-3 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#7a1f3d]/20 bg-[#fbf3f5] p-4">
      <p className="text-sm text-neutral-700">
        <b className="text-[#7a1f3d]">{resume ? "Your interview is in progress." : "You are invited to an AI interview."}</b>{" "}
        {resume ? "You can pick it up where you left off." : "It is a spoken conversation. Find a quiet place and start when you are ready."}
      </p>
      <Link href={`/candidate/interview/${interview.id}`} className="inline-flex items-center gap-2 rounded-lg bg-[#7a1f3d] px-4 py-2 text-sm font-medium text-white hover:bg-[#5e1530]" data-testid="start-interview-link">
        <Mic className="h-4 w-4" /> {resume ? "Resume interview" : "Start interview"}
      </Link>
    </div>
  );
}
