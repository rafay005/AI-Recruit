"use client";

import { useCallback, useEffect, useState } from "react";
import { Download, RefreshCw, Trash2, UserPlus } from "lucide-react";
import { errorMessage, hrInterview } from "@/lib/interviewApi";
import type { HRInterview } from "@/types/interview";
import EvaluationView from "./EvaluationView";

interface Props {
  applicationId: number;
  /** False while the CV is still being analysed. */
  canInvite?: boolean;
  /** Called after an invite or reset so the page can reload the decision status. */
  onChanged?: () => void;
}

export default function HRInterviewPanel({ applicationId, canInvite = true, onChanged }: Props) {
  const [iv, setIv] = useState<HRInterview | null>(null);
  const [loaded, setLoaded] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [questions, setQuestions] = useState(5);
  const [focus, setFocus] = useState("");
  const [confirmReset, setConfirmReset] = useState(false);
  const [showTranscript, setShowTranscript] = useState(false);

  const load = useCallback(async () => {
    try {
      setIv(await hrInterview.forApplication(applicationId));
      setError(null);
    } catch (e) {
      setError(errorMessage(e, "Could not load the interview."));
    } finally {
      setLoaded(true);
    }
  }, [applicationId]);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    void load();
  }, [load]);

  // Refresh while something is happening: candidate answering, or the evaluation being written.
  const active = iv && (iv.status === "in_progress" || iv.status === "invited" || (iv.status === "completed" && (iv.eval_status === "pending" || iv.eval_status === "running")));
  useEffect(() => {
    if (!active) return;
    const t = setInterval(() => void load(), iv?.status === "completed" ? 2500 : 6000);
    return () => clearInterval(t);
  }, [active, iv?.status, load]);

  async function invite() {
    setBusy(true);
    setError(null);
    try {
      setIv(await hrInterview.invite(applicationId, { questions, focus: focus.trim() || undefined }));
      onChanged?.();
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  async function reset() {
    if (!iv) return;
    setBusy(true);
    try {
      await hrInterview.reset(iv.id);
      setIv(null);
      setConfirmReset(false);
      setShowTranscript(false);
      onChanged?.();
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  async function reevaluate() {
    if (!iv) return;
    setBusy(true);
    try {
      setIv(await hrInterview.reevaluate(iv.id));
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  if (!loaded) return <p className="text-sm text-neutral-500">Loading interview…</p>;

  const header = (
    <div className="mb-4">
      <h2 className="font-serif text-2xl text-neutral-900">AI interview</h2>
      <p className="text-sm text-neutral-500">A spoken interview that adapts to the candidate&apos;s answers. You get a transcript and an evaluation.</p>
    </div>
  );
  const err = error && <p className="mb-3 rounded-lg bg-red-50 p-3 text-sm text-red-700" role="alert">{error}</p>;

  /* ---- not invited yet ---- */
  if (!iv) {
    return (
      <section className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-sm" data-testid="hr-interview">
        {header}
        {err}
        <div className="grid gap-4 sm:grid-cols-[160px_1fr]">
          <label className="text-sm">
            <span className="mb-1 block font-medium text-neutral-700">Main questions</span>
            <select value={questions} onChange={(e) => setQuestions(Number(e.target.value))} className="w-full rounded-lg border border-neutral-300 bg-white px-2 py-2" data-testid="q-count">
              {[3, 4, 5, 6, 7, 8].map((n) => <option key={n} value={n}>{n}</option>)}
            </select>
          </label>
          <label className="text-sm">
            <span className="mb-1 block font-medium text-neutral-700">Focus (optional)</span>
            <input value={focus} maxLength={300} onChange={(e) => setFocus(e.target.value)} placeholder="e.g. probe deployment experience" className="w-full rounded-lg border border-neutral-300 px-3 py-2" data-testid="focus" />
          </label>
        </div>
        <p className="mt-3 text-xs text-neutral-500">Questions are built from the job, the CV and the skill gaps. Inviting moves the candidate to the &quot;interview&quot; stage and they see a Start button on their applications.</p>
        <button type="button" onClick={invite} disabled={busy || !canInvite} className="mt-4 inline-flex items-center gap-2 rounded-lg bg-[#7a1f3d] px-4 py-2 font-medium text-white hover:bg-[#5e1530] disabled:cursor-not-allowed disabled:opacity-50" data-testid="invite-btn">
          <UserPlus className="h-4 w-4" /> {busy ? "Inviting…" : "Invite to AI interview"}
        </button>
        {!canInvite && <p className="mt-2 text-xs text-amber-700">Wait until the CV has been analysed.</p>}
      </section>
    );
  }

  const progress = Math.round((Math.min(iv.questions_asked, iv.questions_planned) / Math.max(iv.questions_planned, 1)) * 100);

  return (
    <section className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-sm" data-testid="hr-interview">
      {header}
      {err}

      {iv.status === "invited" && (
        <p className="rounded-lg bg-[#fbf3f5] p-3 text-sm text-neutral-700" data-testid="state-invited">
          Invited. Waiting for the candidate to start ({iv.questions_planned} main questions{iv.focus ? `, focus: ${iv.focus}` : ""}).
        </p>
      )}

      {iv.status === "in_progress" && (
        <div data-testid="state-progress">
          <p className="mb-2 text-sm text-neutral-700">In progress: question {Math.min(iv.questions_asked, iv.questions_planned)} of {iv.questions_planned}. This page refreshes by itself.</p>
          <div className="h-2 overflow-hidden rounded-full bg-neutral-100"><div className="h-full bg-[#7a1f3d]" style={{ width: `${progress}%` }} /></div>
        </div>
      )}

      {iv.status === "completed" && (
        <div data-testid="state-completed">
          {iv.evaluation ? (
            <EvaluationView evaluation={iv.evaluation} />
          ) : iv.eval_status === "failed" ? (
            <p className="rounded-lg bg-red-50 p-3 text-sm text-red-700">{iv.eval_error ?? "The evaluation could not be created."} Try again below.</p>
          ) : (
            <p className="text-sm text-neutral-600">The interview is finished. Writing the evaluation…</p>
          )}
        </div>
      )}

      {iv.turns.length > 0 && (
        <div className="mt-5">
          <button type="button" onClick={() => setShowTranscript((v) => !v)} className="text-sm font-medium text-[#7a1f3d] hover:underline" data-testid="toggle-transcript">
            {showTranscript ? "Hide transcript" : `Show transcript (${iv.turns.length} turns)`}
          </button>
          {showTranscript && (
            <div className="mt-3 max-h-96 space-y-2 overflow-y-auto rounded-xl border border-neutral-200 p-3" data-testid="transcript">
              {iv.turns.map((t) => (
                <div key={t.idx} className="text-sm">
                  <span className={`font-semibold ${t.role === "interviewer" ? "text-[#7a1f3d]" : "text-neutral-800"}`}>{t.role === "interviewer" ? "Interviewer" : "Candidate"}</span>
                  {t.role === "candidate" && t.input_mode && <span className="ml-2 rounded bg-neutral-100 px-1.5 py-0.5 text-[10px] uppercase text-neutral-500">{t.input_mode}</span>}
                  <p className="text-neutral-700">{t.text}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      <div className="mt-5 flex flex-wrap items-center gap-3 border-t border-neutral-100 pt-4">
        {iv.turns.length > 0 && (
          <button type="button" onClick={() => hrInterview.downloadTranscript(iv.id)} className="inline-flex items-center gap-2 rounded-lg border border-neutral-300 px-3 py-1.5 text-sm hover:bg-neutral-50">
            <Download className="h-4 w-4" /> Transcript
          </button>
        )}
        {iv.status === "completed" && (
          <button type="button" onClick={reevaluate} disabled={busy || iv.eval_status === "running"} className="inline-flex items-center gap-2 rounded-lg border border-neutral-300 px-3 py-1.5 text-sm hover:bg-neutral-50 disabled:opacity-50">
            <RefreshCw className="h-4 w-4" /> Re-evaluate
          </button>
        )}
        {confirmReset ? (
          <span className="flex flex-wrap items-center gap-2 text-sm text-neutral-700">
            {iv.status === "invited" ? "Cancel this invitation?" : "Delete this interview and its transcript?"}
            <button type="button" onClick={reset} disabled={busy} className="rounded-lg bg-red-600 px-3 py-1.5 text-white hover:bg-red-700" data-testid="confirm-reset">Yes</button>
            <button type="button" onClick={() => setConfirmReset(false)} className="rounded-lg border border-neutral-300 px-3 py-1.5">No</button>
          </span>
        ) : (
          <button type="button" onClick={() => setConfirmReset(true)} className="inline-flex items-center gap-2 text-sm text-red-700 hover:underline" data-testid="reset-btn">
            <Trash2 className="h-4 w-4" /> {iv.status === "invited" ? "Cancel invitation" : "Reset interview"}
          </button>
        )}
      </div>
    </section>
  );
}
