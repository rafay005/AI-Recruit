"use client";

import { useEffect, useState } from "react";
import { hrInterview } from "@/lib/interviewApi";
import HRInterviewPanel from "./HRInterviewPanel";

interface Props {
  applicationId: number;
  /** The HR decision for this candidate: under_review | shortlisted | interview | rejected | hired */
  decision: string;
  analysisStatus?: string;
  onChanged?: () => void;
}

/**
 * Drop this on the HR candidate page. It shows the AI interview card only for
 * candidates whose decision is "interview" (or who already have an interview),
 * so nobody else sees an invite button.
 */
export default function InterviewSection({ applicationId, decision, analysisStatus = "done", onChanged }: Props) {
  const [exists, setExists] = useState(false);

  // For other decisions (e.g. hired later), still show the card if an interview already exists.
  useEffect(() => {
    if (decision === "interview") return;
    let cancelled = false;
    hrInterview
      .forApplication(applicationId)
      .then((iv) => {
        if (!cancelled) setExists(!!iv);
      })
      .catch(() => {
        if (!cancelled) setExists(false);
      });
    return () => {
      cancelled = true;
    };
  }, [applicationId, decision]);

  if (decision !== "interview" && !exists) return null;
  return <HRInterviewPanel applicationId={applicationId} canInvite={analysisStatus === "done"} onChanged={onChanged} />;
}
