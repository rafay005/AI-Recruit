"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Mic } from "lucide-react";
import { candidateInterview } from "@/lib/interviewApi";
import type { InterviewBrief } from "@/types/interview";

/**
 * Drop this inside an application card on "My applications":
 *   <CandidateInterviewButton applicationId={app.id} />
 * It finds out by itself whether HR has invited the candidate and shows the
 * Start interview button. It re-checks every 10 seconds, so no page refresh is needed.
 */
export default function CandidateInterviewButton({ applicationId }: { applicationId: number }) {
  const [interview, setInterview] = useState<InterviewBrief | null>(null);

  useEffect(() => {
    let cancelled = false;
    const check = () =>
      candidateInterview
        .mine()
        .then((list) => {
          if (cancelled) return;
          setInterview(list.find((a) => a.id === applicationId)?.interview ?? null);
        })
        .catch(() => {});
    void check();
    const t = setInterval(check, 10000);
    return () => {
      cancelled = true;
      clearInterval(t);
    };
  }, [applicationId]);

  if (!interview) return null;

  if (interview.status === "completed") {
    return (
      <div className="mt-4 rounded-xl bg-neutral-50 p-4 text-sm text-neutral-700">
        <b>Interview completed.</b> Thank you. The hiring team will review it and get back to you.
      </div>
    );
  }

  const resume = interview.status === "in_progress";
  return (
    <div className="mt-4 flex flex-wrap items-center justify-between gap-4 rounded-xl border border-[#7a1f3d]/30 bg-[#fbf3f5] p-5" data-testid="candidate-interview-box">
      <div>
        <p className="font-semibold text-[#5e1530]">{resume ? "Your AI interview is in progress" : "You are invited to an AI interview"}</p>
        <p className="mt-1 text-sm text-neutral-700">
          {resume
            ? "You can continue where you left off."
            : "It is a spoken conversation with an AI interviewer. Use Chrome or Edge, find a quiet place, and start when you are ready."}
        </p>
      </div>
      <Link
        href={`/candidate/interview/${interview.id}`}
        className="inline-flex items-center gap-2 rounded-lg bg-[#7a1f3d] px-6 py-3 font-semibold text-white shadow hover:bg-[#5e1530]"
        data-testid="start-interview-btn"
      >
        <Mic className="h-5 w-5" /> {resume ? "Resume interview" : "Start interview"}
      </Link>
    </div>
  );
}
