"use client";

import { useState } from "react";
import { CheckCircle2, Mic, ShieldCheck, Volume2, XCircle } from "lucide-react";
import type { CandidateInterview } from "@/types/interview";

export interface RoomSettings {
  readAloud: boolean;
  autoSend: boolean;
  lang: string;
}

const LANGS = [
  { code: "en-US", label: "English (US)" },
  { code: "en-GB", label: "English (UK)" },
  { code: "en-IN", label: "English (India / South Asia)" },
  { code: "en-AU", label: "English (Australia)" },
];

interface Props {
  interview: CandidateInterview;
  sttSupported: boolean;
  ttsSupported: boolean;
  resume: boolean;
  busy: boolean;
  error: string | null;
  onStart: (settings: RoomSettings) => void;
}

export default function PreCheck({ interview, sttSupported, ttsSupported, resume, busy, error, onStart }: Props) {
  const [consent, setConsent] = useState(resume);
  const [readAloud, setReadAloud] = useState(true);
  const [autoSend, setAutoSend] = useState(true);
  const [lang, setLang] = useState("en-US");
  const [mic, setMic] = useState<"unknown" | "ok" | "blocked">("unknown");

  async function testMic() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((t) => t.stop());
      setMic("ok");
    } catch {
      setMic("blocked");
    }
  }

  return (
    <div className="mx-auto max-w-2xl rounded-2xl border border-neutral-200 bg-white p-6 shadow-sm sm:p-8" data-testid="precheck">
      <p className="text-xs font-semibold uppercase tracking-widest text-[#7a1f3d]">AI interview</p>
      <h1 className="mt-1 font-serif text-3xl text-neutral-900">{interview.job_title}</h1>
      {interview.company && <p className="text-neutral-600">{interview.company}</p>}

      <p className="mt-4 text-neutral-700">
        {resume
          ? "Your interview is still open. Continue where you left off."
          : `You will have a spoken conversation with an AI interviewer: about ${interview.questions_planned} main questions, one at a time, plus a few follow-ups. It takes around 10 to 20 minutes (it wraps up after ${interview.max_minutes}).`}
      </p>

      <div className="mt-6 space-y-3 rounded-xl bg-[#fbf3f5] p-4 text-sm text-neutral-700">
        <div className="flex items-start gap-2">
          {sttSupported ? <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" /> : <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" />}
          <span>
            {sttSupported
              ? "Your browser can turn your speech into text."
              : "This browser cannot turn speech into text. You can still take the interview by typing. For voice, use Chrome, Edge or Safari."}
          </span>
        </div>
        <div className="flex items-start gap-2">
          {ttsSupported ? <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" /> : <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" />}
          <span>{ttsSupported ? "Your browser can read the questions aloud." : "Questions will be shown as text only."}</span>
        </div>
        {sttSupported && (
          <div className="flex flex-wrap items-center gap-3">
            <button type="button" onClick={testMic} className="inline-flex items-center gap-2 rounded-lg border border-[#7a1f3d] px-3 py-1.5 text-[#7a1f3d] hover:bg-white">
              <Mic className="h-4 w-4" /> Test microphone
            </button>
            {mic === "ok" && <span className="text-emerald-700">Microphone works.</span>}
            {mic === "blocked" && <span className="text-amber-700">Microphone blocked. Allow it in the address bar, or type your answers.</span>}
          </div>
        )}
      </div>

      <div className="mt-5 grid gap-3 text-sm sm:grid-cols-2">
        <label className="flex items-center gap-2">
          <input type="checkbox" checked={readAloud && ttsSupported} disabled={!ttsSupported} onChange={(e) => setReadAloud(e.target.checked)} />
          <Volume2 className="h-4 w-4 text-neutral-500" /> Read questions aloud
        </label>
        <label className="flex items-center gap-2">
          <input type="checkbox" checked={autoSend && sttSupported} disabled={!sttSupported} onChange={(e) => setAutoSend(e.target.checked)} />
          Send automatically when I stop speaking
        </label>
        <label className="flex items-center gap-2 sm:col-span-2">
          <span className="text-neutral-600">Speech language</span>
          <select value={lang} onChange={(e) => setLang(e.target.value)} className="rounded-lg border border-neutral-300 bg-white px-2 py-1">
            {LANGS.map((l) => (
              <option key={l.code} value={l.code}>{l.label}</option>
            ))}
          </select>
        </label>
      </div>

      {!resume && (
        <label className="mt-6 flex items-start gap-3 rounded-xl border border-neutral-200 p-4 text-sm text-neutral-700">
          <input type="checkbox" className="mt-1" checked={consent} onChange={(e) => setConsent(e.target.checked)} data-testid="consent" />
          <span>
            <span className="mb-1 flex items-center gap-1 font-medium text-neutral-900"><ShieldCheck className="h-4 w-4 text-[#7a1f3d]" /> I understand and agree</span>
            The interviewer is an AI. Your answers are saved as a <b>text transcript</b> (no audio is recorded by us) and reviewed by the hiring team, who make the decision.
            If you speak, your browser&apos;s speech service (for example Google in Chrome) may process your voice to create the text. You can edit what was heard before sending, and you can type instead at any time.
          </span>
        </label>
      )}

      {error && <p className="mt-4 rounded-lg bg-red-50 p-3 text-sm text-red-700" role="alert">{error}</p>}

      <button
        type="button"
        disabled={!consent || busy}
        onClick={() => onStart({ readAloud: readAloud && ttsSupported, autoSend: autoSend && sttSupported, lang })}
        className="mt-6 w-full rounded-xl bg-[#7a1f3d] px-5 py-3 font-medium text-white shadow hover:bg-[#5e1530] disabled:cursor-not-allowed disabled:opacity-50"
        data-testid="start-btn"
      >
        {busy ? "Starting…" : resume ? "Resume interview" : "Start interview"}
      </button>
    </div>
  );
}
