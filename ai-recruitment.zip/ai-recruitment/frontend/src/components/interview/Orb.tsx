"use client";

export type OrbState = "idle" | "speaking" | "listening" | "thinking";

const LABEL: Record<OrbState, string> = {
  idle: "Ready",
  speaking: "Interviewer is speaking",
  listening: "Listening to you",
  thinking: "Thinking…",
};

export default function Orb({ state }: { state: OrbState }) {
  const ring =
    state === "listening" ? "bg-emerald-400/30" : state === "speaking" ? "bg-[#7a1f3d]/25" : state === "thinking" ? "bg-amber-400/25" : "bg-transparent";
  const core =
    state === "listening" ? "bg-emerald-600" : state === "thinking" ? "bg-amber-600" : "bg-[#7a1f3d]";
  return (
    <div className="flex flex-col items-center gap-3" role="status" aria-live="polite" data-testid="orb" data-state={state}>
      <div className="relative flex h-28 w-28 items-center justify-center">
        <span className={`absolute inset-0 rounded-full ${ring} ${state !== "idle" ? "animate-ping" : ""}`} />
        <span className={`absolute inset-3 rounded-full ${ring} ${state === "speaking" || state === "listening" ? "animate-pulse" : ""}`} />
        <span className={`relative flex h-16 w-16 items-center justify-center rounded-full ${core} text-xl font-semibold text-white shadow-lg transition-colors`}>
          AI
        </span>
      </div>
      <p className="text-sm font-medium text-neutral-600">{LABEL[state]}</p>
    </div>
  );
}
