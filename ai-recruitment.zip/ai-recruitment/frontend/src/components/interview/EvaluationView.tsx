import { AlertTriangle } from "lucide-react";
import type { Evaluation } from "@/types/interview";

function Dots({ value }: { value: number | null }) {
  if (value == null) return <span className="text-xs text-neutral-400">Not assessed</span>;
  return (
    <span className="inline-flex gap-1" aria-label={`${value} out of 5`}>
      {[1, 2, 3, 4, 5].map((i) => (
        <span key={i} className={`h-2.5 w-2.5 rounded-full ${i <= value ? "bg-[#7a1f3d]" : "bg-neutral-200"}`} />
      ))}
    </span>
  );
}

function Ring({ score }: { score: number }) {
  const r = 34;
  const c = 2 * Math.PI * r;
  const tone = score >= 65 ? "#059669" : score >= 45 ? "#d97706" : "#dc2626";
  return (
    <svg width="88" height="88" viewBox="0 0 88 88" role="img" aria-label={`Interview score ${score} out of 100`}>
      <circle cx="44" cy="44" r={r} fill="none" stroke="#eee" strokeWidth="9" />
      <circle cx="44" cy="44" r={r} fill="none" stroke={tone} strokeWidth="9" strokeLinecap="round" strokeDasharray={`${(score / 100) * c} ${c}`} transform="rotate(-90 44 44)" />
      <text x="44" y="50" textAnchor="middle" fontSize="22" fontWeight="600" fill="#262626">{score}</text>
    </svg>
  );
}

export default function EvaluationView({ evaluation: e }: { evaluation: Evaluation }) {
  const mins = e.duration_seconds != null ? Math.max(1, Math.round(e.duration_seconds / 60)) : null;
  return (
    <div className="space-y-5" data-testid="evaluation">
      <div className="flex flex-wrap items-center gap-5">
        <Ring score={e.overall} />
        <div className="min-w-0 flex-1">
          <p className="font-serif text-2xl text-neutral-900">{e.label}</p>
          <p className="text-sm text-neutral-500">
            Answered {e.questions_answered} of {e.questions_planned} planned questions{mins ? ` · about ${mins} min` : ""}
            {e.ended_early ? " · ended early" : ""} · {e.source === "ai" ? `AI evaluation${e.model ? ` (${e.model})` : ""}` : "Built-in evaluation"}
          </p>
        </div>
      </div>

      <p className="text-neutral-700">{e.summary}</p>

      {e.note && <p className="rounded-lg bg-amber-50 p-3 text-sm text-amber-800">{e.note}</p>}
      {e.flags.length > 0 && (
        <div className="rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">
          <p className="mb-1 flex items-center gap-2 font-medium"><AlertTriangle className="h-4 w-4" /> Flags</p>
          <ul className="list-disc space-y-1 pl-5">{e.flags.map((f, i) => <li key={i}>{f}</li>)}</ul>
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <p className="mb-1 text-sm font-semibold text-emerald-700">Strengths</p>
          {e.strengths.length ? <ul className="list-disc space-y-1 pl-5 text-sm text-neutral-700">{e.strengths.map((s, i) => <li key={i}>{s}</li>)}</ul> : <p className="text-sm text-neutral-400">None noted.</p>}
        </div>
        <div>
          <p className="mb-1 text-sm font-semibold text-amber-700">Concerns</p>
          {e.concerns.length ? <ul className="list-disc space-y-1 pl-5 text-sm text-neutral-700">{e.concerns.map((s, i) => <li key={i}>{s}</li>)}</ul> : <p className="text-sm text-neutral-400">None noted.</p>}
        </div>
      </div>

      <div>
        <p className="mb-2 text-sm font-semibold text-neutral-800">Communication</p>
        <div className="flex items-center gap-3 text-sm text-neutral-700"><Dots value={e.communication.score} /> {e.communication.notes}</div>
      </div>

      {e.skills.length > 0 && (
        <div>
          <p className="mb-2 text-sm font-semibold text-neutral-800">Required skills in the interview</p>
          <ul className="divide-y divide-neutral-100 rounded-xl border border-neutral-200">
            {e.skills.map((s) => (
              <li key={s.skill} className="flex flex-wrap items-center justify-between gap-2 px-3 py-2 text-sm">
                <span className="font-medium text-neutral-800">{s.skill}</span>
                <span className="flex items-center gap-3"><span className="text-neutral-500">{s.evidence}</span><Dots value={s.rating} /></span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {e.answers.length > 0 && (
        <div>
          <p className="mb-2 text-sm font-semibold text-neutral-800">Answer by answer</p>
          <ul className="space-y-2">
            {e.answers.map((a, i) => (
              <li key={i} className="text-sm">
                <div className="flex justify-between gap-3"><span className="text-neutral-800">{a.question}</span><span className="shrink-0 font-medium text-neutral-600">{a.score}</span></div>
                <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-neutral-100"><div className="h-full bg-[#7a1f3d]" style={{ width: `${a.score}%` }} /></div>
                <p className="mt-1 text-neutral-500">{a.comment}</p>
              </li>
            ))}
          </ul>
        </div>
      )}

      <p className="text-xs text-neutral-400">
        This score supports your decision, it does not make it. Speech-to-text can contain mistakes and accents are never penalised. Read the transcript before deciding.
      </p>
    </div>
  );
}
