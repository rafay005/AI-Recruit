"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { Download, Keyboard, Mic, MicOff, PhoneOff, RotateCcw, Send, Volume2 } from "lucide-react";
import { candidateInterview, errorMessage } from "@/lib/interviewApi";
import { PROBLEM_TEXT, useSpeech } from "@/lib/useSpeech";
import type { CandidateInterview, InputMode, Turn, TurnsResult } from "@/types/interview";
import Orb, { type OrbState } from "./Orb";
import PreCheck, { type RoomSettings } from "./PreCheck";

type Phase = "loading" | "precheck" | "live" | "done" | "error";

function fmt(sec: number) {
  const s = Math.max(0, Math.floor(sec));
  return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
}

export default function InterviewRoom({ interviewId }: { interviewId: number }) {
  const [phase, setPhase] = useState<Phase>("loading");
  const [iv, setIv] = useState<CandidateInterview | null>(null);
  const [turns, setTurns] = useState<Turn[]>([]);
  const [asked, setAsked] = useState(0);
  const [settings, setSettings] = useState<RoomSettings>({ readAloud: true, autoSend: true, lang: "en-US" });
  const [draft, setDraft] = useState("");
  const [thinking, setThinking] = useState(false);
  const [starting, setStarting] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [confirmEnd, setConfirmEnd] = useState(false);
  const [now, setNow] = useState(() => Date.now());
  const [showLog, setShowLog] = useState(false);

  const fromVoice = useRef(false);
  const alive = useRef(true);
  const busyRef = useRef(false);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const logRef = useRef<HTMLDivElement | null>(null);
  const submitRef = useRef<(text: string, mode: InputMode) => void>(() => {});
  const settingsRef = useRef(settings);

  useEffect(() => {
    settingsRef.current = settings;
  }, [settings]);

  const speech = useSpeech({
    lang: settings.lang,
    onSilence: (text) => {
      if (settingsRef.current.autoSend) submitRef.current(text, "voice");
    },
  });
  const { speak, stopSpeaking, startListening, stopListening, sttSupported, ttsSupported } = speech;

  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
    };
  }, []);

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    logRef.current?.scrollTo({ top: logRef.current.scrollHeight });
  }, [turns, showLog]);

  /* ------------------------------------------------------------ load */
  useEffect(() => {
    let cancelled = false;
    candidateInterview
      .get(interviewId)
      .then((data) => {
        if (cancelled) return;
        setIv(data);
        setTurns(data.turns);
        setAsked(data.questions_asked);
        setPhase(data.status === "completed" ? "done" : "precheck");
      })
      .catch((e) => {
        if (cancelled) return;
        setMessage(errorMessage(e, "We could not open this interview."));
        setPhase("error");
      });
    return () => {
      cancelled = true;
    };
  }, [interviewId]);

  /* ------------------------------------------------------------ the turn loop */
  const beginListening = useCallback(() => {
    if (!alive.current || !sttSupported) return;
    fromVoice.current = true;
    setDraft("");
    startListening();
  }, [sttSupported, startListening]);

  /** Show new turns, speak the interviewer's words, then open the microphone. */
  const deliver = useCallback(
    async (result: Pick<TurnsResult, "new_turns" | "done" | "questions_asked">, s: RoomSettings) => {
      setTurns((prev) => [...prev, ...result.new_turns.filter((t) => !prev.some((p) => p.idx === t.idx))]);
      setAsked(result.questions_asked);
      const said = result.new_turns.filter((t) => t.role === "interviewer").map((t) => t.text).join(" ");
      if (result.done) {
        setPhase("done");
        if (s.readAloud && said) await speak(said);
        return;
      }
      if (s.readAloud && said) await speak(said);
      if (alive.current) beginListening();
    },
    [speak, beginListening],
  );

  /** After a failed request the answer may or may not have been saved: ask the server. */
  const recover = useCallback(
    async (s: RoomSettings, keepText: string) => {
      try {
        const fresh = await candidateInterview.get(interviewId);
        setIv(fresh);
        if (fresh.status === "completed") {
          setTurns(fresh.turns);
          setPhase("done");
          return;
        }
        if (fresh.needs_reply) {
          setTurns(fresh.turns);
          const res = await candidateInterview.resume(interviewId);
          setMessage(null);
          await deliver(res, s);
          return;
        }
        setTurns(fresh.turns);
        setDraft(keepText);
      } catch (e) {
        setDraft(keepText);
        setMessage(errorMessage(e));
      }
    },
    [interviewId, deliver],
  );

  const submit = useCallback(
    async (rawText: string, mode: InputMode) => {
      const text = rawText.replace(/\s+/g, " ").trim();
      if (!text || busyRef.current) return;
      busyRef.current = true;
      stopListening();
      stopSpeaking();
      setMessage(null);
      setDraft("");
      setThinking(true);
      // Show the candidate's own words right away.
      setTurns((prev) => [
        ...prev,
        { idx: (prev[prev.length - 1]?.idx ?? -1) + 0.5, role: "candidate", kind: "answer", text, created_at: new Date().toISOString() },
      ]);
      const s = settingsRef.current;
      try {
        const res = await candidateInterview.answer(interviewId, text, mode);
        setThinking(false);
        busyRef.current = false;
        await deliver(res, s);
      } catch (e) {
        setMessage(errorMessage(e));
        setTurns((prev) => prev.filter((t) => Number.isInteger(t.idx)));
        setThinking(false);
        await recover(s, text);
        busyRef.current = false;
      }
    },
    [interviewId, deliver, recover, stopListening, stopSpeaking],
  );

  useEffect(() => {
    submitRef.current = (t, m) => void submit(t, m);
  }, [submit]);

  /* ------------------------------------------------------------ start / resume */
  async function handleStart(s: RoomSettings) {
    if (!iv) return;
    setSettings(s);
    setStarting(true);
    setMessage(null);
    try {
      if (iv.status === "in_progress") {
        // Resuming: speak the last question again, or finish a reply that never arrived.
        setPhase("live");
        if (iv.needs_reply) {
          const res = await candidateInterview.resume(interviewId);
          await deliver(res, s);
        } else {
          const last = [...iv.turns].reverse().find((t) => t.role === "interviewer");
          if (s.readAloud && last) await speak(last.text);
          beginListening();
        }
      } else {
        const res = await candidateInterview.start(interviewId, true);
        setPhase("live");
        setIv({ ...iv, status: "in_progress", started_at: new Date().toISOString() });
        await deliver(res, s);
      }
    } catch (e) {
      setMessage(errorMessage(e));
      setPhase("precheck");
    } finally {
      setStarting(false);
    }
  }

  /* ------------------------------------------------------------ buttons */
  function toggleMic() {
    if (speech.listening) {
      const text = stopListening();
      setDraft(text);
    } else {
      beginListening();
    }
  }

  function reRecord() {
    stopListening();
    setDraft("");
    beginListening();
  }

  function typeInstead() {
    const text = stopListening();
    if (text) setDraft(text);
    stopSpeaking();
    textareaRef.current?.focus();
  }

  async function repeatQuestion() {
    const last = [...turns].reverse().find((t) => t.role === "interviewer");
    if (!last) return;
    stopListening();
    await speak(last.text);
    beginListening();
  }

  async function endInterview() {
    setConfirmEnd(false);
    stopListening();
    stopSpeaking();
    busyRef.current = true;
    setThinking(true);
    try {
      const res = await candidateInterview.end(interviewId);
      setThinking(false);
      busyRef.current = false;
      await deliver(res, settings);
    } catch (e) {
      setThinking(false);
      busyRef.current = false;
      setMessage(errorMessage(e));
    }
  }

  /* ------------------------------------------------------------ render */
  if (phase === "loading") return <p className="py-20 text-center text-neutral-500">Opening your interview…</p>;
  if (phase === "error" || !iv)
    return (
      <div className="mx-auto max-w-md py-20 text-center">
        <p className="text-red-700" role="alert">{message ?? "This interview is not available."}</p>
        <Link href="/candidate/applications" className="mt-4 inline-block text-[#7a1f3d] underline">Back to my applications</Link>
      </div>
    );

  if (phase === "precheck")
    return (
      <PreCheck
        interview={iv}
        sttSupported={sttSupported}
        ttsSupported={ttsSupported}
        resume={iv.status === "in_progress"}
        busy={starting}
        error={message}
        onStart={handleStart}
      />
    );

  const lastInterviewer = [...turns].reverse().find((t) => t.role === "interviewer");
  const done = phase === "done";
  const orb: OrbState = thinking ? "thinking" : speech.speaking ? "speaking" : speech.listening ? "listening" : "idle";
  const shownText = speech.listening ? speech.liveText : draft;
  const startedMs = iv.started_at ? new Date(iv.started_at).getTime() : now;
  const remaining = iv.max_minutes * 60 - (now - startedMs) / 1000;
  const progress = Math.min(100, Math.round((Math.min(asked, iv.questions_planned) / Math.max(iv.questions_planned, 1)) * 100));

  return (
    <div className="mx-auto grid max-w-5xl gap-6 lg:grid-cols-[1fr_320px]" data-testid="room">
      <section className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-sm sm:p-8">
        <header className="mb-4 flex flex-wrap items-center justify-between gap-2 text-sm text-neutral-500">
          <span className="font-medium text-neutral-800">{iv.job_title}{iv.company ? ` · ${iv.company}` : ""}</span>
          {!done && <span data-testid="timer">Time left {fmt(remaining)}</span>}
        </header>
        <div className="mb-6 h-1.5 overflow-hidden rounded-full bg-neutral-100" aria-label="Progress">
          <div className="h-full bg-[#7a1f3d] transition-all" style={{ width: `${done ? 100 : progress}%` }} />
        </div>
        <p className="mb-8 text-center text-xs uppercase tracking-widest text-neutral-400">
          {done ? "Interview finished" : `Question ${Math.min(Math.max(asked, 1), iv.questions_planned)} of ${iv.questions_planned}`}
        </p>

        <Orb state={done ? "idle" : orb} />

        <p className="mx-auto mt-6 max-w-xl text-center font-serif text-xl leading-snug text-neutral-900" data-testid="caption" aria-live="polite">
          {lastInterviewer?.text ?? "…"}
        </p>

        {done ? (
          <div className="mt-8 text-center" data-testid="done">
            <p className="text-neutral-700">Thank you. The hiring team will review your interview and be in touch.</p>
            <div className="mt-5 flex flex-wrap justify-center gap-3">
              <button type="button" onClick={() => candidateInterview.downloadTranscript(interviewId)} className="inline-flex items-center gap-2 rounded-lg border border-[#7a1f3d] px-4 py-2 text-[#7a1f3d] hover:bg-[#fbf3f5]">
                <Download className="h-4 w-4" /> Download my transcript
              </button>
              <Link href="/candidate/applications" className="rounded-lg bg-[#7a1f3d] px-4 py-2 text-white hover:bg-[#5e1530]">Back to my applications</Link>
            </div>
          </div>
        ) : (
          <div className="mt-8">
            <label htmlFor="answer" className="mb-1 block text-sm font-medium text-neutral-700">
              {speech.listening ? "Listening… speak your answer" : "Your answer (you can edit it before sending)"}
            </label>
            <textarea
              id="answer"
              ref={textareaRef}
              rows={4}
              value={shownText}
              disabled={thinking}
              placeholder={sttSupported ? "Tap the microphone and speak, or type here." : "Type your answer here."}
              onChange={(e) => {
                if (speech.listening) stopListening();
                if (!draft && !shownText) fromVoice.current = false;
                setDraft(e.target.value);
              }}
              className="w-full resize-y rounded-xl border border-neutral-300 p-3 text-neutral-900 focus:border-[#7a1f3d] focus:outline-none focus:ring-2 focus:ring-[#7a1f3d]/20 disabled:bg-neutral-50"
              data-testid="answer"
            />

            {(speech.problem || message) && (
              <p className="mt-2 rounded-lg bg-amber-50 p-2 text-sm text-amber-800" role="alert" data-testid="notice">
                {message ?? (speech.problem ? PROBLEM_TEXT[speech.problem] : "")}
              </p>
            )}

            <div className="mt-3 flex flex-wrap items-center gap-2">
              {sttSupported && (
                <button type="button" onClick={toggleMic} disabled={thinking} aria-pressed={speech.listening} className={`inline-flex items-center gap-2 rounded-lg px-3 py-2 text-white ${speech.listening ? "bg-emerald-600 hover:bg-emerald-700" : "bg-neutral-700 hover:bg-neutral-800"} disabled:opacity-50`} data-testid="mic-btn">
                  {speech.listening ? <Mic className="h-4 w-4" /> : <MicOff className="h-4 w-4" />}
                  {speech.listening ? "Stop" : "Speak"}
                </button>
              )}
              <button type="button" disabled={thinking || !shownText.trim()} onClick={() => submit(shownText, fromVoice.current ? "voice" : "typed")} className="inline-flex items-center gap-2 rounded-lg bg-[#7a1f3d] px-4 py-2 font-medium text-white hover:bg-[#5e1530] disabled:cursor-not-allowed disabled:opacity-50" data-testid="send-btn">
                <Send className="h-4 w-4" /> Send answer
              </button>
              {sttSupported && (
                <button type="button" onClick={reRecord} disabled={thinking} className="inline-flex items-center gap-2 rounded-lg border border-neutral-300 px-3 py-2 text-neutral-700 hover:bg-neutral-50 disabled:opacity-50">
                  <RotateCcw className="h-4 w-4" /> Re-record
                </button>
              )}
              {sttSupported && (
                <button type="button" onClick={typeInstead} disabled={thinking} className="inline-flex items-center gap-2 rounded-lg border border-neutral-300 px-3 py-2 text-neutral-700 hover:bg-neutral-50 disabled:opacity-50">
                  <Keyboard className="h-4 w-4" /> Type instead
                </button>
              )}
              {ttsSupported && (
                <button type="button" onClick={repeatQuestion} disabled={thinking} className="inline-flex items-center gap-2 rounded-lg border border-neutral-300 px-3 py-2 text-neutral-700 hover:bg-neutral-50 disabled:opacity-50">
                  <Volume2 className="h-4 w-4" /> Repeat question
                </button>
              )}
            </div>

            <div className="mt-6 border-t border-neutral-100 pt-4">
              {confirmEnd ? (
                <p className="flex flex-wrap items-center gap-3 text-sm text-neutral-700">
                  End the interview now? It cannot be restarted.
                  <button type="button" onClick={endInterview} className="rounded-lg bg-red-600 px-3 py-1.5 text-white hover:bg-red-700" data-testid="confirm-end">Yes, end it</button>
                  <button type="button" onClick={() => setConfirmEnd(false)} className="rounded-lg border border-neutral-300 px-3 py-1.5">Keep going</button>
                </p>
              ) : (
                <button type="button" onClick={() => setConfirmEnd(true)} className="inline-flex items-center gap-2 text-sm text-red-700 hover:underline" data-testid="end-btn">
                  <PhoneOff className="h-4 w-4" /> End interview
                </button>
              )}
            </div>
          </div>
        )}
      </section>

      <aside className="rounded-2xl border border-neutral-200 bg-white p-4 shadow-sm">
        <button type="button" onClick={() => setShowLog((v) => !v)} className="mb-2 flex w-full items-center justify-between text-sm font-medium text-neutral-800 lg:cursor-default">
          Conversation
          <span className="text-xs text-[#7a1f3d] lg:hidden">{showLog ? "Hide" : "Show"}</span>
        </button>
        <div ref={logRef} className={`${showLog ? "block" : "hidden"} max-h-[28rem] space-y-3 overflow-y-auto lg:block`} data-testid="log">
          {turns.map((t, i) => (
            <div key={`${t.idx}-${i}`} className={t.role === "candidate" ? "text-right" : ""}>
              <p className={`inline-block max-w-full rounded-xl px-3 py-2 text-left text-sm ${t.role === "candidate" ? "bg-[#fbf3f5] text-neutral-900" : "bg-neutral-100 text-neutral-800"}`}>
                {t.text}
              </p>
            </div>
          ))}
          {thinking && <p className="text-sm italic text-neutral-400">The interviewer is thinking…</p>}
        </div>
      </aside>
    </div>
  );
}
