"use client";

import { useRef, useState } from "react";
import { FileText, UploadCloud, X } from "lucide-react";

interface Props {
  file: File | null;
  onChange: (file: File | null) => void;
  maxMB?: number;
}

const ALLOWED = [".pdf", ".docx"];

function formatSize(bytes: number): string {
  return bytes < 1024 * 1024
    ? `${Math.max(1, Math.round(bytes / 1024))} KB`
    : `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

export default function FileDrop({ file, onChange, maxMB = 5 }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [over, setOver] = useState(false);
  const [error, setError] = useState("");

  function pick(f: File | undefined | null) {
    setError("");
    if (!f) return;
    const ext = f.name.slice(f.name.lastIndexOf(".")).toLowerCase();
    if (!ALLOWED.includes(ext)) {
      setError("Please choose a PDF or DOCX file.");
      return;
    }
    if (f.size > maxMB * 1024 * 1024) {
      setError(`This file is larger than ${maxMB} MB.`);
      return;
    }
    if (f.size === 0) {
      setError("This file is empty.");
      return;
    }
    onChange(f);
  }

  return (
    <div>
      {file ? (
        <div className="flex items-center gap-3 rounded-xl border border-maroon-200 bg-maroon-50 p-4">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-white text-maroon-700">
            <FileText size={20} />
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium">{file.name}</p>
            <p className="text-xs text-muted">{formatSize(file.size)}</p>
          </div>
          <button
            type="button"
            onClick={() => {
              onChange(null);
              if (inputRef.current) inputRef.current.value = "";
            }}
            aria-label="Remove file"
            className="rounded-lg p-2 text-maroon-700 hover:bg-white"
          >
            <X size={18} />
          </button>
        </div>
      ) : (
        <label
          onDragOver={(e) => {
            e.preventDefault();
            setOver(true);
          }}
          onDragLeave={() => setOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setOver(false);
            pick(e.dataTransfer.files?.[0]);
          }}
          className={`flex cursor-pointer flex-col items-center gap-2 rounded-xl border-2 border-dashed px-6 py-10 text-center transition focus-within:outline-2 focus-within:outline-maroon-600 ${
            over ? "border-maroon-600 bg-maroon-50" : "border-line bg-white hover:border-maroon-300"
          }`}
        >
          <UploadCloud size={28} className="text-maroon-600" />
          <span className="font-medium">
            Drop your CV here or <span className="text-maroon-700 underline">browse</span>
          </span>
          <span className="text-xs text-muted">PDF or DOCX, up to {maxMB} MB. Scanned CVs are supported.</span>
          <input
            ref={inputRef}
            type="file"
            accept=".pdf,.docx,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            className="sr-only"
            onChange={(e) => pick(e.target.files?.[0])}
          />
        </label>
      )}
      {error && (
        <p role="alert" className="mt-2 text-sm text-red-700">
          {error}
        </p>
      )}
    </div>
  );
}
