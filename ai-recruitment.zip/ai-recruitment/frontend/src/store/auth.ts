import { create } from "zustand";
import { api } from "@/lib/api";

export interface User {
  id: number;
  full_name: string;
  email: string;
  role: "hr" | "candidate";
  company: string | null;
}

interface AuthState {
  user: User | null;
  login: (email: string, password: string) => Promise<User>;
  logout: () => void;
  loadUser: () => Promise<User | null>;
}

export const useAuth = create<AuthState>((set) => ({
  user: null,

  login: async (email, password) => {
    const form = new URLSearchParams();
    form.append("username", email);
    form.append("password", password);

    const { data } = await api.post("/api/auth/login", form, {
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
    });

    localStorage.setItem("token", data.access_token);
    set({ user: data.user });
    return data.user as User;
  },

  logout: () => {
    localStorage.removeItem("token");
    set({ user: null });
  },

  loadUser: async () => {
    if (!localStorage.getItem("token")) {
      set({ user: null });
      return null;
    }
    try {
      const { data } = await api.get("/api/auth/me");
      set({ user: data });
      return data as User;
    } catch {
      localStorage.removeItem("token");
      set({ user: null });
      return null;
    }
  },
}));
