export interface EducationItem {
  degree: string | null;
  field: string | null;
  institution: string | null;
  start: string | null;
  end: string | null;
  grade: string | null;
}

export interface ExperienceItem {
  title: string | null;
  company: string | null;
  start: string | null;
  end: string | null;
  description: string | null;
}

export interface ProjectItem {
  name: string | null;
  description: string | null;
  technologies: string[];
}

export interface CertificationItem {
  name: string | null;
  issuer: string | null;
  date: string | null;
}

export interface ExtractedCV {
  name: string | null;
  email: string | null;
  phone: string | null;
  summary: string | null;
  education: EducationItem[];
  experience: ExperienceItem[];
  skills: string[];
  projects: ProjectItem[];
  certifications: CertificationItem[];
  total_experience_years: number | null;
}

export type Decision = "under_review" | "shortlisted" | "interview" | "rejected" | "hired";

export const DECISIONS: { value: Decision; hr: string; candidate: string }[] = [
  { value: "under_review", hr: "Under review", candidate: "Under review" },
  { value: "shortlisted", hr: "Shortlisted", candidate: "Shortlisted" },
  { value: "interview", hr: "Interview", candidate: "Interview stage" },
  { value: "rejected", hr: "Rejected", candidate: "Not selected" },
  { value: "hired", hr: "Hired", candidate: "Selected" },
];

export type AnalysisStatus = "pending" | "processing" | "done" | "failed";

export interface Application {
  id: number;
  job: { id: number; title: string; company: string | null };
  phone: string | null;
  cover_note: string | null;
  cv_filename: string;
  cv_size: number;
  analysis_status: AnalysisStatus;
  analysis_error: string | null;
  analysis_note: string | null;
  extraction_method: "pdf_text" | "docx" | "ocr" | "vlm" | null;
  analysis_model: string | null;
  created_at: string;
  analyzed_at: string | null;
  extracted: ExtractedCV | null;
  decision: Decision;
  decision_note: string | null;
  decision_at: string | null;
}

export interface HRApplication extends Application {
  candidate_account_name: string;
  candidate_account_email: string;
  parsed_text: string | null;
}

export interface ApplicationListItem {
  id: number;
  job_id: number;
  job_title: string;
  candidate_name: string;
  candidate_email: string;
  cv_filename: string;
  created_at: string;
  analysis_status: AnalysisStatus;
  skills: string[];
  total_experience_years: number | null;
  extraction_method: string | null;
  match_percent: number | null;
  match_label: string | null;
  decision: Decision;
}

export function methodLabel(m: Application["extraction_method"] | string | null): string {
  switch (m) {
    case "pdf_text":
      return "Read directly from the PDF";
    case "docx":
      return "Read directly from the DOCX";
    case "ocr":
      return "Scanned CV, read with OCR";
    case "vlm":
      return "Scanned CV, read with AI vision";
    default:
      return "";
  }
}
