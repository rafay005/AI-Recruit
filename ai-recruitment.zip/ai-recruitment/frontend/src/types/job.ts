export type JobStatus = "draft" | "approved" | "published";

export interface JobInput {
  title: string;
  department: string | null;
  location: string | null;
  employment_type: string;
  work_mode: string;
  experience_level: string;
  min_experience_years: number | null;
  max_experience_years: number | null;
  education: string | null;
  salary_min: number | null;
  salary_max: number | null;
  salary_currency: string | null;
  show_salary: boolean;
  openings: number;
  application_deadline: string | null; // YYYY-MM-DD
  required_skills: string[];
  nice_to_have_skills: string[];
  responsibilities: string | null;
  company_about: string | null;
}

export interface Job extends JobInput {
  id: number;
  jd_text: string | null;
  jd_source: "ai" | "template" | "manual" | null;
  jd_edited: boolean;
  jd_model: string | null;
  status: JobStatus;
  approved_at: string | null;
  published_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface JobListItem {
  applicant_count: number;
  id: number;
  title: string;
  department: string | null;
  location: string | null;
  employment_type: string;
  work_mode: string;
  experience_level: string;
  openings: number;
  application_deadline: string | null;
  status: JobStatus;
  published_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface PublicJob {
  id: number;
  title: string;
  company: string | null;
  department: string | null;
  location: string | null;
  employment_type: string;
  work_mode: string;
  experience_level: string;
  openings: number;
  application_deadline: string | null;
  required_skills: string[];
  nice_to_have_skills: string[];
  salary_min: number | null;
  salary_max: number | null;
  salary_currency: string | null;
  jd_text: string | null;
  published_at: string | null;
}

export const EMPLOYMENT_TYPES = [
  { value: "full_time", label: "Full-time" },
  { value: "part_time", label: "Part-time" },
  { value: "contract", label: "Contract" },
  { value: "internship", label: "Internship" },
];

export const WORK_MODES = [
  { value: "onsite", label: "On-site" },
  { value: "hybrid", label: "Hybrid" },
  { value: "remote", label: "Remote" },
];

export const EXPERIENCE_LEVELS = [
  { value: "entry", label: "Entry level" },
  { value: "mid", label: "Mid level" },
  { value: "senior", label: "Senior level" },
  { value: "lead", label: "Lead / Principal" },
];

export function labelOf(
  options: { value: string; label: string }[],
  value: string
): string {
  return options.find((o) => o.value === value)?.label ?? value;
}
