export type SkillStatus = "match" | "related" | "missing";

export interface SkillMatch {
  skill: string;
  status: SkillStatus;
  evidence: string | null;
  via: string | null;
  method?: "exact" | "meaning" | "similar" | "none";
  snippet?: string | null;
  source?: string | null;
  score?: number;
  confidence?: number | null;
}

export interface RelevanceItem {
  text: string;
  score: number;
  status: "strong" | "partial" | "weak";
  snippet: string | null;
  source: string | null;
}

export interface RelevanceBlock {
  applicable: boolean;
  score: number | null;
  items: RelevanceItem[];
}

export interface SkillsBlock {
  total: number;
  matched: number;
  related: number;
  missing: number;
  score: number;
  items: SkillMatch[];
}

export interface ExperienceBlock {
  applicable: boolean;
  status: "meets" | "below" | "unknown" | "na";
  required_min: number | null;
  required_max: number | null;
  candidate_years: number | null;
  score: number | null;
}

export interface EducationBlock {
  applicable: boolean;
  status: "meets" | "below" | "unknown" | "na";
  required: string | null;
  candidate: string | null;
  score: number | null;
}

export interface MatchBreakdown {
  overall: number;
  label: string;
  required: SkillsBlock;
  nice_to_have: SkillsBlock | null;
  experience: ExperienceBlock;
  education: EducationBlock;
  relevance?: RelevanceBlock;
  weights: Record<string, number>;
  search_mode?: "hybrid" | "keyword";
  role_family?: string | null;
}

export interface RankedCandidate {
  rank: number;
  application_id: number;
  candidate_name: string;
  candidate_email: string;
  years: number | null;
  applied_at: string;
  match: MatchBreakdown;
  gap: { verdict: "none" | "trainable" | "critical"; critical: number; trainable: number; missing: string[] } | null;
  decision: "under_review" | "shortlisted" | "interview" | "rejected" | "hired";
}

export interface UnrankedCandidate {
  application_id: number;
  candidate_name: string;
  analysis_status: string;
  reason: string;
}

export interface JobCriteria {
  id: number;
  title: string;
  required_skills: string[];
  nice_to_have_skills: string[];
  min_experience_years: number | null;
  max_experience_years: number | null;
  education: string | null;
}

export interface Ranking {
  job: JobCriteria;
  ranked: RankedCandidate[];
  unranked: UnrankedCandidate[];
}

export interface CandidateMatch {
  job: JobCriteria;
  rank: number | null;
  total_ranked: number;
  match: MatchBreakdown | null;
  reason: string | null;
}
