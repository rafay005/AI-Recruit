export type InterviewStatus = "invited" | "in_progress" | "completed";
export type TurnKind = "greeting" | "question" | "followup" | "clarify" | "closing" | "answer";
export type InputMode = "voice" | "typed";

export interface InterviewBrief {
  id: number;
  status: InterviewStatus;
}

export interface Turn {
  idx: number;
  role: "interviewer" | "candidate";
  kind: TurnKind;
  text: string;
  created_at: string;
}

export interface HRTurn extends Turn {
  topic: string | null;
  input_mode: InputMode | null;
  source: string | null;
}

/** What the candidate sees. There is never a score or an evaluation in here. */
export interface CandidateInterview {
  id: number;
  status: InterviewStatus;
  job_title: string;
  company: string | null;
  mode: "ai" | "built-in" | null;
  questions_planned: number;
  questions_asked: number;
  started_at: string | null;
  completed_at: string | null;
  max_minutes: number;
  turns: Turn[];
  can_answer: boolean;
  needs_reply: boolean;
}

export interface TurnsResult {
  new_turns: Turn[];
  status: InterviewStatus;
  done: boolean;
  questions_asked: number;
  questions_planned: number;
}

export interface SkillRating {
  skill: string;
  rating: number | null;
  evidence: string;
}

export interface AnswerScore {
  question: string;
  score: number;
  comment: string;
}

export interface Evaluation {
  source: "ai" | "built-in";
  model: string | null;
  overall: number;
  label: string;
  summary: string;
  strengths: string[];
  concerns: string[];
  communication: { score: number; notes: string };
  skills: SkillRating[];
  answers: AnswerScore[];
  flags: string[];
  questions_answered: number;
  questions_planned: number;
  ended_early: boolean;
  ended_reason: string | null;
  duration_seconds: number | null;
  note: string | null;
}

export interface HRInterview {
  id: number;
  application_id: number;
  status: InterviewStatus;
  mode: "ai" | "built-in" | null;
  questions_planned: number;
  questions_asked: number;
  focus: string | null;
  invited_at: string;
  started_at: string | null;
  completed_at: string | null;
  ended_reason: string | null;
  eval_status: "pending" | "running" | "done" | "failed";
  eval_error: string | null;
  evaluation: Evaluation | null;
  turns: HRTurn[];
}

export interface InterviewChipData {
  status: InterviewStatus;
  score?: number | null;
  label?: string | null;
}
