import type { JobCriteria } from "@/types/ranking";

export interface GapItem {
  skill: string;
  status: "missing" | "related";
  severity: "critical" | "trainable";
  effort: string;
  reason: string;
  how_to_close: string;
  similar_skill: string | null;
}

export interface GapAssessment {
  source: "built-in" | "ai";
  model: string | null;
  verdict: "none" | "trainable" | "critical";
  summary: string;
  items: GapItem[];
}

export interface SkillGap {
  application_id: number;
  candidate_name: string;
  job: JobCriteria;
  required: string[];
  candidate_has: string[];
  candidate_extra: string[];
  missing: string[];
  similar: string[];
  nice_missing: string[];
  assessment: GapAssessment;
  ai_available: boolean;
  ai_cached: boolean;
  generated_at: string | null;
}
