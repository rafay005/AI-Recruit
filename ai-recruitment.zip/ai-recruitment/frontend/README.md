# Frontend files (Phase 1)

These files go on top of a fresh Next.js project. See the setup steps in the chat.
After copying them in, run from this folder:

```
npm install axios zustand lucide-react
npm run dev
```
