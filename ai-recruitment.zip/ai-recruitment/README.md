# AI Recruit

An AI-assisted hiring platform. HR posts a job, candidates apply with a CV, the system reads every CV,
ranks candidates by how well they fit **the meaning of the job** (not just keywords), runs a short
job-specific AI interview with each candidate, and can make the hiring decisions automatically
(thresholds + first come, first served) or let HR decide on a drag-and-drop board.

It runs **fully offline with no paid API**. An Anthropic or OpenAI key is optional and only makes some
texts (job descriptions, live interview wording, evaluation) more natural.

---

## Contents

1. [What it does](#1-what-it-does)
2. [Technology](#2-technology)
3. [How it is built](#3-how-it-is-built)
4. [Folder structure](#4-folder-structure)
5. [How each part works](#5-how-each-part-works)
6. [Database](#6-database)
7. [API](#7-api)
8. [Configuration (.env)](#8-configuration-env)
9. [Run it locally](#9-run-it-locally)
10. [Deploy for a client](#10-deploy-for-a-client)
11. [Privacy and data flow](#11-privacy-and-data-flow)
12. [Tests and demo data](#12-tests-and-demo-data)
13. [Known limitations](#13-known-limitations)

---

## 1. What it does

### For HR

| Area | What HR can do |
|---|---|
| **Jobs** | Create a job (skills, experience, education, responsibilities, openings), generate a job description, edit, approve, publish |
| **Ranking** | See every applicant ranked best first, with a breakdown: which skills matched (and the CV line that proves it), role relevance, experience, education |
| **Skill gap** | For each candidate, which required skills are missing and whether each gap is *critical* or *trainable* |
| **Interviews** | Invite a candidate to an AI interview, read the transcript, see the evaluation |
| **Hands-free hiring** | Per job: set a CV threshold (auto-invite to interview) and an interview threshold (auto-select), with a live preview of who would pass |
| **Pipeline board** | Drag candidates between Under review, Shortlisted, Interview, Selected, Rejected |
| **Dashboard** | KPIs, 30-day activity, hiring funnel, candidate status, jobs pipeline, top candidates, a to-do list |
| **Analytics** | Score distributions, conversion rates, per-job table, skills demand vs supply |
| **Activity** | Full timeline of applications, interviews, automatic decisions (with the reason) and manual moves |

### For candidates

- Browse open jobs and apply with a CV (PDF, Word or image; scanned CVs are read with OCR).
- Follow each application's status and read HR's note.
- Take the AI interview (voice or typed), and download their own transcript.

---

## 2. Technology

| Layer | Used |
|---|---|
| Languages | **Python 3.11** (backend), **TypeScript** (frontend), SQL |
| Backend | **FastAPI**, Uvicorn, **SQLAlchemy 2**, **Alembic** (migrations), Pydantic, python-jose (JWT), passlib/bcrypt |
| Database | **PostgreSQL** (SQLite works for tests) |
| CV reading | pypdf, pypdfium2, python-docx, Pillow, **RapidOCR** (scanned CVs) |
| Meaning search | **bge-small-en-v1.5** embedding model via **fastembed + ONNX Runtime** (local, free, offline) |
| Keyword search | Own BM25 implementation |
| Optional AI | Anthropic Claude (default `claude-sonnet-5-5`) or OpenAI (default `gpt-4o-mini`) over HTTPS (httpx) |
| Email (optional) | Python `smtplib`, any SMTP server |
| Frontend | **Next.js 16**, **React 19**, **Tailwind CSS 4**, Zustand (auth state), Axios, lucide-react icons, react-markdown |
| Charts and motion | Hand-written SVG charts; CSS 3D animations (no chart or animation library) |
| Voice | Browser Web Speech API (speech-to-text and text-to-speech) |

There are **no AI agent frameworks** (no LangChain etc.). Decisions are made by deterministic code so
every score can be explained; an LLM, when configured, only writes text.

---

## 3. How it is built

```
 Browser (HR / candidate)
        │  HTTPS, JSON, JWT token
        ▼
 Next.js frontend  ──────────────►  FastAPI backend  ──────►  PostgreSQL
 (pages, charts,                     │  services:               (all data)
  drag and drop)                     │   • CV pipeline
                                     │   • job profile          backend/uploads/
                                     │   • hybrid search  ◄──►  (CV files)
                                     │   • matching/ranking
                                     │   • interview engine     backend/.models/
                                     │   • evaluation           (search model)
                                     │   • automation
                                     │   • notify (email)
                                     ▼
                       optional: Anthropic / OpenAI API, SMTP server
```

Long work (reading a CV, evaluating an interview) runs as a background task after the request returns;
the automation runs right after each of those finishes.

---

## 4. Folder structure

```
ai-recruitment/
├── backend/
│   ├── app/
│   │   ├── main.py                 app start, routers, model warm-up
│   │   ├── core/                   config (.env settings), security (JWT, passwords)
│   │   ├── db/                     database session
│   │   ├── models/                 database tables (SQLAlchemy)
│   │   ├── schemas/                request/response shapes (Pydantic)
│   │   ├── api/                    HTTP endpoints
│   │   │   ├── auth.py  jobs.py  applications.py  ranking.py  skillgap.py
│   │   │   ├── interviews.py  automation.py (settings + dashboard insights)
│   │   │   ├── pipeline.py (board)  hr.py
│   │   └── services/               the logic
│   │       ├── cv/                 parse file → text (incl. OCR) → structured CV
│   │       ├── search/             embeddings.py, bm25.py, hybrid.py
│   │       ├── job_profile.py      understanding the job post
│   │       ├── matching.py         CV vs job score
│   │       ├── ranking.py          rank every candidate for a job
│   │       ├── skillgap.py         critical vs trainable gaps
│   │       ├── interview/          plan.py, engine.py, builtin.py, evaluation.py
│   │       ├── automation.py       thresholds, first come first served
│   │       ├── notify.py           emails to candidates
│   │       ├── jd_generator.py     job description writer
│   │       └── llm_client.py       optional AI provider
│   ├── alembic/versions/           migrations 0001 … 0007 (the table structure)
│   ├── scripts/seed_demo.py        demo company for testing
│   ├── tests/                      test_phase6.py, test_hybrid.py, test_automation.py
│   ├── requirements.txt  requirements-ocr.txt  .env.example  schema.sql
│   └── uploads/                    stored CV files (not in git)
└── frontend/
    ├── src/app/
    │   ├── (auth)/login, register
    │   ├── hr/ dashboard, jobs, jobs/[id] (+ edit, ranking), candidates,
    │   │       applications/[id] (+ interview), pipeline, analytics, activity
    │   └── candidate/ (open jobs), applications, jobs/[id]/apply, interview/[id]
    ├── src/components/             MatchBreakdown, AutomationPanel, Tilt,
    │                               dashboard/charts.tsx, dashboard/shared.tsx, interview/…
    ├── src/lib/                    api client, speech helper
    └── src/app/globals.css         theme + 3D motion styles
```

---

## 5. How each part works

### 5.1 Reading a CV (`services/cv/`)

1. **Parse:** PDF, Word or image → plain text. Pages with no text layer are read with RapidOCR
   (or an AI vision model if a key is set).
2. **Extract:** text → structured CV: name, contact, summary, skills, experience, projects, education,
   certifications, total years. Built-in rules by default; an LLM when a key is set.
3. Stored on the application (`parsed_text`, `extracted`), then the automation runs (5.8).

### 5.2 Understanding the job (`services/job_profile.py`)

Every job gets a **profile**:

- **Role family** (software, AI/ML, data, video/media, design, marketing, sales, support, HR, finance,
  education, operations, healthcare), recognised by meaning. It sets the interview style
  (technical / creative / people / business).
- **Responsibilities**, pulled from the HR notes or the description (headings, requirement lists,
  benefits and filler like "We are looking for…" are removed).
- **Each requirement expanded into its meaning**, e.g. "video editing" → cutting footage, captions,
  Premiere Pro, DaVinci Resolve…, plus the sentence of the post that mentions it.
- Each requirement is tagged **named tool** (FastAPI must be on the CV) or **broad capability**
  ("AI", "speaking skills": similar experience counts).

With an AI key the profile is refined by the AI and stored on the job; it is rebuilt when the post changes.

### 5.3 Hybrid search (`services/search/`)

The CV is split into small chunks: each skill, each job bullet, each project, summary sentences,
certifications. For each requirement:

| Signal | How |
|---|---|
| Exact | the skill or a known alias appears (`Fast APi` = `FastAPI`, `k8s` = `Kubernetes`) |
| Keyword | BM25 plus how many of the requirement's own words a chunk contains |
| Meaning | cosine similarity of embeddings, **minus a noise floor** (how similar the query is to unrelated filler sentences), so vague queries don't match everything |

`hybrid = 0.7 × meaning + 0.3 × keyword`. The best chunk is kept as **evidence** and shown to HR.
Vectors are cached in the `text_embeddings` table.

### 5.4 Matching and ranking (`services/matching.py`, `ranking.py`)

Per requirement:

1. exact / alias match → **full credit**
2. a known sibling tool (MySQL for PostgreSQL) → **half credit**
3. meaning match: broad capability → full match; named tool → half credit only

Overall score (weights are relative; parts that don't apply are dropped and the rest re-balanced):

| Part | Default weight |
|---|---|
| Required skills | 60 |
| Role relevance (candidate's real work vs the job's responsibilities, by meaning) | 20 |
| Experience (years vs range) | 20 |
| Nice-to-have skills | 10 |
| Education (degree level) | 10 |

Name, gender, age, nationality and university are never used. Ties: more required skills, more
experience, earlier application.

### 5.5 Skill gap (`services/skillgap.py`)

Each missing skill is rated by category (language, framework, domain, tool…), whether the title or
responsibilities depend on it, and whether the foundation it builds on is present. Result:
**critical** (test before relying on it) or **trainable** (with an effort estimate and how to close it).

### 5.6 AI interview (`services/interview/`)

- **Plan** (`plan.py`): intro → skill checks → gap probes → deep dive on the candidate's most relevant
  work → a scenario from the job's responsibilities → motivation. Questions quote the candidate's own
  CV evidence and the job's own responsibilities, use the role family's style, and wording is chosen
  per candidate, so two candidates (or one candidate on two jobs) get different questions.
  Employer and candidate names are never put into questions.
- **Engine** (`engine.py`): one question per turn, a cap on follow-ups, a time limit, handling of
  "repeat that" and "skip", and a filter that blocks questions about protected characteristics
  (age, family, religion, salary history…). With an AI key the AI words each turn; the rules above
  are still enforced in code.
- **Evaluation** (`evaluation.py`): built-in scoring of length, specifics, ownership and relevance
  (keywords and meaning); an AI rubric when a key is set. Attempts to manipulate the AI are flagged.

### 5.7 Hands-free hiring (`services/automation.py`)

Off by default, per job.

| Stage | Rule |
|---|---|
| CV analysed | match ≥ CV threshold → **Interview** + invitation; below → **Rejected** (or left for HR) |
| Interview evaluated | score ≥ interview threshold and an opening is free → **Selected**; openings full → rejected "positions filled"; below → **Rejected** |

- **First come, first served:** backlog processed in application order; seats go to qualifying
  candidates in that order; the job row is locked while a seat is given out.
- **Never overrides HR:** only candidates still in the stage the automation owns are touched.
- Every action is logged in `automation_events` with score, threshold and reason. Candidates only
  see a polite message, never numbers.

### 5.8 Pipeline board (`api/pipeline.py`, `hr/pipeline`)

Drag-and-drop (or a "Move to" menu). Moving to Interview creates the invitation; leaving Interview
can cancel an untaken invitation; Rejected asks for confirmation and an optional note; Selected
warns when openings are full. Every move is HR's decision (`decision_source = "hr"`), is logged, and
can be undone for a few seconds.

### 5.9 Dashboard, Analytics, Activity

All three read one endpoint, `/api/hr/dashboard/insights`, which computes KPIs, funnel, 30-day
timeline, score histograms, per-job rows, top candidates, skills coverage and the activity feed for
the signed-in HR user only.

---

## 6. Database

PostgreSQL. The structure is defined by the models in `backend/app/models/` and created by the
migrations in `backend/alembic/versions/`. A full SQL export of the structure is in
`backend/schema.sql`.

```
users ──< jobs ──< applications >── users (candidate)
                       ├──< interviews ──< interview_turns
                       └──< automation_events >── jobs
text_embeddings  (search cache)      alembic_version  (current migration)
```

| Table | Holds |
|---|---|
| `users` | HR and candidate accounts (bcrypt password hash, role, company) |
| `jobs` | Requirements, description, status, job profile (JSON), automation settings |
| `applications` | One per candidate per job: CV file info, CV text, extracted CV (JSON), decision, decision source (auto/hr), note, match score, skill-gap cache |
| `interviews` | One per application: status, plan (JSON), timing, evaluation (JSON) |
| `interview_turns` | Every question and answer in order |
| `automation_events` | Audit log of automatic decisions and manual board moves |
| `text_embeddings` | Cached meaning vectors (sha256 key → float32 vector) |

The CV **files** live in `backend/uploads/`; the database stores only their file names, so back up
both together.

---

## 7. API

Interactive docs while the backend runs: **http://localhost:8000/docs** (Swagger) and `/redoc`.
Sign in with `POST /api/auth/login`, then click **Authorize** and paste the token.

| Group | Endpoints |
|---|---|
| Auth | `POST /api/auth/register` · `POST /api/auth/login` · `GET /api/auth/me` |
| Jobs (HR) | `POST/GET /api/hr/jobs` · `GET/PUT/DELETE /api/hr/jobs/{id}` · `POST …/generate-jd` · `PUT …/jd` · `POST …/approve` · `POST …/publish` · `POST …/unpublish` |
| Jobs (public) | `GET /api/jobs` · `GET /api/jobs/{id}` |
| Applications (candidate) | `POST /api/jobs/{id}/apply` · `GET /api/applications/mine` · `GET/DELETE /api/applications/{id}` · `POST …/retry` |
| Applications (HR) | `GET /api/hr/applications` · `GET …/{id}` · `GET …/{id}/cv` · `POST …/{id}/reanalyze` · `PUT …/{id}/decision` |
| Ranking and gaps | `GET /api/hr/jobs/{id}/ranking` · `GET /api/hr/applications/{id}/match` · `GET …/skill-gap` · `POST …/skill-gap/explain` |
| Interviews (candidate) | `GET /api/interviews/{id}` · `POST …/start` · `POST …/answer` · `POST …/continue` · `POST …/end` · `GET …/transcript` |
| Interviews (HR) | `POST/GET /api/hr/applications/{id}/interview` · `DELETE /api/hr/interviews/{id}` · `POST …/reevaluate` · `GET …/transcript.txt` |
| Automation | `GET/PUT /api/hr/jobs/{id}/automation` · `POST /api/hr/jobs/{id}/automation/run` |
| Pipeline | `GET /api/hr/pipeline?job_id=` · `PUT /api/hr/applications/{id}/stage` |
| Dashboard | `GET /api/hr/dashboard` · `GET /api/hr/dashboard/insights` |

HR endpoints only return the signed-in HR user's own jobs and candidates; candidates only see their
own applications and interviews.

---

## 8. Configuration (.env)

Copy `backend/.env.example` to `backend/.env`. Never commit or send `.env`.

| Setting | Meaning |
|---|---|
| `DATABASE_URL` | `postgresql+psycopg2://user:password@host:5432/recruitment` |
| `SECRET_KEY` | Long random string that signs login tokens |
| `FRONTEND_URL` | Site address (CORS and links in emails) |
| `ALLOW_HR_SIGNUP` | `true` lets anyone register as HR. Set `false` in production after creating HR accounts |
| `LLM_PROVIDER` | `auto` / `anthropic` / `openai` / `template` (no AI) |
| `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `LLM_MODEL` | Optional AI provider |
| `UPLOAD_DIR`, `MAX_CV_MB`, `SCANNED_CV_MODE` | CV storage, size limit, OCR mode |
| `RANK_WEIGHT_*` | Ranking weights (required, relevance, nice, experience, education) |
| `SEMANTIC_SEARCH` | `auto` = keywords + meaning; `off` = keywords only |
| `INTERVIEW_QUESTIONS`, `INTERVIEW_MAX_MINUTES` | Interview defaults |
| `SMTP_HOST` … `SMTP_TLS` | Optional email. Empty = candidates are told in the app only |

`frontend/.env.local` holds `NEXT_PUBLIC_API_URL` (the backend address).

---

## 9. Run it locally

**Needs:** Python 3.11, Node.js 20+, PostgreSQL.

```sql
-- in psql or pgAdmin, once
CREATE USER recruit_user WITH PASSWORD 'recruit_pass';
CREATE DATABASE recruitment OWNER recruit_user;
```

```bash
# backend
cd backend
python -m venv venv
venv\Scripts\activate            # macOS/Linux: source venv/bin/activate
pip install -r requirements.txt  # + requirements-ocr.txt for scanned CVs
copy .env.example .env           # then edit DATABASE_URL and SECRET_KEY
alembic upgrade head             # creates all tables
uvicorn app.main:app --reload --reload-dir app --port 8000
```

```bash
# frontend (second terminal)
cd frontend
npm install
npm run dev
```

Open **http://localhost:3000**, register an HR account, create a job. The first backend start
downloads the search model (~65 MB) into `backend/.models/`; after that it is offline.

---

## 10. Deploy for a client

Deploy on **the client's own server** (their machine or their cloud account) so their data never
leaves their infrastructure. Users only need a browser.

1. Install PostgreSQL (or use a managed one) and create an **empty** database and user (section 9).
2. Copy the code (preferably from a private Git repository), install backend and frontend.
3. Create a new `.env` with **their own** `SECRET_KEY`, database password, `FRONTEND_URL`.
4. `alembic upgrade head`: builds all tables, empty. Never copy your own database.
5. Register the client's first HR account, then set `ALLOW_HR_SIGNUP=false` and restart.
6. Production: `npm run build && npm start` for the frontend, HTTPS in front of both, daily backups
   of the database **and** `uploads/`, and copy `backend/.models/` so no download is needed.

**Updates:** pull the new code, run `alembic upgrade head` again (applies only new migrations, keeps data).

**Moving existing data** (only when needed): `pg_dump -Fc` the database and copy `uploads/` with it;
restore with `pg_restore`.

---

## 11. Privacy and data flow

- All data stays in the client's PostgreSQL and `uploads/` folder. The app never contacts the developer.
- Outside connections, only when used:
  - one-time model download from Hugging Face (download only; avoidable by copying `.models/`)
  - Anthropic/OpenAI, **only if a key is set** (CV and interview text is then sent to that provider)
  - the client's SMTP server, if configured
  - **voice answers:** in Google Chrome the browser's speech recognition sends audio to Google;
    typed answers stay on the server
- Passwords are stored as bcrypt hashes. HR only sees their own jobs and candidates.
- Automatic rejection is regulated in some regions (e.g. GDPR right to human review, EU AI Act for
  hiring tools). Automation is off by default and HR can override every decision on the Pipeline board;
  have the client's legal team review how they use it.

---

## 12. Tests and demo data

Tests use a throwaway SQLite database, not your PostgreSQL data:

```bash
cd backend
set DATABASE_URL=sqlite:///./p6.db
set SECRET_KEY=k
set LLM_PROVIDER=template
set PYTHONPATH=.
alembic upgrade head
python tests\test_hybrid.py       # job understanding, hybrid ranking, per-candidate interviews
python tests\test_automation.py   # thresholds, first come first served, pipeline board, dashboard
python tests\test_phase6.py       # interview flow, privacy, safety, AI mode (mocked)
```

Each prints PASS/FAIL per check and `FAILURES: n` at the end.

**Demo data** (writes to your real database, under `@airecruit-demo.example.com` accounts only):

```bash
python scripts\seed_demo.py           # demo company: 3 jobs, 13 candidates, automated decisions
python scripts\seed_demo.py --remove  # delete it
```

Logins are written to `backend/scripts/DEMO_ACCOUNTS.md` (git-ignored).

---

## 13. Known limitations

- Search quality is tuned for **English** CVs and jobs.
- Without an AI key, the interview evaluation measures detail, specifics and relevance, not whether an
  answer is technically correct. HR should read the transcript.
- Background tasks run inside the backend process; a restart during CV analysis or evaluation
  interrupts that task (HR can re-run "Reanalyze" / "Re-evaluate").
- One pre-existing test (`gap answer without a learning plan`) in `test_phase6.py` fails, and one
  pre-existing lint warning exists in `frontend/src/lib/useSpeech.ts`.
- The project is not yet a Git repository; create one before handing over.
