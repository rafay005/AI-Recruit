"""Create a demo HR company with jobs, candidates and CVs, then let the real automation process them.

Run from the backend folder (venv active):
    python scripts\\seed_demo.py           create (or reset) the demo data
    python scripts\\seed_demo.py --remove  delete it again

Everything lives under the demo HR account and candidate accounts ending in @airecruit.test,
so it never touches your real data. Logins are written to scripts/DEMO_ACCOUNTS.md.
"""
import random
import secrets
import sys
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.core.security import hash_password  # noqa: E402
from app.db.session import SessionLocal  # noqa: E402
from app.models.application import Application  # noqa: E402
from app.models.automation import AutomationEvent  # noqa: E402
from app.models.interview import Interview, InterviewTurn  # noqa: E402
from app.models.job import Job  # noqa: E402
from app.models.user import User, UserRole  # noqa: E402
from app.services.automation import process_interview, run_job  # noqa: E402
from app.services.interview.evaluation import label_for  # noqa: E402

DOMAIN = "@airecruit-demo.example.com"  # reserved domain: never delivers mail, passes email validation
HR_EMAIL = "demo.hr" + DOMAIN
NOW = datetime.now(timezone.utc)
rnd = random.Random(42)

JOBS = [
    dict(title="Backend Python Developer", department="Engineering", location="Islamabad", work_mode="hybrid",
         experience_level="mid", openings=2, min_experience_years=2, education="BS Computer Science",
         required_skills=["Python", "FastAPI", "PostgreSQL", "Docker"], nice_to_have_skills=["Redis", "AWS"],
         responsibilities="- Build and optimise REST APIs with FastAPI\n- Design PostgreSQL schemas and queries\n- Containerise services with Docker\n- Review code and mentor juniors",
         auto=(True, 60, 65)),
    dict(title="Video Content Creator", department="Marketing", location="Remote", work_mode="remote",
         experience_level="mid", openings=1, min_experience_years=1, education=None,
         required_skills=["video editing", "video creation", "storytelling", "good speaking skills"], nice_to_have_skills=["After Effects"],
         responsibilities="- Create short-form videos for social media every week\n- Edit footage, add captions, music and motion graphics\n- Present on camera for product explainers",
         auto=(True, 55, 60)),
    dict(title="Data Analyst", department="Operations", location="Lahore", work_mode="onsite",
         experience_level="entry", openings=1, min_experience_years=0, education="Bachelor's degree",
         required_skills=["SQL", "Excel", "Power BI", "Statistics"], nice_to_have_skills=["Python"],
         responsibilities="- Build weekly dashboards in Power BI\n- Write SQL to answer business questions\n- Present findings to managers",
         auto=(False, 60, 65)),
]

DEV = lambda name, skills, years, desc, deg="BS", field="Computer Science": dict(  # noqa: E731
    name=name, skills=skills, total_experience_years=years, education=[{"degree": deg, "field": field}],
    summary=desc.split(".")[0] + ".", experience=[{"title": "Software Engineer", "company": "Example Co", "description": desc}])

CANDIDATES = [
    # (name, job index, cv, days ago, interview score or None)
    ("Ayesha Khan", 0, DEV("Ayesha Khan", ["Python", "FastAPI", "PostgreSQL", "Docker", "Redis"], 4, "Built REST APIs with FastAPI serving 2M requests a day.\nDesigned PostgreSQL schemas and tuned slow queries.\nShipped every service in Docker on AWS."), 28, 84),
    ("Hamza Ali", 0, DEV("Hamza Ali", ["Python", "Django", "MySQL", "Docker"], 3, "Developed Django backends with MySQL.\nWrote Celery jobs and containerised them with Docker."), 25, 71),
    ("Sara Ahmed", 0, DEV("Sara Ahmed", ["Java", "Spring Boot", "Oracle"], 5, "Built Spring Boot services on Oracle for a bank."), 22, None),
    ("Usman Tariq", 0, DEV("Usman Tariq", ["Python", "FastAPI", "PostgreSQL"], 2, "Created FastAPI microservices with PostgreSQL.\nMentored two interns on code reviews."), 18, 58),
    ("Zainab Malik", 0, DEV("Zainab Malik", ["Python", "Flask", "PostgreSQL", "Docker", "AWS"], 6, "Led a Flask to FastAPI migration.\nOwned PostgreSQL and Docker deployments on AWS."), 12, 77),
    ("Bilal Hussain", 0, DEV("Bilal Hussain", ["HTML", "CSS", "WordPress"], 1, "Built WordPress sites for small businesses.", "BA", "English"), 9, None),
    ("Mariam Siddiqui", 0, DEV("Mariam Siddiqui", ["Python", "FastAPI", "Docker", "PostgreSQL", "Kubernetes"], 3, "Built FastAPI services on Kubernetes.\nTuned PostgreSQL indexes."), 4, None),
    ("Omar Farooq", 1, dict(name="Omar Farooq", skills=["Premiere Pro", "CapCut", "After Effects", "Public Speaking"], total_experience_years=3,
        summary="Video editor and creator with 3 years of short-form content.",
        experience=[{"title": "Video Editor", "company": "Studio", "description": "Edited 400+ TikTok and Reels videos.\nCreated motion graphics in After Effects.\nHosted a weekly product show on camera."}]), 27, 82),
    ("Hira Javed", 1, dict(name="Hira Javed", skills=["Photoshop", "Canva", "Copywriting"], total_experience_years=2,
        summary="Graphic designer focused on social posts.",
        experience=[{"title": "Designer", "company": "Agency", "description": "Designed social media posts and banners.\nWrote captions for campaigns."}]), 20, None),
    ("Ali Raza", 1, dict(name="Ali Raza", skills=["DaVinci Resolve", "Storyboarding", "YouTube"], total_experience_years=4,
        summary="YouTube creator and editor telling stories about tech.",
        experience=[{"title": "Content Creator", "company": "Own channel", "description": "Scripted, filmed and edited 120 YouTube videos.\nGrew the channel to 80k subscribers with storytelling.\nPresented every episode on camera."}]), 14, 74),
    ("Fatima Noor", 1, dict(name="Fatima Noor", skills=["Excel", "Accounting"], total_experience_years=2,
        summary="Accountant.", experience=[{"title": "Accountant", "company": "Firm", "description": "Prepared invoices and payroll."}]), 6, None),
    ("Danish Iqbal", 2, DEV("Danish Iqbal", ["SQL", "Excel", "Power BI", "Statistics", "Python"], 1, "Built Power BI dashboards for sales.\nWrote SQL reports for managers.", "BS", "Statistics"), 16, None),
    ("Sana Yousaf", 2, DEV("Sana Yousaf", ["Excel", "Tableau"], 0, "Made Tableau charts during an internship.", "BBA", "Business"), 3, None),
]


def remove(db):
    for dom in (DOMAIN, "@airecruit.test"):  # second one: an earlier version of this script
        hr = db.query(User).filter(User.email == "demo.hr" + dom).one_or_none()
        if hr:
            db.query(Job).filter(Job.owner_id == hr.id).delete()
        db.query(User).filter(User.email.like("%" + dom)).delete(synchronize_session=False)
    db.commit()


def main():
    db = SessionLocal()
    remove(db)
    if "--remove" in sys.argv:
        print("Demo data removed.")
        return
    pw = secrets.token_urlsafe(9)
    hr = User(full_name="Demo Recruiter", email=HR_EMAIL, hashed_password=hash_password(pw), role=UserRole.HR, company="Demo Corp")
    db.add(hr)
    db.flush()

    jobs = []
    for spec in JOBS:
        s = dict(spec)
        enabled, cvt, ivt = s.pop("auto")
        jd = f"# {s['title']}\n\n## Key Responsibilities\n{s['responsibilities']}\n\n## Required Qualifications\n" + "\n".join(f"- {x}" for x in s["required_skills"])
        j = Job(owner_id=hr.id, employment_type="full_time", status="published", jd_text=jd, jd_source="manual",
                published_at=NOW - timedelta(days=30), approved_at=NOW - timedelta(days=30),
                auto_enabled=enabled, auto_cv_threshold=cvt, auto_interview_threshold=ivt, auto_questions=5, **s)
        db.add(j)
        jobs.append(j)
    db.flush()

    apps = []
    for name, ji, cv, days, iv_score in CANDIDATES:
        u = User(full_name=name, email=name.lower().replace(" ", ".") + DOMAIN, hashed_password=hash_password(pw), role=UserRole.CANDIDATE)
        db.add(u)
        db.flush()
        created = NOW - timedelta(days=days, hours=rnd.randint(0, 20))
        a = Application(job_id=jobs[ji].id, candidate_id=u.id, cv_filename=f"{name.split()[0]}_CV.pdf",
                        cv_stored_name=uuid.uuid4().hex + ".pdf", cv_content_type="application/pdf", cv_size=48000,
                        analysis_status="done", analyzed_at=created, extracted={**cv, "email": u.email},
                        parsed_text="", extraction_method="text", created_at=created)
        db.add(a)
        apps.append((a, iv_score))
    db.commit()

    # 1) CV stage, the real automation, first come first served
    for j in jobs:
        if j.auto_enabled:
            print(j.title, "->", run_job(db, j))

    # 2) Interviews: candidates who were invited take them (score given), then automation decides
    for a, score in sorted(apps, key=lambda t: t[0].created_at):
        iv = a.interview
        if iv is None or score is None:
            continue
        start = a.created_at + timedelta(days=2)
        iv.status, iv.started_at, iv.completed_at, iv.mode = "completed", start, start + timedelta(minutes=18), "built-in"
        iv.ended_reason, iv.consent_at = "completed", start
        db.add_all([InterviewTurn(interview_id=iv.id, idx=0, role="interviewer", kind="question", topic="Background",
                                  text="Could you tell me a little about yourself?", source="built-in"),
                    InterviewTurn(interview_id=iv.id, idx=1, role="candidate", kind="answer", topic="Background",
                                  text="(demo interview)", source="candidate")])
        iv.eval_status = "done"
        iv.evaluation = {"source": "built-in", "model": None, "overall": score, "label": label_for(score),
                         "summary": "Demo evaluation.", "strengths": [], "concerns": [], "communication": {"score": 4, "notes": "Clear."},
                         "skills": [], "answers": [], "flags": [], "questions_answered": 5, "note": None,
                         "questions_planned": 5, "ended_early": False, "ended_reason": "completed", "duration_seconds": 1080}
        db.flush()
        print(" ", a.extracted["name"], "interview", score, "->", process_interview(db, iv))
    db.commit()

    # Spread decision and log times realistically (the automation stamped them all "now").
    for a, _ in apps:
        db.refresh(a)
        if a.decision_at:
            t = a.interview.completed_at + timedelta(minutes=2) if a.interview and a.interview.completed_at else a.created_at + timedelta(minutes=3)
            a.decision_at = t
            for e in db.query(AutomationEvent).filter(AutomationEvent.application_id == a.id):
                e.created_at = a.created_at + timedelta(minutes=3) if e.action in ("invited", "cv_rejected", "cv_held") else t
    db.commit()

    out = Path(__file__).with_name("DEMO_ACCOUNTS.md")
    out.write_text(
        "# Demo accounts (local test data only)\n\n"
        f"Created by `python scripts\\seed_demo.py` on {NOW:%Y-%m-%d %H:%M} UTC. Remove with `--remove`.\n\n"
        f"- HR: `{HR_EMAIL}`\n- Candidates: `<first>.<last>{DOMAIN}`, e.g. `ayesha.khan{DOMAIN}`\n"
        f"- Password for all demo accounts: `{pw}`\n", encoding="utf-8")
    print(f"\nDemo ready. Logins written to {out}")


if __name__ == "__main__":
    main()
