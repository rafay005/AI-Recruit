"""job profile columns and the text embedding cache

Revision ID: 0006
Revises: 0005
Create Date: 2026-11-04
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0006"
down_revision: Union[str, None] = "0005"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("jobs", sa.Column("profile", sa.JSON(), nullable=True))
    op.add_column("jobs", sa.Column("profile_signature", sa.String(length=64), nullable=True))
    op.create_table(
        "text_embeddings",
        sa.Column("key", sa.String(length=64), primary_key=True),
        sa.Column("model", sa.String(length=120), nullable=False),
        sa.Column("vector", sa.LargeBinary(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )


def downgrade() -> None:
    op.drop_table("text_embeddings")
    op.drop_column("jobs", "profile_signature")
    op.drop_column("jobs", "profile")
