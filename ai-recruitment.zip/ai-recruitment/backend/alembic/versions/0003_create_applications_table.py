"""create applications table

Revision ID: 0003
Revises: 0002
Create Date: 2026-10-11
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0003"
down_revision: Union[str, None] = "0002"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "applications",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column(
            "job_id",
            sa.Integer(),
            sa.ForeignKey("jobs.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "candidate_id",
            sa.Integer(),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("phone", sa.String(length=40), nullable=True),
        sa.Column("cover_note", sa.Text(), nullable=True),
        sa.Column("cv_filename", sa.String(length=200), nullable=False),
        sa.Column("cv_stored_name", sa.String(length=80), nullable=False),
        sa.Column("cv_content_type", sa.String(length=100), nullable=False),
        sa.Column("cv_size", sa.Integer(), nullable=False),
        sa.Column("analysis_status", sa.String(length=20), nullable=False),
        sa.Column("analysis_started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("analyzed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("analysis_error", sa.String(length=400), nullable=True),
        sa.Column("analysis_note", sa.String(length=400), nullable=True),
        sa.Column("extraction_method", sa.String(length=30), nullable=True),
        sa.Column("analysis_model", sa.String(length=80), nullable=True),
        sa.Column("parsed_text", sa.Text(), nullable=True),
        sa.Column("extracted", sa.JSON(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.UniqueConstraint("cv_stored_name"),
        sa.UniqueConstraint("job_id", "candidate_id", name="uq_application_job_candidate"),
    )
    op.create_index("ix_applications_id", "applications", ["id"])
    op.create_index("ix_applications_job_id", "applications", ["job_id"])
    op.create_index("ix_applications_candidate_id", "applications", ["candidate_id"])
    op.create_index("ix_applications_analysis_status", "applications", ["analysis_status"])


def downgrade() -> None:
    op.drop_index("ix_applications_analysis_status", table_name="applications")
    op.drop_index("ix_applications_candidate_id", table_name="applications")
    op.drop_index("ix_applications_job_id", table_name="applications")
    op.drop_index("ix_applications_id", table_name="applications")
    op.drop_table("applications")
