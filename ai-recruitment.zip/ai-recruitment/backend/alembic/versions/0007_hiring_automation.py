"""hiring automation settings, decision source and the automation log

Revision ID: 0007
Revises: 0006
Create Date: 2026-11-04
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0007"
down_revision: Union[str, None] = "0006"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("jobs", sa.Column("auto_enabled", sa.Boolean(), nullable=False, server_default=sa.false()))
    op.add_column("jobs", sa.Column("auto_cv_threshold", sa.Integer(), nullable=False, server_default="60"))
    op.add_column("jobs", sa.Column("auto_interview_threshold", sa.Integer(), nullable=False, server_default="65"))
    op.add_column("jobs", sa.Column("auto_reject_below_cv", sa.Boolean(), nullable=False, server_default=sa.true()))
    op.add_column("jobs", sa.Column("auto_questions", sa.Integer(), nullable=False, server_default="5"))
    op.add_column("applications", sa.Column("decision_source", sa.String(length=10), nullable=True))
    op.add_column("applications", sa.Column("match_score", sa.Integer(), nullable=True))
    op.create_table(
        "automation_events",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("job_id", sa.Integer(), sa.ForeignKey("jobs.id", ondelete="CASCADE"), nullable=False),
        sa.Column("application_id", sa.Integer(), sa.ForeignKey("applications.id", ondelete="CASCADE"), nullable=True),
        sa.Column("action", sa.String(length=30), nullable=False),
        sa.Column("score", sa.Integer(), nullable=True),
        sa.Column("threshold", sa.Integer(), nullable=True),
        sa.Column("detail", sa.String(length=400), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index("ix_automation_events_job_id", "automation_events", ["job_id"])
    op.create_index("ix_automation_events_application_id", "automation_events", ["application_id"])
    op.create_index("ix_automation_events_action", "automation_events", ["action"])
    op.create_index("ix_automation_events_created_at", "automation_events", ["created_at"])


def downgrade() -> None:
    op.drop_table("automation_events")
    op.drop_column("applications", "match_score")
    op.drop_column("applications", "decision_source")
    for c in ("auto_questions", "auto_reject_below_cv", "auto_interview_threshold", "auto_cv_threshold", "auto_enabled"):
        op.drop_column("jobs", c)
