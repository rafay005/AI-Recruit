"""application decision status and cached skill-gap explanation

Revision ID: 0004
Revises: 0003
Create Date: 2026-10-12
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0004"
down_revision: Union[str, None] = "0003"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "applications",
        sa.Column("decision", sa.String(length=20), nullable=False, server_default="under_review"),
    )
    op.add_column("applications", sa.Column("decision_note", sa.String(length=500), nullable=True))
    op.add_column("applications", sa.Column("decision_at", sa.DateTime(timezone=True), nullable=True))
    op.add_column("applications", sa.Column("gap_assessment", sa.JSON(), nullable=True))
    op.add_column("applications", sa.Column("gap_signature", sa.String(length=64), nullable=True))
    op.add_column("applications", sa.Column("gap_model", sa.String(length=80), nullable=True))
    op.add_column("applications", sa.Column("gap_generated_at", sa.DateTime(timezone=True), nullable=True))
    op.create_index("ix_applications_decision", "applications", ["decision"])


def downgrade() -> None:
    op.drop_index("ix_applications_decision", table_name="applications")
    for col in ("gap_generated_at", "gap_model", "gap_signature", "gap_assessment",
                "decision_at", "decision_note", "decision"):
        op.drop_column("applications", col)
