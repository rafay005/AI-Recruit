# Backend (FastAPI)

Run from this folder (`ai-recruitment/backend`):

```
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
alembic upgrade head
uvicorn app.main:app --reload --port 8000
```

API docs: http://localhost:8000/docs
