# Phase 3 backend notes (CV analysis)

From `ai-recruitment\backend`, with `(venv)` active:

```
pip install -r requirements.txt
alembic upgrade head
uvicorn app.main:app --reload --port 8000
```

`alembic upgrade head` should print: Running upgrade 0002 -> 0003, create applications table

## Optional: OCR for scanned CVs (no AI key needed)

```
pip install -r requirements-ocr.txt
```

Without it, scanned (image-only) CVs need an AI key (vision model). Text PDFs and DOCX files
work with neither.

## Settings (add to .env only if you want to change them)

```
UPLOAD_DIR=uploads
MAX_CV_MB=5
SCANNED_CV_MODE=auto     # auto | vlm | ocr
```

CV files are saved in `backend\uploads\cvs` under random names. They are never served
publicly; only the HR user who owns the job can download them.
