# Phase 4 backend notes (ranking)

No new database table, so there is no migration this time.

From `ai-recruitment\backend`, with `(venv)` active, just restart the server:

```
uvicorn app.main:app --reload --port 8000
```

## How the score works

Overall match = weighted average of
- Required skills   60%   (a similar skill, e.g. MySQL for PostgreSQL, counts as half)
- Nice-to-have      10%
- Experience        20%   (years found in the CV vs the job's range)
- Education         10%   (highest degree vs the job's requirement)

Parts that do not apply to a job are dropped and the rest are re-balanced.
To change the weights, add these to `.env` and restart the backend:

```
RANK_WEIGHT_REQUIRED=60
RANK_WEIGHT_NICE=10
RANK_WEIGHT_EXPERIENCE=20
RANK_WEIGHT_EDUCATION=10
```
