# Phase 2 backend notes

1. Add these lines to your existing `backend/.env` (do NOT replace the file):

```
LLM_PROVIDER=auto
ANTHROPIC_API_KEY=
OPENAI_API_KEY=
LLM_MODEL=
```

   - Leave the keys empty to use the built-in template generator (no AI).
   - Paste ONE key to use real AI. `auto` picks Anthropic if its key is set, else OpenAI.
   - `LLM_MODEL` is optional. Defaults: Anthropic `claude-sonnet-5-5`, OpenAI `gpt-4o-mini`.

2. With the venv active, in `backend`:

```
pip install -r requirements.txt
alembic upgrade head
uvicorn app.main:app --reload --port 8000
```

The migration adds the `jobs` table (revision 0002).
