from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    DATABASE_URL: str
    SECRET_KEY: str
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    FRONTEND_URL: str = "http://localhost:3000"
    # Dev convenience: lets anyone register as HR. Set to false before deploying.
    ALLOW_HR_SIGNUP: bool = True

    # --- AI job-description generator (Phase 2) ---
    # "auto" = use Anthropic if ANTHROPIC_API_KEY is set, else OpenAI if
    # OPENAI_API_KEY is set, else a built-in template (no AI, no key needed).
    # Or force one of: anthropic | openai | template
    LLM_PROVIDER: str = "auto"
    ANTHROPIC_API_KEY: str = ""
    OPENAI_API_KEY: str = ""
    LLM_MODEL: str = ""  # optional override; each provider has a default

    # --- CV uploads and analysis (Phase 3) ---
    UPLOAD_DIR: str = "uploads"  # relative to the backend folder
    MAX_CV_MB: int = 5
    # How to read scanned (image-only) CVs:
    #   auto = AI vision model if an AI key is set, else local OCR (RapidOCR)
    #   vlm  = AI vision model only      ocr = local OCR only
    SCANNED_CV_MODE: str = "auto"

    # --- Candidate ranking (Phase 4): how the overall match is weighted ---
    # Weights are relative. Parts that do not apply to a job (for example no
    # experience range set) are left out and the rest are re-balanced.
    RANK_WEIGHT_REQUIRED: float = 60
    RANK_WEIGHT_NICE: float = 10
    RANK_WEIGHT_EXPERIENCE: float = 20
    RANK_WEIGHT_EDUCATION: float = 10
    # How closely the candidate's actual work matches the job's responsibilities
    # (semantic search; only used when the embedding model is available).
    RANK_WEIGHT_RELEVANCE: float = 20

    # --- Hybrid search (keywords + meaning) ---
    # auto = local embedding model (downloaded once, runs offline) with keyword search
    # off  = keyword search only
    SEMANTIC_SEARCH: str = "auto"
    EMBEDDING_MODEL: str = "BAAI/bge-small-en-v1.5"
    EMBEDDING_CACHE_DIR: str = ".models"  # relative to the backend folder

    # --- AI interviews (Phase 6) ---
    INTERVIEW_QUESTIONS: int = 5  # default number of main questions
    INTERVIEW_MAX_MINUTES: int = 30  # the interview wraps up politely after this

    # --- Email (optional). Empty SMTP_HOST = candidates are told in the app only. ---
    SMTP_HOST: str = ""
    SMTP_PORT: int = 587
    SMTP_USER: str = ""
    SMTP_PASSWORD: str = ""
    SMTP_FROM: str = ""
    SMTP_TLS: bool = True

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @field_validator("DATABASE_URL")
    @classmethod
    def use_psycopg2_driver(cls, v: str) -> str:
        # Newer SQLAlchemy picks the psycopg v3 driver for plain "postgresql://".
        # We install psycopg2, so make that explicit.
        if v.startswith("postgresql://"):
            return v.replace("postgresql://", "postgresql+psycopg2://", 1)
        if v.startswith("postgres://"):
            return v.replace("postgres://", "postgresql+psycopg2://", 1)
        return v


settings = Settings()
