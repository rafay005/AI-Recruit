from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api import applications, auth, automation, hr, interviews, jobs, pipeline, ranking, skillgap
from app.core.config import settings

app = FastAPI(title="AI Recruitment API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.FRONTEND_URL, "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(hr.router)
app.include_router(jobs.router)
app.include_router(jobs.public_router)
app.include_router(applications.router)
app.include_router(applications.hr_router)
app.include_router(ranking.router)
app.include_router(skillgap.router)
app.include_router(interviews.router)
app.include_router(interviews.hr_router)
app.include_router(automation.router)
app.include_router(pipeline.router)


@app.on_event("startup")
def _warm_up_search() -> None:
    # Load the embedding model in the background so the first ranking is fast.
    from app.services.search import embeddings

    embeddings.warm_up()


@app.get("/health")
def health():
    return {"status": "ok"}
