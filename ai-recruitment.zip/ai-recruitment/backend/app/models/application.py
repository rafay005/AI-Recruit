from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any

from sqlalchemy import JSON, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.session import Base

if TYPE_CHECKING:
    from app.models.interview import Interview
    from app.models.job import Job
    from app.models.user import User

# pending -> processing -> done | failed
ANALYSIS_STATUSES = ("pending", "processing", "done", "failed")

# HR decision about the candidate
DECISIONS = ("under_review", "shortlisted", "interview", "rejected", "hired")
MOVED_FORWARD = ("shortlisted", "interview", "hired")


class Application(Base):
    __tablename__ = "applications"
    __table_args__ = (
        UniqueConstraint("job_id", "candidate_id", name="uq_application_job_candidate"),
    )

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    job_id: Mapped[int] = mapped_column(
        ForeignKey("jobs.id", ondelete="CASCADE"), index=True
    )
    candidate_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )

    # ---- what the candidate submitted ----
    phone: Mapped[str | None] = mapped_column(String(40), nullable=True)
    cover_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    cv_filename: Mapped[str] = mapped_column(String(200))  # original name, for display
    cv_stored_name: Mapped[str] = mapped_column(String(80), unique=True)  # uuid on disk
    cv_content_type: Mapped[str] = mapped_column(String(100))
    cv_size: Mapped[int] = mapped_column(Integer)

    # ---- CV analysis ----
    analysis_status: Mapped[str] = mapped_column(String(20), default="pending", index=True)
    analysis_started_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    analyzed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    analysis_error: Mapped[str | None] = mapped_column(String(400), nullable=True)
    analysis_note: Mapped[str | None] = mapped_column(String(400), nullable=True)
    extraction_method: Mapped[str | None] = mapped_column(String(30), nullable=True)
    analysis_model: Mapped[str | None] = mapped_column(String(80), nullable=True)
    parsed_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    extracted: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)

    # ---- HR decision (visible to the candidate) ----
    decision: Mapped[str] = mapped_column(
        String(20), default="under_review", server_default="under_review", index=True
    )
    decision_note: Mapped[str | None] = mapped_column(String(500), nullable=True)
    decision_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    decision_source: Mapped[str | None] = mapped_column(String(10), nullable=True)  # auto | hr
    match_score: Mapped[int | None] = mapped_column(Integer, nullable=True)  # CV match at the automated check

    # ---- cached AI explanation of skill gaps (HR only) ----
    gap_assessment: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
    gap_signature: Mapped[str | None] = mapped_column(String(64), nullable=True)
    gap_model: Mapped[str | None] = mapped_column(String(80), nullable=True)
    gap_generated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    job: Mapped["Job"] = relationship("Job")
    candidate: Mapped["User"] = relationship("User")
    interview: Mapped["Interview | None"] = relationship(
        "Interview", back_populates="application", uselist=False, cascade="all, delete-orphan"
    )
