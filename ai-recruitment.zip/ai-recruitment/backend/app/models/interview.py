from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any

from sqlalchemy import (
    JSON,
    DateTime,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.session import Base

if TYPE_CHECKING:
    from app.models.application import Application

# invited -> in_progress -> completed
INTERVIEW_STATUSES = ("invited", "in_progress", "completed")
# pending -> running -> done | failed
EVAL_STATUSES = ("pending", "running", "done", "failed")


class Interview(Base):
    __tablename__ = "interviews"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    application_id: Mapped[int] = mapped_column(
        ForeignKey("applications.id", ondelete="CASCADE"), unique=True, index=True
    )

    status: Mapped[str] = mapped_column(String(20), default="invited", index=True)
    mode: Mapped[str | None] = mapped_column(String(20), nullable=True)  # ai | built-in
    questions_planned: Mapped[int] = mapped_column(Integer, default=5)
    focus: Mapped[str | None] = mapped_column(String(300), nullable=True)  # HR guidance
    plan: Mapped[list[dict[str, Any]] | None] = mapped_column(JSON, nullable=True)
    followups_used: Mapped[int] = mapped_column(Integer, default=0)  # for the current question

    invited_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    consent_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    ended_reason: Mapped[str | None] = mapped_column(String(30), nullable=True)

    eval_status: Mapped[str] = mapped_column(String(20), default="pending")
    evaluation: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
    eval_model: Mapped[str | None] = mapped_column(String(80), nullable=True)
    eval_error: Mapped[str | None] = mapped_column(String(300), nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    application: Mapped["Application"] = relationship("Application", back_populates="interview")
    turns: Mapped[list["InterviewTurn"]] = relationship(
        "InterviewTurn",
        back_populates="interview",
        cascade="all, delete-orphan",
        order_by="InterviewTurn.idx",
    )


class InterviewTurn(Base):
    __tablename__ = "interview_turns"
    __table_args__ = (UniqueConstraint("interview_id", "idx", name="uq_turn_interview_idx"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    interview_id: Mapped[int] = mapped_column(
        ForeignKey("interviews.id", ondelete="CASCADE"), index=True
    )
    idx: Mapped[int] = mapped_column(Integer)
    role: Mapped[str] = mapped_column(String(12))  # interviewer | candidate
    # greeting | question | followup | clarify | closing | answer
    kind: Mapped[str] = mapped_column(String(20))
    topic: Mapped[str | None] = mapped_column(String(120), nullable=True)
    text: Mapped[str] = mapped_column(Text)
    input_mode: Mapped[str | None] = mapped_column(String(10), nullable=True)  # voice | typed
    source: Mapped[str | None] = mapped_column(String(12), nullable=True)  # ai | built-in | candidate
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    interview: Mapped["Interview"] = relationship("Interview", back_populates="turns")
