from __future__ import annotations

from datetime import date, datetime
from typing import TYPE_CHECKING

from sqlalchemy import (
    JSON,
    Boolean,
    Date,
    DateTime,
    ForeignKey,
    Integer,
    String,
    Text,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.session import Base

if TYPE_CHECKING:
    from app.models.user import User

# Job lifecycle: draft -> approved -> published (and back via unpublish/edit)
JOB_STATUSES = ("draft", "approved", "published")


class Job(Base):
    __tablename__ = "jobs"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    owner_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )

    # ---- requirements entered by HR ----
    title: Mapped[str] = mapped_column(String(200))
    department: Mapped[str | None] = mapped_column(String(120), nullable=True)
    location: Mapped[str | None] = mapped_column(String(160), nullable=True)
    employment_type: Mapped[str] = mapped_column(String(30), default="full_time")
    work_mode: Mapped[str] = mapped_column(String(20), default="onsite")
    experience_level: Mapped[str] = mapped_column(String(20), default="mid")
    min_experience_years: Mapped[int | None] = mapped_column(Integer, nullable=True)
    max_experience_years: Mapped[int | None] = mapped_column(Integer, nullable=True)
    education: Mapped[str | None] = mapped_column(String(200), nullable=True)
    salary_min: Mapped[int | None] = mapped_column(Integer, nullable=True)
    salary_max: Mapped[int | None] = mapped_column(Integer, nullable=True)
    salary_currency: Mapped[str | None] = mapped_column(String(8), nullable=True)
    show_salary: Mapped[bool] = mapped_column(Boolean, default=False)
    openings: Mapped[int] = mapped_column(Integer, default=1)
    application_deadline: Mapped[date | None] = mapped_column(Date, nullable=True)
    required_skills: Mapped[list[str]] = mapped_column(JSON, default=list)
    nice_to_have_skills: Mapped[list[str]] = mapped_column(JSON, default=list)
    responsibilities: Mapped[str | None] = mapped_column(Text, nullable=True)
    company_about: Mapped[str | None] = mapped_column(Text, nullable=True)

    # ---- job description ----
    jd_text: Mapped[str | None] = mapped_column(Text, nullable=True)  # Markdown
    jd_source: Mapped[str | None] = mapped_column(String(20), nullable=True)  # ai | template | manual
    jd_edited: Mapped[bool] = mapped_column(Boolean, default=False)
    jd_model: Mapped[str | None] = mapped_column(String(80), nullable=True)

    # ---- what the job is actually about (built from the post; refined by AI when available) ----
    profile: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    profile_signature: Mapped[str | None] = mapped_column(String(64), nullable=True)

    # ---- hiring automation (off until HR switches it on) ----
    auto_enabled: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    auto_cv_threshold: Mapped[int] = mapped_column(Integer, default=60, server_default="60")
    auto_interview_threshold: Mapped[int] = mapped_column(Integer, default=65, server_default="65")
    auto_reject_below_cv: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")
    auto_questions: Mapped[int] = mapped_column(Integer, default=5, server_default="5")

    # ---- workflow ----
    status: Mapped[str] = mapped_column(String(20), default="draft", index=True)
    approved_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    published_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    owner: Mapped["User"] = relationship("User")
