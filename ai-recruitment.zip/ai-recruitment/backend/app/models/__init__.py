# Import every model here so Alembic can see them.
from app.models.user import User, UserRole  # noqa: F401
from app.models.job import Job  # noqa: F401
from app.models.application import Application  # noqa: F401
from app.models.interview import Interview, InterviewTurn  # noqa: F401
from app.models.embedding import TextEmbedding  # noqa: F401
from app.models.automation import AutomationEvent  # noqa: F401
