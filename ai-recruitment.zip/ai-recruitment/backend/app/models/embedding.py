from datetime import datetime

from sqlalchemy import DateTime, LargeBinary, String, func
from sqlalchemy.orm import Mapped, mapped_column

from app.db.session import Base


class TextEmbedding(Base):
    """Cache of text -> embedding vector, so a CV or job is only embedded once."""

    __tablename__ = "text_embeddings"

    key: Mapped[str] = mapped_column(String(64), primary_key=True)  # sha256(model + kind + text)
    model: Mapped[str] = mapped_column(String(120))
    vector: Mapped[bytes] = mapped_column(LargeBinary)  # float32, L2-normalised
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
