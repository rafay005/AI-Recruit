import re
from datetime import date, datetime, timezone

from fastapi import (
    APIRouter,
    BackgroundTasks,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    Response,
    UploadFile,
)
from fastapi.responses import FileResponse
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, require_hr
from app.db.session import get_db
from app.models.application import DECISIONS, Application
from app.models.job import Job
from app.models.user import User, UserRole
from app.schemas.application import (
    ApplicationListItem,
    ApplicationOut,
    DecisionIn,
    DecisionOut,
    HRApplicationDetail,
    JobBrief,
)
from app.schemas.cv import ExtractedCV
from app.schemas.interview import InterviewBrief
from app.services.cv.pipeline import STALE_AFTER_SECONDS, analyze_application
from app.services.matching import match_application
from app.services.storage import cv_file_path, delete_cv, save_cv

PHONE_RE = re.compile(r"^[0-9+()\-\s.]{6,40}$")


def require_candidate(user: User = Depends(get_current_user)) -> User:
    if user.role != UserRole.CANDIDATE:
        raise HTTPException(status_code=403, detail="Only candidates can apply for jobs")
    return user


def _extracted(app: Application) -> ExtractedCV | None:
    if not app.extracted:
        return None
    try:
        return ExtractedCV.model_validate(app.extracted)
    except Exception:
        return None


def _brief(job: Job) -> JobBrief:
    return JobBrief(id=job.id, title=job.title, company=job.owner.company if job.owner else None)


def _out(app: Application) -> ApplicationOut:
    return ApplicationOut(
        id=app.id,
        job=_brief(app.job),
        phone=app.phone,
        cover_note=app.cover_note,
        cv_filename=app.cv_filename,
        cv_size=app.cv_size,
        analysis_status=app.analysis_status,
        analysis_error=app.analysis_error,
        analysis_note=app.analysis_note,
        extraction_method=app.extraction_method,
        analysis_model=app.analysis_model,
        created_at=app.created_at,
        analyzed_at=app.analyzed_at,
        extracted=_extracted(app),
        decision=app.decision or "under_review",
        decision_note=app.decision_note,
        decision_at=app.decision_at,
        interview=InterviewBrief(id=app.interview.id, status=app.interview.status) if app.interview else None,
    )


def _is_stuck(app: Application) -> bool:
    if app.analysis_status != "processing":
        return False
    started = app.analysis_started_at or app.updated_at or app.created_at
    if started.tzinfo is None:
        started = started.replace(tzinfo=timezone.utc)
    return (datetime.now(timezone.utc) - started).total_seconds() > STALE_AFTER_SECONDS


def _restart(app: Application, db: Session, background: BackgroundTasks) -> None:
    app.analysis_status = "processing"
    app.analysis_started_at = datetime.now(timezone.utc)
    app.analysis_error = None
    app.analysis_note = None
    db.commit()
    background.add_task(analyze_application, app.id)


# ============================ Candidate ============================

router = APIRouter(prefix="/api", tags=["applications"])


@router.post("/jobs/{job_id}/apply", response_model=ApplicationOut, status_code=201)
def apply_for_job(
    job_id: int,
    background: BackgroundTasks,
    cv: UploadFile = File(...),
    phone: str | None = Form(default=None),
    cover_note: str | None = Form(default=None),
    user: User = Depends(require_candidate),
    db: Session = Depends(get_db),
):
    job = db.scalar(
        select(Job).where(
            Job.id == job_id,
            Job.status == "published",
        )
    )
    if not job or (job.application_deadline and job.application_deadline < date.today()):
        raise HTTPException(status_code=404, detail="This job is not open for applications.")

    if db.scalar(
        select(Application.id).where(
            Application.job_id == job_id, Application.candidate_id == user.id
        )
    ):
        raise HTTPException(status_code=409, detail="You have already applied for this job.")

    phone = (phone or "").strip() or None
    if phone and not PHONE_RE.match(phone):
        raise HTTPException(status_code=422, detail="Please enter a valid phone number.")
    cover_note = (cover_note or "").strip() or None
    if cover_note and len(cover_note) > 2000:
        raise HTTPException(status_code=422, detail="The cover note must be 2000 characters or fewer.")

    stored, display, content_type, size = save_cv(cv)
    application = Application(
        job_id=job.id,
        candidate_id=user.id,
        phone=phone,
        cover_note=cover_note,
        cv_filename=display,
        cv_stored_name=stored,
        cv_content_type=content_type,
        cv_size=size,
        analysis_status="processing",
    )
    db.add(application)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        delete_cv(stored)
        raise HTTPException(status_code=409, detail="You have already applied for this job.")
    db.refresh(application)
    background.add_task(analyze_application, application.id)
    return _out(application)


@router.get("/applications/mine", response_model=list[ApplicationOut])
def my_applications(user: User = Depends(require_candidate), db: Session = Depends(get_db)):
    rows = db.scalars(
        select(Application)
        .where(Application.candidate_id == user.id)
        .order_by(Application.created_at.desc(), Application.id.desc())
    )
    return [_out(a) for a in rows]


def _get_mine(db: Session, application_id: int, user: User) -> Application:
    app = db.scalar(
        select(Application).where(
            Application.id == application_id, Application.candidate_id == user.id
        )
    )
    if not app:
        raise HTTPException(status_code=404, detail="Application not found")
    return app


@router.get("/applications/{application_id}", response_model=ApplicationOut)
def get_my_application(
    application_id: int, user: User = Depends(require_candidate), db: Session = Depends(get_db)
):
    return _out(_get_mine(db, application_id, user))


@router.post("/applications/{application_id}/retry", response_model=ApplicationOut)
def retry_my_analysis(
    application_id: int,
    background: BackgroundTasks,
    user: User = Depends(require_candidate),
    db: Session = Depends(get_db),
):
    app = _get_mine(db, application_id, user)
    if app.analysis_status != "failed" and not _is_stuck(app):
        raise HTTPException(status_code=409, detail="Your CV is not in a state that can be retried.")
    _restart(app, db, background)
    db.refresh(app)
    return _out(app)


@router.delete("/applications/{application_id}", status_code=204)
def withdraw_application(
    application_id: int, user: User = Depends(require_candidate), db: Session = Depends(get_db)
):
    app = _get_mine(db, application_id, user)
    stored = app.cv_stored_name
    db.delete(app)
    db.commit()
    delete_cv(stored)  # remove the CV file together with the application
    return Response(status_code=204)


# ============================ HR ============================

hr_router = APIRouter(prefix="/api/hr/applications", tags=["hr-applications"])


def _get_hr_application(db: Session, application_id: int, user: User) -> Application:
    app = db.scalar(
        select(Application)
        .join(Job, Job.id == Application.job_id)
        .where(Application.id == application_id, Job.owner_id == user.id)
    )
    if not app:
        raise HTTPException(status_code=404, detail="Application not found")
    return app


@hr_router.get("", response_model=list[ApplicationListItem])
def list_applications(
    job_id: int | None = Query(default=None),
    user: User = Depends(require_hr),
    db: Session = Depends(get_db),
):
    q = (
        select(Application)
        .join(Job, Job.id == Application.job_id)
        .where(Job.owner_id == user.id)
        .order_by(Application.created_at.desc(), Application.id.desc())
    )
    if job_id is not None:
        q = q.where(Application.job_id == job_id)
    items: list[ApplicationListItem] = []
    for a in db.scalars(q):
        ex = _extracted(a)
        m = match_application(a.job, a.extracted, a.parsed_text) if a.analysis_status == "done" else None
        items.append(
            ApplicationListItem(
                id=a.id,
                job_id=a.job_id,
                job_title=a.job.title,
                candidate_name=(ex.name if ex and ex.name else a.candidate.full_name),
                candidate_email=(ex.email if ex and ex.email else a.candidate.email),
                cv_filename=a.cv_filename,
                created_at=a.created_at,
                analysis_status=a.analysis_status,
                skills=(ex.skills[:8] if ex else []),
                total_experience_years=(ex.total_experience_years if ex else None),
                extraction_method=a.extraction_method,
                match_percent=m.overall if m else None,
                match_label=m.label if m else None,
                decision=a.decision or "under_review",
            )
        )
    return items


@hr_router.get("/{application_id}", response_model=HRApplicationDetail)
def get_application(
    application_id: int, user: User = Depends(require_hr), db: Session = Depends(get_db)
):
    a = _get_hr_application(db, application_id, user)
    base = _out(a).model_dump()
    return HRApplicationDetail(
        **base,
        candidate_account_name=a.candidate.full_name,
        candidate_account_email=a.candidate.email,
        parsed_text=a.parsed_text,
    )


@hr_router.get("/{application_id}/cv")
def download_cv(
    application_id: int, user: User = Depends(require_hr), db: Session = Depends(get_db)
):
    a = _get_hr_application(db, application_id, user)
    try:
        path = cv_file_path(a.cv_stored_name)
    except ValueError:
        raise HTTPException(status_code=404, detail="CV file not found")
    if not path.exists():
        raise HTTPException(status_code=404, detail="CV file not found")
    return FileResponse(
        path,
        media_type=a.cv_content_type,
        filename=a.cv_filename,
        content_disposition_type="attachment",
    )


@hr_router.post("/{application_id}/reanalyze", response_model=HRApplicationDetail)
def reanalyze(
    application_id: int,
    background: BackgroundTasks,
    user: User = Depends(require_hr),
    db: Session = Depends(get_db),
):
    a = _get_hr_application(db, application_id, user)
    if a.analysis_status == "processing" and not _is_stuck(a):
        raise HTTPException(status_code=409, detail="This CV is already being analysed.")
    _restart(a, db, background)
    db.refresh(a)
    base = _out(a).model_dump()
    return HRApplicationDetail(
        **base,
        candidate_account_name=a.candidate.full_name,
        candidate_account_email=a.candidate.email,
        parsed_text=a.parsed_text,
    )


@hr_router.put("/{application_id}/decision", response_model=DecisionOut)
def set_decision(
    application_id: int,
    body: DecisionIn,
    user: User = Depends(require_hr),
    db: Session = Depends(get_db),
):
    """HR decides what happens to a candidate. The candidate can see the result."""
    a = _get_hr_application(db, application_id, user)
    if body.decision not in DECISIONS:
        raise HTTPException(status_code=422, detail="Unknown decision.")
    note = (body.note or "").strip() or None
    if note and len(note) > 500:
        raise HTTPException(status_code=422, detail="The note must be 500 characters or fewer.")
    if body.decision == "under_review":
        note = None
    a.decision = body.decision
    a.decision_note = note
    a.decision_at = None if body.decision == "under_review" else datetime.now(timezone.utc)
    a.decision_source = None if body.decision == "under_review" else "hr"
    db.commit()
    db.refresh(a)
    return DecisionOut(decision=a.decision, decision_note=a.decision_note, decision_at=a.decision_at)
