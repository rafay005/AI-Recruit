from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import require_hr
from app.db.session import get_db
from app.models.application import Application
from app.models.job import Job
from app.models.user import User
from app.schemas.match import CandidateMatchOut, RankingOut
from app.services.ranking import job_criteria, rank_job

router = APIRouter(prefix="/api/hr", tags=["ranking"])


def _owned_job(db: Session, job_id: int, user: User) -> Job:
    job = db.scalar(select(Job).where(Job.id == job_id, Job.owner_id == user.id))
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@router.get("/jobs/{job_id}/ranking", response_model=RankingOut)
def job_ranking(job_id: int, user: User = Depends(require_hr), db: Session = Depends(get_db)):
    job = _owned_job(db, job_id, user)
    ranked, unranked = rank_job(db, job)
    return RankingOut(job=job_criteria(job), ranked=ranked, unranked=unranked)


@router.get("/applications/{application_id}/match", response_model=CandidateMatchOut)
def application_match(
    application_id: int, user: User = Depends(require_hr), db: Session = Depends(get_db)
):
    app = db.scalar(
        select(Application)
        .join(Job, Job.id == Application.job_id)
        .where(Application.id == application_id, Job.owner_id == user.id)
    )
    if not app:
        raise HTTPException(status_code=404, detail="Application not found")
    job = app.job
    ranked, unranked = rank_job(db, job)
    for r in ranked:
        if r.application_id == app.id:
            return CandidateMatchOut(job=job_criteria(job), rank=r.rank, total_ranked=len(ranked), match=r.match)
    reason = next((u.reason for u in unranked if u.application_id == app.id), "Not ranked yet.")
    return CandidateMatchOut(
        job=job_criteria(job), rank=None, total_ranked=len(ranked), match=None, reason=reason
    )
