from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import require_hr
from app.db.session import get_db
from app.models.application import Application
from app.models.job import Job
from app.models.user import User
from app.schemas.cv import ExtractedCV
from app.schemas.gap import SkillGapOut
from app.schemas.match import MatchBreakdown
from app.services.llm_client import llm_available
from app.services.matching import match_cv
from app.services.ranking import job_criteria
from app.services.skillgap import (
    LLMError,
    build_gap_out,
    built_in_assessment,
    explain_with_ai,
    store_ai_assessment,
)

router = APIRouter(prefix="/api/hr/applications", tags=["skill-gap"])


def _load(db: Session, application_id: int, user: User) -> tuple[Application, Job, ExtractedCV, MatchBreakdown]:
    app = db.scalar(
        select(Application)
        .join(Job, Job.id == Application.job_id)
        .where(Application.id == application_id, Job.owner_id == user.id)
    )
    if not app:
        raise HTTPException(status_code=404, detail="Application not found")
    if app.analysis_status != "done" or not app.extracted:
        raise HTTPException(status_code=409, detail="This CV has not been analysed yet.")
    try:
        cv = ExtractedCV.model_validate(app.extracted)
    except Exception:
        raise HTTPException(status_code=409, detail="This CV has no readable data to compare.")
    return app, app.job, cv, match_cv(app.job, cv, app.parsed_text)


def _out(app: Application, job: Job, cv: ExtractedCV, match: MatchBreakdown) -> SkillGapOut:
    name = cv.name or app.candidate.full_name
    return build_gap_out(app, job, cv, match, job_criteria(job), name)


@router.get("/{application_id}/skill-gap", response_model=SkillGapOut)
def get_skill_gap(application_id: int, user: User = Depends(require_hr), db: Session = Depends(get_db)):
    app, job, cv, match = _load(db, application_id, user)
    return _out(app, job, cv, match)


@router.post("/{application_id}/skill-gap/explain", response_model=SkillGapOut)
def explain_skill_gap(application_id: int, user: User = Depends(require_hr), db: Session = Depends(get_db)):
    app, job, cv, match = _load(db, application_id, user)
    if not llm_available():
        raise HTTPException(
            status_code=409,
            detail="No AI provider is configured. Add an API key in the backend .env file to get AI explanations.",
        )
    base = built_in_assessment(job, cv, app.parsed_text, match)
    try:
        ai = explain_with_ai(job, cv, match, base)
    except LLMError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except (ValueError, KeyError, TypeError):
        raise HTTPException(status_code=502, detail="The AI response could not be understood. Please try again.")
    store_ai_assessment(app, job, cv, match, ai)
    db.commit()
    db.refresh(app)
    return _out(app, job, cv, match)
