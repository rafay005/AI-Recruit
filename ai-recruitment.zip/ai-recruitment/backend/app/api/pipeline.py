"""Pipeline board: every candidate as a card in a stage column; HR moves them by hand.

A manual move is HR's decision (decision_source = "hr"), so the automation never moves
that candidate again. Moving into Interview creates the invitation; moving out of
Interview can cancel an invitation that was never started.
"""
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import require_hr
from app.core.config import settings
from app.db.session import get_db
from app.models.application import DECISIONS, Application
from app.models.automation import AutomationEvent
from app.models.interview import Interview
from app.models.job import Job
from app.models.user import User
from app.services import notify
from app.services.automation import (
    NOTE_CV_REJECTED, NOTE_INVITED, NOTE_SELECTED, selected_count,
)
from app.services.interview.plan import clamp_questions
from app.services.ranking import rank_job

router = APIRouter(prefix="/api/hr", tags=["pipeline"])

STAGE_LABEL = {"under_review": "Under review", "shortlisted": "Shortlisted", "interview": "Interview",
               "hired": "Selected", "rejected": "Rejected"}
DEFAULT_NOTE = {"interview": NOTE_INVITED, "hired": NOTE_SELECTED, "rejected": NOTE_CV_REJECTED}


class StageIn(BaseModel):
    stage: str
    note: str | None = Field(default=None, max_length=500)
    cancel_interview: bool = False  # when leaving Interview: delete an invitation that was never started


def _interview_score(a: Application) -> int | None:
    iv = a.interview
    if iv and iv.eval_status == "done" and isinstance(iv.evaluation, dict) and iv.evaluation.get("overall") is not None:
        return int(iv.evaluation["overall"])
    return None


def _card(a: Application, rank: int | None, match: int | None) -> dict:
    ex = a.extracted if isinstance(a.extracted, dict) else {}
    return {
        "application_id": a.id,
        "name": ex.get("name") or a.candidate.full_name,
        "job_id": a.job_id,
        "job_title": a.job.title,
        "stage": a.decision or "under_review",
        "rank": rank,
        "match": match,
        "interview_score": _interview_score(a),
        "interview_status": a.interview.status if a.interview else None,
        "decision_source": a.decision_source,
        "since": a.decision_at or a.created_at,
        "analysed": a.analysis_status == "done",
        "skills": (ex.get("skills") or [])[:4],
    }


def _job_out(db: Session, j: Job) -> dict:
    return {"id": j.id, "title": j.title, "status": j.status, "openings": j.openings,
            "selected": selected_count(db, j), "auto_enabled": j.auto_enabled}


@router.get("/pipeline")
def pipeline(job_id: int | None = Query(default=None), user: User = Depends(require_hr), db: Session = Depends(get_db)):
    jobs = list(db.scalars(select(Job).where(Job.owner_id == user.id).order_by(Job.created_at.desc())))
    if job_id is not None and not any(j.id == job_id for j in jobs):
        raise HTTPException(status_code=404, detail="Job not found")
    cards = []
    for j in jobs:
        if job_id is not None and j.id != job_id:
            continue
        ranked, unranked = rank_job(db, j)
        apps = {a.id: a for a in db.scalars(select(Application).where(Application.job_id == j.id))}
        for r in ranked:
            cards.append(_card(apps[r.application_id], r.rank, r.match.overall))
        for u in unranked:
            cards.append(_card(apps[u.application_id], None, None))
    return {
        "jobs": [_job_out(db, j) for j in jobs],
        "job_id": job_id,
        "stages": [{"key": k, "label": STAGE_LABEL[k]} for k in ("under_review", "shortlisted", "interview", "hired", "rejected")],
        "cards": cards,
        "email_enabled": notify.email_enabled(),
    }


@router.put("/applications/{application_id}/stage")
def move(application_id: int, body: StageIn, user: User = Depends(require_hr), db: Session = Depends(get_db)):
    a = db.scalar(select(Application).join(Job, Job.id == Application.job_id)
                  .where(Application.id == application_id, Job.owner_id == user.id))
    if not a:
        raise HTTPException(status_code=404, detail="Application not found")
    if body.stage not in DECISIONS:
        raise HTTPException(status_code=422, detail="Unknown stage.")
    job = a.job
    old = a.decision or "under_review"
    warning = None
    created_interview = cancelled_interview = False

    if body.stage == "interview" and a.interview is None:
        if a.analysis_status != "done" or not a.extracted:
            raise HTTPException(status_code=409, detail="The CV must be analysed before the candidate can be interviewed.")
        db.add(Interview(application_id=a.id, status="invited", followups_used=0, eval_status="pending",
                         questions_planned=clamp_questions(job.auto_questions, settings.INTERVIEW_QUESTIONS)))
        created_interview = True
    if old == "interview" and body.stage != "interview" and body.cancel_interview and a.interview is not None:
        if a.interview.status != "invited":
            raise HTTPException(status_code=409, detail="The interview has already started, so it cannot be cancelled.")
        db.delete(a.interview)
        cancelled_interview = True
    if body.stage == "hired" and old != "hired":
        taken = selected_count(db, job)
        if taken >= job.openings:
            warning = f"All {job.openings} {'opening was' if job.openings == 1 else 'openings were'} already filled. Selected anyway."

    note = (body.note or "").strip() or DEFAULT_NOTE.get(body.stage)
    a.decision = body.stage
    a.decision_note = None if body.stage == "under_review" else note
    a.decision_at = None if body.stage == "under_review" else datetime.now(timezone.utc)
    a.decision_source = None if body.stage == "under_review" else "hr"
    db.add(AutomationEvent(job_id=job.id, application_id=a.id, action="manual_move", score=a.match_score,
                           detail=f"Moved from {STAGE_LABEL[old]} to {STAGE_LABEL[body.stage]} by HR."
                                  + (" Interview invitation created." if created_interview else "")
                                  + (" Interview invitation cancelled." if cancelled_interview else "")))
    db.commit()
    db.refresh(a)

    emailed = False
    if old != body.stage:
        ex = a.extracted if isinstance(a.extracted, dict) else {}
        first = (ex.get("name") or a.candidate.full_name or "there").split(" ")[0]
        company = job.owner.company if job.owner else None
        if body.stage == "interview":
            emailed = notify.interview_invite(first, a.candidate.email, job.title, company)
        elif body.stage in ("hired", "rejected"):
            emailed = notify.decision(first, a.candidate.email, job.title, company, selected=body.stage == "hired")

    return {
        "card": _card(a, None, a.match_score),
        "previous": old,
        "warning": warning,
        "created_interview": created_interview,
        "cancelled_interview": cancelled_interview,
        "emailed": emailed,
        "job": _job_out(db, job),
    }
