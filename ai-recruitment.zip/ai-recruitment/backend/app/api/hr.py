from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.api.deps import require_hr
from app.db.session import get_db
from app.models.application import MOVED_FORWARD, Application
from app.models.interview import Interview
from app.models.job import Job
from app.models.user import User

router = APIRouter(prefix="/api/hr", tags=["hr"])


@router.get("/dashboard")
def dashboard(user: User = Depends(require_hr), db: Session = Depends(get_db)):
    rows = db.execute(
        select(Job.status, func.count(Job.id))
        .where(Job.owner_id == user.id)
        .group_by(Job.status)
    ).all()
    counts = {status: n for status, n in rows}
    applicants = db.scalar(
        select(func.count(Application.id))
        .join(Job, Job.id == Application.job_id)
        .where(Job.owner_id == user.id)
    ) or 0
    moved_forward = db.scalar(
        select(func.count(Application.id))
        .join(Job, Job.id == Application.job_id)
        .where(Job.owner_id == user.id, Application.decision.in_(MOVED_FORWARD))
    ) or 0
    iv_rows = db.execute(
        select(Interview.status, func.count(Interview.id))
        .join(Application, Application.id == Interview.application_id)
        .join(Job, Job.id == Application.job_id)
        .where(Job.owner_id == user.id)
        .group_by(Interview.status)
    ).all()
    iv_counts = {status: n for status, n in iv_rows}
    return {
        "hr_name": user.full_name,
        "company": user.company,
        "stats": {
            "open_jobs": counts.get("published", 0),
            "draft_jobs": counts.get("draft", 0) + counts.get("approved", 0),
            "total_applicants": applicants,
            # Placeholders until later phases
            "interviews_scheduled": iv_counts.get("invited", 0) + iv_counts.get("in_progress", 0),
            "interviews_completed": iv_counts.get("completed", 0),
            "shortlisted": moved_forward,
        },
    }
