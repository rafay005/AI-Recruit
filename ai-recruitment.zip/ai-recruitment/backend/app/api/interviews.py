from datetime import datetime, timezone

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Response
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.applications import require_candidate
from app.api.deps import require_hr
from app.core.config import settings
from app.db.session import get_db
from app.models.application import Application
from app.models.interview import Interview
from app.models.job import Job
from app.models.user import User
from app.schemas.interview import (
    AnswerIn,
    Evaluation,
    HRTurnOut,
    InterviewCandidateOut,
    InterviewHROut,
    InviteIn,
    StartIn,
    TurnOut,
    TurnsOut,
)
from app.services.interview import engine
from app.services.interview.evaluation import run_evaluation
from app.services.interview.plan import clamp_questions

# ============================ helpers ============================


def _asked(iv: Interview) -> int:
    return engine.main_questions_asked(iv.turns)


def _turns_out(turns) -> list[TurnOut]:
    return [TurnOut(idx=t.idx, role=t.role, kind=t.kind, text=t.text, created_at=t.created_at) for t in turns]


def _can_answer(iv: Interview) -> bool:
    return bool(
        iv.status == "in_progress" and iv.turns and iv.turns[-1].role == "interviewer" and iv.turns[-1].kind != "closing"
    )


def _needs_reply(iv: Interview) -> bool:
    return bool(iv.status == "in_progress" and iv.turns and iv.turns[-1].role == "candidate")


def _candidate_out(iv: Interview) -> InterviewCandidateOut:
    job = iv.application.job
    return InterviewCandidateOut(
        id=iv.id,
        status=iv.status,
        job_title=job.title,
        company=job.owner.company if job.owner else None,
        mode=iv.mode,
        questions_planned=iv.questions_planned,
        questions_asked=_asked(iv),
        started_at=iv.started_at,
        completed_at=iv.completed_at,
        max_minutes=settings.INTERVIEW_MAX_MINUTES,
        turns=_turns_out(iv.turns),
        can_answer=_can_answer(iv),
        needs_reply=_needs_reply(iv),
    )


def _result(iv: Interview, new_turns) -> TurnsOut:
    return TurnsOut(
        new_turns=_turns_out(new_turns),
        status=iv.status,
        done=iv.status == "completed",
        questions_asked=_asked(iv),
        questions_planned=iv.questions_planned,
    )


def _transcript_text(iv: Interview, candidate_label: str) -> str:
    job = iv.application.job
    lines = [
        "Interview transcript",
        f"Role: {job.title}",
        f"Date: {(iv.started_at or iv.invited_at).strftime('%Y-%m-%d %H:%M UTC')}",
        "",
    ]
    for t in iv.turns:
        who = "Interviewer" if t.role == "interviewer" else candidate_label
        lines.append(f"{who}: {t.text}")
        lines.append("")
    return "\n".join(lines).strip() + "\n"


# ============================ candidate ============================

router = APIRouter(prefix="/api/interviews", tags=["interviews"])


def _get_mine(db: Session, interview_id: int, user: User) -> Interview:
    iv = db.scalar(
        select(Interview)
        .join(Application, Application.id == Interview.application_id)
        .where(Interview.id == interview_id, Application.candidate_id == user.id)
    )
    if not iv:
        raise HTTPException(status_code=404, detail="Interview not found")
    return iv


@router.get("/{interview_id}", response_model=InterviewCandidateOut)
def get_interview(interview_id: int, user: User = Depends(require_candidate), db: Session = Depends(get_db)):
    return _candidate_out(_get_mine(db, interview_id, user))


@router.post("/{interview_id}/start", response_model=TurnsOut)
def start_interview(
    interview_id: int, body: StartIn, user: User = Depends(require_candidate), db: Session = Depends(get_db)
):
    iv = _get_mine(db, interview_id, user)
    if iv.status == "completed":
        raise HTTPException(status_code=409, detail="This interview is already complete.")
    if iv.status == "in_progress":  # resuming: nothing new to create
        return _result(iv, [])
    if not body.consent:
        raise HTTPException(status_code=422, detail="Please agree to the conditions to start the interview.")
    iv.consent_at = datetime.now(timezone.utc)
    new = engine.start_interview(db, iv)
    return _result(iv, new)


@router.post("/{interview_id}/answer", response_model=TurnsOut)
def answer(
    interview_id: int,
    body: AnswerIn,
    background: BackgroundTasks,
    user: User = Depends(require_candidate),
    db: Session = Depends(get_db),
):
    iv = _get_mine(db, interview_id, user)
    if not _can_answer(iv):
        raise HTTPException(status_code=409, detail="There is no question to answer right now.")
    last = iv.turns[-1]
    engine.add_turn(
        db, iv, "candidate", "answer", body.text,
        topic=last.topic, input_mode=body.input_mode, source="candidate",
    )
    db.commit()  # the answer is saved even if producing the reply fails
    new = engine.advance(db, iv)
    if iv.status == "completed":
        background.add_task(run_evaluation, iv.id)
    return _result(iv, new)


@router.post("/{interview_id}/continue", response_model=TurnsOut)
def continue_interview(
    interview_id: int,
    background: BackgroundTasks,
    user: User = Depends(require_candidate),
    db: Session = Depends(get_db),
):
    """Used after a dropped connection: the answer was saved but the reply never arrived."""
    iv = _get_mine(db, interview_id, user)
    if not _needs_reply(iv):
        raise HTTPException(status_code=409, detail="Nothing to continue.")
    new = engine.advance(db, iv)
    if iv.status == "completed":
        background.add_task(run_evaluation, iv.id)
    return _result(iv, new)


@router.post("/{interview_id}/end", response_model=TurnsOut)
def end_interview(
    interview_id: int,
    background: BackgroundTasks,
    user: User = Depends(require_candidate),
    db: Session = Depends(get_db),
):
    iv = _get_mine(db, interview_id, user)
    if iv.status != "in_progress":
        raise HTTPException(status_code=409, detail="This interview is not in progress.")
    new = engine.end_early(db, iv)
    background.add_task(run_evaluation, iv.id)
    return _result(iv, new)


@router.get("/{interview_id}/transcript")
def my_transcript(interview_id: int, user: User = Depends(require_candidate), db: Session = Depends(get_db)):
    iv = _get_mine(db, interview_id, user)
    if not iv.turns:
        raise HTTPException(status_code=404, detail="There is no transcript yet.")
    return Response(
        _transcript_text(iv, "You"),
        media_type="text/plain; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="interview-transcript.txt"'},
    )


# ============================ HR ============================

hr_router = APIRouter(prefix="/api/hr", tags=["hr-interviews"])


def _hr_application(db: Session, application_id: int, user: User) -> Application:
    app = db.scalar(
        select(Application)
        .join(Job, Job.id == Application.job_id)
        .where(Application.id == application_id, Job.owner_id == user.id)
    )
    if not app:
        raise HTTPException(status_code=404, detail="Application not found")
    return app


def _hr_interview(db: Session, interview_id: int, user: User) -> Interview:
    iv = db.scalar(
        select(Interview)
        .join(Application, Application.id == Interview.application_id)
        .join(Job, Job.id == Application.job_id)
        .where(Interview.id == interview_id, Job.owner_id == user.id)
    )
    if not iv:
        raise HTTPException(status_code=404, detail="Interview not found")
    return iv


def _hr_out(iv: Interview) -> InterviewHROut:
    ev = None
    if iv.evaluation:
        try:
            ev = Evaluation.model_validate(iv.evaluation)
        except Exception:
            ev = None
    return InterviewHROut(
        id=iv.id,
        application_id=iv.application_id,
        status=iv.status,
        mode=iv.mode,
        questions_planned=iv.questions_planned,
        questions_asked=_asked(iv),
        focus=iv.focus,
        invited_at=iv.invited_at,
        started_at=iv.started_at,
        completed_at=iv.completed_at,
        ended_reason=iv.ended_reason,
        eval_status=iv.eval_status,
        eval_error=iv.eval_error,
        evaluation=ev,
        turns=[
            HRTurnOut(
                idx=t.idx, role=t.role, kind=t.kind, text=t.text, created_at=t.created_at,
                topic=t.topic, input_mode=t.input_mode, source=t.source,
            )
            for t in iv.turns
        ],
    )


@hr_router.post("/applications/{application_id}/interview", response_model=InterviewHROut, status_code=201)
def invite_to_interview(
    application_id: int,
    body: InviteIn | None = None,
    user: User = Depends(require_hr),
    db: Session = Depends(get_db),
):
    app = _hr_application(db, application_id, user)
    if app.analysis_status != "done" or not app.extracted:
        raise HTTPException(status_code=409, detail="The CV must be analysed before you can invite the candidate.")
    if app.interview is not None:
        raise HTTPException(status_code=409, detail="An interview is already set up for this candidate.")
    body = body or InviteIn()
    iv = Interview(
        application_id=app.id,
        status="invited",
        questions_planned=clamp_questions(body.questions, settings.INTERVIEW_QUESTIONS),
        focus=body.focus,
        followups_used=0,
        eval_status="pending",
    )
    db.add(iv)
    if app.decision in ("under_review", "shortlisted"):
        app.decision = "interview"
        app.decision_at = datetime.now(timezone.utc)
        app.decision_source = "hr"
    db.commit()
    db.refresh(iv)
    return _hr_out(iv)


@hr_router.get("/applications/{application_id}/interview", response_model=InterviewHROut | None)
def get_application_interview(
    application_id: int, user: User = Depends(require_hr), db: Session = Depends(get_db)
):
    app = _hr_application(db, application_id, user)
    return _hr_out(app.interview) if app.interview else None


@hr_router.delete("/interviews/{interview_id}", status_code=204)
def reset_interview(interview_id: int, user: User = Depends(require_hr), db: Session = Depends(get_db)):
    """Cancel an invitation, or throw away an interview so the candidate can be invited again."""
    iv = _hr_interview(db, interview_id, user)
    db.delete(iv)
    db.commit()
    return Response(status_code=204)


@hr_router.post("/interviews/{interview_id}/reevaluate", response_model=InterviewHROut)
def reevaluate(
    interview_id: int,
    background: BackgroundTasks,
    user: User = Depends(require_hr),
    db: Session = Depends(get_db),
):
    iv = _hr_interview(db, interview_id, user)
    if iv.status != "completed":
        raise HTTPException(status_code=409, detail="The interview is not finished yet.")
    if iv.eval_status == "running":
        raise HTTPException(status_code=409, detail="The evaluation is already running.")
    iv.eval_status = "pending"
    iv.eval_error = None
    db.commit()
    background.add_task(run_evaluation, iv.id)
    db.refresh(iv)
    return _hr_out(iv)


@hr_router.get("/interviews/{interview_id}/transcript.txt")
def hr_transcript(interview_id: int, user: User = Depends(require_hr), db: Session = Depends(get_db)):
    iv = _hr_interview(db, interview_id, user)
    if not iv.turns:
        raise HTTPException(status_code=404, detail="There is no transcript yet.")
    name = iv.application.candidate.full_name
    return Response(
        _transcript_text(iv, f"Candidate ({name})"),
        media_type="text/plain; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="interview-transcript.txt"'},
    )
