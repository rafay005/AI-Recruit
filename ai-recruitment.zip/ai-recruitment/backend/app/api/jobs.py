from datetime import date, datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Query, Response
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, require_hr
from app.db.session import get_db
from app.models.application import Application
from app.models.job import JOB_STATUSES, Job
from app.models.user import User
from app.schemas.job import (
    GenerateJDRequest,
    JDUpdate,
    JobListItem,
    JobOut,
    JobRequirements,
    PublicJobOut,
)
from app.services.jd_generator import LLMError, generate_jd

# ---------------------------- HR (owner-only) ----------------------------
router = APIRouter(prefix="/api/hr/jobs", tags=["hr-jobs"])


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _get_owned(db: Session, job_id: int, user: User) -> Job:
    job = db.scalar(select(Job).where(Job.id == job_id, Job.owner_id == user.id))
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


def _require_editable(job: Job) -> None:
    if job.status == "published":
        raise HTTPException(
            status_code=409,
            detail="This job is published. Unpublish it before making changes.",
        )


def _reset_approval(job: Job) -> None:
    """Any content change invalidates a previous approval."""
    job.status = "draft"
    job.approved_at = None


@router.post("", response_model=JobOut, status_code=201)
def create_job(
    data: JobRequirements,
    user: User = Depends(require_hr),
    db: Session = Depends(get_db),
):
    job = Job(owner_id=user.id, status="draft", **data.model_dump())
    # Pre-fill the company blurb is left to HR; nothing else is auto-filled.
    db.add(job)
    db.commit()
    db.refresh(job)
    return job


@router.get("", response_model=list[JobListItem])
def list_jobs(
    status: str | None = Query(default=None),
    user: User = Depends(require_hr),
    db: Session = Depends(get_db),
):
    q = select(Job).where(Job.owner_id == user.id)
    if status:
        if status not in JOB_STATUSES:
            raise HTTPException(status_code=400, detail="Unknown status filter")
        q = q.where(Job.status == status)
    jobs = list(db.scalars(q.order_by(Job.updated_at.desc(), Job.id.desc())))
    counts = dict(
        db.execute(
            select(Application.job_id, func.count(Application.id))
            .where(Application.job_id.in_([j.id for j in jobs] or [0]))
            .group_by(Application.job_id)
        ).all()
    )
    items = []
    for j in jobs:
        item = JobListItem.model_validate(j)
        item.applicant_count = counts.get(j.id, 0)
        items.append(item)
    return items


@router.get("/{job_id}", response_model=JobOut)
def get_job(
    job_id: int, user: User = Depends(require_hr), db: Session = Depends(get_db)
):
    return _get_owned(db, job_id, user)


@router.put("/{job_id}", response_model=JobOut)
def update_requirements(
    job_id: int,
    data: JobRequirements,
    user: User = Depends(require_hr),
    db: Session = Depends(get_db),
):
    job = _get_owned(db, job_id, user)
    _require_editable(job)
    for field, value in data.model_dump().items():
        setattr(job, field, value)
    if job.status == "approved":
        _reset_approval(job)
    db.commit()
    db.refresh(job)
    return job


@router.delete("/{job_id}", status_code=204)
def delete_job(
    job_id: int, user: User = Depends(require_hr), db: Session = Depends(get_db)
):
    job = _get_owned(db, job_id, user)
    _require_editable(job)
    if db.scalar(select(func.count(Application.id)).where(Application.job_id == job.id)):
        raise HTTPException(
            status_code=409,
            detail="This job has applications, so it cannot be deleted. Unpublish it instead.",
        )
    db.delete(job)
    db.commit()
    return Response(status_code=204)


@router.post("/{job_id}/generate-jd", response_model=JobOut)
def generate_job_description(
    job_id: int,
    body: GenerateJDRequest | None = None,
    user: User = Depends(require_hr),
    db: Session = Depends(get_db),
):
    job = _get_owned(db, job_id, user)
    _require_editable(job)
    instructions = body.instructions if body else None
    try:
        text, source, model = generate_jd(job, user.company, instructions)
    except LLMError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    job.jd_text = text
    job.jd_source = source
    job.jd_model = model
    job.jd_edited = False
    _reset_approval(job)
    db.commit()
    db.refresh(job)
    return job


@router.put("/{job_id}/jd", response_model=JobOut)
def save_job_description(
    job_id: int,
    body: JDUpdate,
    user: User = Depends(require_hr),
    db: Session = Depends(get_db),
):
    job = _get_owned(db, job_id, user)
    _require_editable(job)
    new_text = body.jd_text.strip()
    if new_text != (job.jd_text or "").strip():
        if job.jd_source in ("ai", "template"):
            job.jd_edited = True
        else:
            job.jd_source = "manual"
        job.jd_text = new_text
        _reset_approval(job)
    db.commit()
    db.refresh(job)
    return job


@router.post("/{job_id}/approve", response_model=JobOut)
def approve_job_description(
    job_id: int, user: User = Depends(require_hr), db: Session = Depends(get_db)
):
    job = _get_owned(db, job_id, user)
    _require_editable(job)
    if not job.jd_text or not job.jd_text.strip():
        raise HTTPException(status_code=400, detail="Generate or write a JD before approving")
    job.status = "approved"
    job.approved_at = _now()
    db.commit()
    db.refresh(job)
    return job


@router.post("/{job_id}/publish", response_model=JobOut)
def publish_job(
    job_id: int, user: User = Depends(require_hr), db: Session = Depends(get_db)
):
    job = _get_owned(db, job_id, user)
    if job.status == "published":
        raise HTTPException(status_code=409, detail="Job is already published")
    if job.status != "approved":
        raise HTTPException(status_code=400, detail="Approve the JD before publishing")
    if job.application_deadline and job.application_deadline < date.today():
        raise HTTPException(
            status_code=400,
            detail="The application deadline has passed. Update the requirements first.",
        )
    job.status = "published"
    job.published_at = _now()
    db.commit()
    db.refresh(job)
    return job


@router.post("/{job_id}/unpublish", response_model=JobOut)
def unpublish_job(
    job_id: int, user: User = Depends(require_hr), db: Session = Depends(get_db)
):
    job = _get_owned(db, job_id, user)
    if job.status != "published":
        raise HTTPException(status_code=400, detail="Job is not published")
    job.status = "approved"
    job.published_at = None
    db.commit()
    db.refresh(job)
    return job


# ---------------------------- Candidates (read-only) ----------------------------
public_router = APIRouter(prefix="/api/jobs", tags=["jobs"])


def _to_public(job: Job) -> PublicJobOut:
    return PublicJobOut(
        id=job.id,
        title=job.title,
        company=job.owner.company if job.owner else None,
        department=job.department,
        location=job.location,
        employment_type=job.employment_type,
        work_mode=job.work_mode,
        experience_level=job.experience_level,
        openings=job.openings,
        application_deadline=job.application_deadline,
        required_skills=job.required_skills,
        nice_to_have_skills=job.nice_to_have_skills,
        salary_min=job.salary_min if job.show_salary else None,
        salary_max=job.salary_max if job.show_salary else None,
        salary_currency=job.salary_currency if job.show_salary else None,
        jd_text=job.jd_text,
        published_at=job.published_at,
    )


def _open_jobs_query():
    return select(Job).where(
        Job.status == "published",
        or_(Job.application_deadline.is_(None), Job.application_deadline >= date.today()),
    )


@public_router.get("", response_model=list[PublicJobOut])
def list_open_jobs(
    _: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    jobs = db.scalars(_open_jobs_query().order_by(Job.published_at.desc()))
    return [_to_public(j) for j in jobs]


@public_router.get("/{job_id}", response_model=PublicJobOut)
def get_open_job(
    job_id: int, _: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    job = db.scalar(_open_jobs_query().where(Job.id == job_id))
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return _to_public(job)
