"""Hiring automation settings per job, and the HR insights dashboard."""
from collections import Counter
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import require_hr
from app.db.session import get_db
from app.models.application import Application
from app.models.automation import AutomationEvent
from app.models.job import Job
from app.models.user import User
from app.services import notify
from app.services.automation import run_job, selected_count
from app.services.job_profile import profile_for
from app.services.matching import canon, match_application

router = APIRouter(prefix="/api/hr", tags=["automation"])


class AutomationIn(BaseModel):
    enabled: bool
    cv_threshold: int = Field(ge=0, le=100)
    interview_threshold: int = Field(ge=0, le=100)
    reject_below_cv: bool = True
    questions: int = Field(default=5, ge=3, le=8)


def _owned_job(db: Session, job_id: int, user: User) -> Job:
    job = db.scalar(select(Job).where(Job.id == job_id, Job.owner_id == user.id))
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


def _event_out(e: AutomationEvent, names: dict[int, str]) -> dict:
    return {
        "id": e.id, "action": e.action, "score": e.score, "threshold": e.threshold, "detail": e.detail,
        "application_id": e.application_id, "candidate_name": names.get(e.application_id or -1),
        "created_at": e.created_at,
    }


def _candidate_name(a: Application) -> str:
    ex = a.extracted if isinstance(a.extracted, dict) else {}
    return ex.get("name") or a.candidate.full_name


def _automation_out(db: Session, job: Job, last_run: dict | None = None) -> dict:
    profile = profile_for(job)
    apps = list(db.scalars(select(Application).where(Application.job_id == job.id)
                           .order_by(Application.created_at.asc())))
    scores = []
    for a in apps:
        if a.analysis_status == "done":
            m = match_application(job, a.extracted, a.parsed_text, profile)
            if m:
                scores.append(m.overall)
    iv_scores = [int(a.interview.evaluation["overall"]) for a in apps
                 if a.interview and a.interview.eval_status == "done" and isinstance(a.interview.evaluation, dict)
                 and a.interview.evaluation.get("overall") is not None]
    names = {a.id: _candidate_name(a) for a in apps}
    events = list(db.scalars(select(AutomationEvent).where(AutomationEvent.job_id == job.id)
                             .order_by(AutomationEvent.created_at.desc(), AutomationEvent.id.desc()).limit(30)))
    return {
        "job_id": job.id,
        "enabled": job.auto_enabled,
        "cv_threshold": job.auto_cv_threshold,
        "interview_threshold": job.auto_interview_threshold,
        "reject_below_cv": job.auto_reject_below_cv,
        "questions": job.auto_questions,
        "openings": job.openings,
        "selected": selected_count(db, job),
        "email_enabled": notify.email_enabled(),
        "cv_scores": scores,  # every analysed CV's current match, for the threshold preview
        "interview_scores": iv_scores,
        "pending_review": sum(1 for a in apps if a.decision == "under_review"),
        "events": [_event_out(e, names) for e in events],
        "last_run": last_run,
    }


@router.get("/jobs/{job_id}/automation")
def get_automation(job_id: int, user: User = Depends(require_hr), db: Session = Depends(get_db)):
    return _automation_out(db, _owned_job(db, job_id, user))


@router.put("/jobs/{job_id}/automation")
def save_automation(job_id: int, body: AutomationIn, user: User = Depends(require_hr), db: Session = Depends(get_db)):
    job = _owned_job(db, job_id, user)
    job.auto_enabled = body.enabled
    job.auto_cv_threshold = body.cv_threshold
    job.auto_interview_threshold = body.interview_threshold
    job.auto_reject_below_cv = body.reject_below_cv
    job.auto_questions = body.questions
    db.commit()
    summary = run_job(db, job) if job.auto_enabled else None  # apply to everyone already waiting
    return _automation_out(db, job, summary)


@router.post("/jobs/{job_id}/automation/run")
def run_automation(job_id: int, user: User = Depends(require_hr), db: Session = Depends(get_db)):
    job = _owned_job(db, job_id, user)
    if not job.auto_enabled:
        raise HTTPException(status_code=409, detail="Turn automation on for this job first.")
    return _automation_out(db, job, run_job(db, job))


# ============================ insights dashboard ============================

_ACTION_TEXT = {
    "invited": "invited to interview automatically",
    "cv_rejected": "rejected automatically at CV stage",
    "cv_held": "held for review (below CV threshold)",
    "selected": "selected automatically",
    "interview_rejected": "rejected after interview",
    "openings_full": "passed, but openings were full",
    "manual_move": "moved on the pipeline board",
}


def _hist(values: list[int]) -> list[dict]:
    buckets = [0] * 10
    for v in values:
        buckets[min(9, max(0, int(v) // 10))] += 1
    return [{"from": i * 10, "to": i * 10 + 9 if i < 9 else 100, "count": c} for i, c in enumerate(buckets)]


def _aware(dt):
    return dt.replace(tzinfo=timezone.utc) if dt is not None and dt.tzinfo is None else dt


@router.get("/dashboard/insights")
def insights(user: User = Depends(require_hr), db: Session = Depends(get_db)):
    now = datetime.now(timezone.utc)
    jobs = list(db.scalars(select(Job).where(Job.owner_id == user.id).order_by(Job.created_at.desc())))
    job_ids = [j.id for j in jobs]
    apps = list(db.scalars(select(Application).where(Application.job_id.in_(job_ids)))) if job_ids else []
    events = list(db.scalars(select(AutomationEvent).where(AutomationEvent.job_id.in_(job_ids))
                             .order_by(AutomationEvent.created_at.desc()).limit(200))) if job_ids else []

    # Current match for every analysed CV (cached search makes this cheap).
    profiles = {j.id: profile_for(j) for j in jobs}
    match: dict[int, int] = {}
    breakdown = {}
    for a in apps:
        if a.analysis_status == "done":
            m = match_application(a.job, a.extracted, a.parsed_text, profiles[a.job_id])
            if m:
                match[a.id] = m.overall
                breakdown[a.id] = m

    def iv_score(a: Application) -> int | None:
        iv = a.interview
        if iv and iv.eval_status == "done" and isinstance(iv.evaluation, dict) and iv.evaluation.get("overall") is not None:
            return int(iv.evaluation["overall"])
        return None

    iv_scores = {a.id: s for a in apps if (s := iv_score(a)) is not None}
    decisions = Counter(a.decision or "under_review" for a in apps)
    decided = [a for a in apps if a.decision not in (None, "under_review")]
    auto_decided = [a for a in decided if a.decision_source == "auto"]
    days_to_decision = [
        (_aware(a.decision_at) - _aware(a.created_at)).total_seconds() / 86400
        for a in decided if a.decision_at and a.created_at
    ]

    week, prev = now - timedelta(days=7), now - timedelta(days=14)
    apps_7 = sum(1 for a in apps if _aware(a.created_at) >= week)
    apps_prev = sum(1 for a in apps if prev <= _aware(a.created_at) < week)

    # 30-day timeline
    start = (now - timedelta(days=29)).date()
    days = [start + timedelta(days=i) for i in range(30)]
    per_day = Counter(_aware(a.created_at).date() for a in apps)
    dec_day = Counter(_aware(a.decision_at).date() for a in decided if a.decision_at)
    timeline = [{"date": d.isoformat(), "applications": per_day.get(d, 0), "decisions": dec_day.get(d, 0)} for d in days]

    interviewed = [a for a in apps if a.interview and a.interview.status == "completed"]
    invited = [a for a in apps if a.interview is not None]
    funnel = [
        {"stage": "Applied", "count": len(apps)},
        {"stage": "CV analysed", "count": sum(1 for a in apps if a.analysis_status == "done")},
        {"stage": "Invited to interview", "count": len(invited)},
        {"stage": "Interviewed", "count": len(interviewed)},
        {"stage": "Selected", "count": decisions.get("hired", 0)},
    ]

    # Per job
    job_rows = []
    for j in jobs:
        ja = [a for a in apps if a.job_id == j.id]
        ms = [match[a.id] for a in ja if a.id in match]
        best = max(ja, key=lambda a: match.get(a.id, -1), default=None)
        job_rows.append({
            "id": j.id, "title": j.title, "status": j.status, "role_family": profiles[j.id].get("role_family_label"),
            "applicants": len(ja), "avg_match": round(sum(ms) / len(ms)) if ms else None,
            "best_match": match.get(best.id) if best and best.id in match else None,
            "best_candidate": _candidate_name(best) if best and best.id in match else None,
            "interviews_done": sum(1 for a in ja if a.interview and a.interview.status == "completed"),
            "selected": sum(1 for a in ja if a.decision == "hired"), "openings": j.openings,
            "auto_enabled": j.auto_enabled, "cv_threshold": j.auto_cv_threshold,
            "interview_threshold": j.auto_interview_threshold,
        })

    # Top candidates: combine CV match and interview score when there is one.
    def combined(a):
        cv, iv = match.get(a.id), iv_scores.get(a.id)
        return (cv if iv is None else round(0.5 * cv + 0.5 * iv)) if cv is not None else -1

    top = sorted([a for a in apps if a.id in match], key=lambda a: (-combined(a), a.created_at))[:6]
    top_out = [{
        "application_id": a.id, "name": _candidate_name(a), "job_title": a.job.title,
        "match": match[a.id], "interview": iv_scores.get(a.id), "combined": combined(a),
        "decision": a.decision or "under_review", "decision_source": a.decision_source,
    } for a in top]

    # Skill demand (how many jobs need it) vs supply (share of their applicants who show it).
    demand: Counter = Counter()
    have: Counter = Counter()
    seen_for: Counter = Counter()
    label: dict[str, str] = {}
    for j in jobs:
        for s in j.required_skills or []:
            k = canon(s)
            demand[k] += 1
            label.setdefault(k, s)
    for a in apps:
        m = breakdown.get(a.id)
        if not m:
            continue
        for it in m.required.items:
            k = canon(it.skill)
            seen_for[k] += 1
            if it.status == "match":
                have[k] += 1
    skills = sorted(demand, key=lambda k: (-demand[k], -seen_for[k]))[:8]
    skills_out = [{"skill": label[k], "jobs": demand[k], "applicants": seen_for[k],
                   "coverage": round(100 * have[k] / seen_for[k]) if seen_for[k] else None} for k in skills]

    # Activity feed
    names = {a.id: _candidate_name(a) for a in apps}
    titles = {j.id: j.title for j in jobs}
    activity = [{
        "at": e.created_at, "kind": e.action, "auto": e.action != "manual_move",
        "text": f"{names.get(e.application_id, 'A candidate')} {_ACTION_TEXT.get(e.action, e.action)}",
        "detail": e.detail, "job_title": titles.get(e.job_id),
    } for e in events[:60]]
    for a in apps:
        activity.append({"at": a.created_at, "kind": "applied", "auto": False,
                         "text": f"{names[a.id]} applied", "detail": None, "job_title": a.job.title})
        if a.interview and a.interview.completed_at:
            activity.append({"at": a.interview.completed_at, "kind": "interviewed", "auto": False,
                             "text": f"{names[a.id]} finished the interview", "detail": None, "job_title": a.job.title})
    activity.sort(key=lambda x: _aware(x["at"]), reverse=True)

    ms_all = list(match.values())
    iv_all = list(iv_scores.values())
    return {
        "hr_name": user.full_name,
        "company": user.company,
        "kpis": {
            "open_jobs": sum(1 for j in jobs if j.status == "published"),
            "draft_jobs": sum(1 for j in jobs if j.status != "published"),
            "total_applicants": len(apps),
            "applicants_7d": apps_7,
            "applicants_prev_7d": apps_prev,
            "avg_match": round(sum(ms_all) / len(ms_all)) if ms_all else None,
            "interviews_completed": len(interviewed),
            "interviews_pending": sum(1 for a in invited if a.interview.status != "completed"),
            "avg_interview": round(sum(iv_all) / len(iv_all)) if iv_all else None,
            "selected": decisions.get("hired", 0),
            "rejected": decisions.get("rejected", 0),
            "openings": sum(j.openings for j in jobs if j.status == "published"),
            "automated_decisions": len(auto_decided),
            "automation_rate": round(100 * len(auto_decided) / len(decided)) if decided else None,
            "avg_days_to_decision": round(sum(days_to_decision) / len(days_to_decision), 1) if days_to_decision else None,
            "jobs_automated": sum(1 for j in jobs if j.auto_enabled),
        },
        "funnel": funnel,
        "timeline": timeline,
        "match_histogram": _hist(ms_all),
        "interview_histogram": _hist(iv_all),
        "decisions": {k: decisions.get(k, 0) for k in ("under_review", "shortlisted", "interview", "hired", "rejected")},
        "jobs": job_rows,
        "top_candidates": top_out,
        "skills": skills_out,
        "activity": activity[:80],
    }
