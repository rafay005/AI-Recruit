"""Job-description generator.

Providers (chosen by LLM_PROVIDER in .env):
  anthropic -> Claude via the Anthropic Messages API
  openai    -> OpenAI Chat Completions API
  template  -> built-in fill-in-the-blanks generator (no AI, no key needed)
  auto      -> anthropic if ANTHROPIC_API_KEY is set, else openai if
               OPENAI_API_KEY is set, else template
"""
import re

import httpx

from app.core.config import settings
from app.models.job import Job

DEFAULT_MODELS = {
    "anthropic": "claude-sonnet-5-5",
    "openai": "gpt-4o-mini",
}

LABELS = {
    "full_time": "Full-time",
    "part_time": "Part-time",
    "contract": "Contract",
    "internship": "Internship",
    "onsite": "On-site",
    "remote": "Remote",
    "hybrid": "Hybrid",
    "entry": "Entry level",
    "mid": "Mid level",
    "senior": "Senior level",
    "lead": "Lead / Principal level",
}

SYSTEM_PROMPT = """You are an expert technical recruiter and HR copywriter.
Write a clear, accurate, inclusive job description in Markdown from the details you are given.

Rules:
- Use ONLY the facts provided. Never invent benefits, perks, salary, team size, tech stack, \
company facts, or locations that were not given. If something is not provided, leave that section out.
- Do not use gendered, age-related, or otherwise discriminatory wording. Avoid cliches like \
"rockstar" or "ninja".
- Be specific and concise. Prefer short bullet points. Do not pad.
- Structure, in this order (skip a section if there is nothing real to put in it):
  1. "# <Job title>" as the first line
  2. A one-line summary in bold: company, location, employment type, work mode (only what is known)
  3. "## About the Company" (only if company information was provided)
  4. "## Role Overview"
  5. "## Key Responsibilities"
  6. "## Required Qualifications" (experience, education, and the required skills)
  7. "## Nice to Have" (only if nice-to-have skills were given)
  8. "## Compensation" (only if HR chose to show salary)
  9. "## Application Details" (openings and deadline, only if given)
- Turn the HR's rough responsibility notes into clean bullet points; do not add unrelated duties.
- Output ONLY the Markdown job description, with no preface, no explanation, and no code fences."""


class LLMError(Exception):
    """Raised when the AI provider cannot produce a job description."""


# ----------------------------- helpers -----------------------------


def resolve_provider() -> str:
    p = (settings.LLM_PROVIDER or "auto").strip().lower()
    if p == "auto":
        if settings.ANTHROPIC_API_KEY:
            return "anthropic"
        if settings.OPENAI_API_KEY:
            return "openai"
        return "template"
    if p not in ("anthropic", "openai", "template"):
        raise LLMError(
            f"Unknown LLM_PROVIDER '{settings.LLM_PROVIDER}'. "
            "Use auto, anthropic, openai or template."
        )
    return p


def _money(job: Job) -> str | None:
    if not job.show_salary:
        return None
    cur = job.salary_currency or ""
    lo, hi = job.salary_min, job.salary_max
    if lo is not None and hi is not None:
        return f"{cur} {lo:,} - {hi:,}".strip()
    if lo is not None:
        return f"From {cur} {lo:,}".strip()
    if hi is not None:
        return f"Up to {cur} {hi:,}".strip()
    return None


def _experience(job: Job) -> str | None:
    lo, hi = job.min_experience_years, job.max_experience_years
    if lo is not None and hi is not None:
        return f"{lo}-{hi} years of relevant experience"
    if lo is not None:
        return f"{lo}+ years of relevant experience"
    if hi is not None:
        return f"Up to {hi} years of experience"
    return None


def build_user_prompt(job: Job, company_name: str | None, instructions: str | None) -> str:
    lines = [f"Job title: {job.title}"]
    if company_name:
        lines.append(f"Company: {company_name}")
    if job.company_about:
        lines.append(f"About the company: {job.company_about}")
    if job.department:
        lines.append(f"Department: {job.department}")
    if job.location:
        lines.append(f"Location: {job.location}")
    lines.append(f"Employment type: {LABELS.get(job.employment_type, job.employment_type)}")
    lines.append(f"Work mode: {LABELS.get(job.work_mode, job.work_mode)}")
    lines.append(f"Seniority: {LABELS.get(job.experience_level, job.experience_level)}")
    exp = _experience(job)
    if exp:
        lines.append(f"Experience: {exp}")
    if job.education:
        lines.append(f"Education: {job.education}")
    lines.append("Required skills: " + ", ".join(job.required_skills))
    if job.nice_to_have_skills:
        lines.append("Nice-to-have skills: " + ", ".join(job.nice_to_have_skills))
    if job.responsibilities:
        lines.append(f"HR's rough notes on responsibilities:\n{job.responsibilities}")
    money = _money(job)
    if money:
        lines.append(f"Salary range to show publicly: {money}")
    else:
        lines.append("Salary: do NOT mention salary.")
    lines.append(f"Number of openings: {job.openings}")
    if job.application_deadline:
        lines.append(f"Application deadline: {job.application_deadline.isoformat()}")
    if instructions:
        lines.append(f"Extra instructions from HR (style and emphasis only): {instructions}")
    return "\n".join(lines)


def _strip_fences(text: str) -> str:
    text = text.strip()
    m = re.match(r"^```(?:markdown|md)?\s*\n(.*?)\n```$", text, re.DOTALL)
    return m.group(1).strip() if m else text


def _http_error(provider: str, resp: httpx.Response) -> LLMError:
    code = resp.status_code
    if code in (401, 403):
        return LLMError(f"{provider} rejected the API key (HTTP {code}). Check your key in .env.")
    if code == 404:
        return LLMError(
            f"{provider} says the model was not found (HTTP 404). "
            "Set LLM_MODEL in .env to a model your account can use."
        )
    if code == 429:
        return LLMError(f"{provider} rate limit or quota reached (HTTP 429). Try again shortly.")
    return LLMError(f"{provider} returned an error (HTTP {code}).")


# ----------------------------- providers -----------------------------


def _call_anthropic(prompt: str, model: str) -> str:
    if not settings.ANTHROPIC_API_KEY:
        raise LLMError("ANTHROPIC_API_KEY is not set in .env")
    try:
        resp = httpx.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": settings.ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": model,
                "max_tokens": 2000,
                "system": SYSTEM_PROMPT,
                "messages": [{"role": "user", "content": prompt}],
            },
            timeout=90,
        )
    except httpx.HTTPError as exc:
        raise LLMError(f"Could not reach Anthropic: {type(exc).__name__}") from exc
    if resp.status_code != 200:
        raise _http_error("Anthropic", resp)
    blocks = resp.json().get("content", [])
    return "".join(b.get("text", "") for b in blocks if b.get("type") == "text")


def _call_openai(prompt: str, model: str) -> str:
    if not settings.OPENAI_API_KEY:
        raise LLMError("OPENAI_API_KEY is not set in .env")
    try:
        resp = httpx.post(
            "https://api.openai.com/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {settings.OPENAI_API_KEY}",
                "content-type": "application/json",
            },
            json={
                "model": model,
                "messages": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": prompt},
                ],
            },
            timeout=90,
        )
    except httpx.HTTPError as exc:
        raise LLMError(f"Could not reach OpenAI: {type(exc).__name__}") from exc
    if resp.status_code != 200:
        raise _http_error("OpenAI", resp)
    choices = resp.json().get("choices", [])
    return choices[0]["message"]["content"] if choices else ""


# ----------------------------- template fallback -----------------------------


def _bullets_from_notes(notes: str) -> list[str]:
    parts = re.split(r"[\n;]+", notes)
    out = []
    for p in parts:
        p = re.sub(r"^\s*[-*\u2022\d.)]+\s*", "", p).strip()
        if p:
            out.append(p[0].upper() + p[1:])
    return out


def _article(title: str) -> str:
    first = title.strip().split(" ")[0] if title.strip() else ""
    if not first:
        return "a"
    # Acronyms are read letter by letter: "an HR", "an ML", "an SQL", but "a QA", "a UI".
    if first.isupper() and 2 <= len(first) <= 4:
        return "an" if first[0] in "AEFHILMNORSX" else "a"
    return "an" if first[0].lower() in "aeiou" else "a"


def render_template(job: Job, company_name: str | None) -> str:
    meta = [
        x
        for x in (
            company_name,
            job.location,
            LABELS.get(job.employment_type),
            LABELS.get(job.work_mode),
        )
        if x
    ]
    md: list[str] = [f"# {job.title}", ""]
    if meta:
        md += [f"**{' | '.join(meta)}**", ""]
    if job.company_about:
        md += ["## About the Company", job.company_about, ""]

    dept = f" in the {job.department} team" if job.department else ""
    md += [
        "## Role Overview",
        f"We are looking for {_article(job.title)} {job.title}{dept} to join us.",
        "",
        "## Key Responsibilities",
    ]
    if job.responsibilities:
        md += [f"- {b}" for b in _bullets_from_notes(job.responsibilities)]
    else:
        md += ["- _Add the key responsibilities for this role here._"]
    md += ["", "## Required Qualifications"]
    exp = _experience(job)
    if exp:
        md.append(f"- {exp}")
    if job.education:
        md.append(f"- {job.education}")
    md += [f"- {s}" for s in job.required_skills]

    if job.nice_to_have_skills:
        md += ["", "## Nice to Have"] + [f"- {s}" for s in job.nice_to_have_skills]

    money = _money(job)
    if money:
        md += ["", "## Compensation", money]

    details = []
    if job.openings > 1:
        details.append(f"- Openings: {job.openings}")
    if job.application_deadline:
        details.append(f"- Apply by: {job.application_deadline.isoformat()}")
    if details:
        md += ["", "## Application Details"] + details
    return "\n".join(md).strip() + "\n"


# ----------------------------- public API -----------------------------


def generate_jd(
    job: Job, company_name: str | None, instructions: str | None
) -> tuple[str, str, str]:
    """Returns (markdown_text, source, model_label). source is 'ai' or 'template'."""
    provider = resolve_provider()
    if provider == "template":
        return render_template(job, company_name), "template", "template"

    model = settings.LLM_MODEL.strip() or DEFAULT_MODELS[provider]
    prompt = build_user_prompt(job, company_name, instructions)
    raw = _call_anthropic(prompt, model) if provider == "anthropic" else _call_openai(prompt, model)
    text = _strip_fences(raw)
    if len(text) < 80:
        raise LLMError("The AI returned an empty or too-short job description. Try again.")
    return text, "ai", f"{provider}:{model}"
