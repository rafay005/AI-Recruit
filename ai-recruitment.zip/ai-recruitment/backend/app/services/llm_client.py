"""Tiny shared client for the AI provider (text and image input)."""
import base64

import httpx

from app.core.config import settings
from app.services.jd_generator import DEFAULT_MODELS, LLMError, _http_error, resolve_provider


def llm_available() -> bool:
    try:
        provider = resolve_provider()
    except LLMError:
        return False
    if provider == "anthropic":
        return bool(settings.ANTHROPIC_API_KEY)
    if provider == "openai":
        return bool(settings.OPENAI_API_KEY)
    return False


def current_model_label() -> str:
    provider = resolve_provider()
    model = settings.LLM_MODEL.strip() or DEFAULT_MODELS.get(provider, "")
    return f"{provider}:{model}"


def chat(
    system: str,
    user: str,
    *,
    images: list[bytes] | None = None,
    max_tokens: int = 3000,
) -> str:
    """Send one request. `images` are PNG bytes. Returns the model's text."""
    provider = resolve_provider()
    if provider == "template":
        raise LLMError("No AI provider is configured.")
    model = settings.LLM_MODEL.strip() or DEFAULT_MODELS[provider]
    encoded = [base64.b64encode(b).decode() for b in (images or [])]

    if provider == "anthropic":
        if not settings.ANTHROPIC_API_KEY:
            raise LLMError("ANTHROPIC_API_KEY is not set in .env")
        content: list[dict] | str = user
        if encoded:
            content = [
                {
                    "type": "image",
                    "source": {"type": "base64", "media_type": "image/png", "data": e},
                }
                for e in encoded
            ] + [{"type": "text", "text": user}]
        try:
            resp = httpx.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": settings.ANTHROPIC_API_KEY,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": model,
                    "max_tokens": max_tokens,
                    "system": system,
                    "messages": [{"role": "user", "content": content}],
                },
                timeout=120,
            )
        except httpx.HTTPError as exc:
            raise LLMError(f"Could not reach Anthropic: {type(exc).__name__}") from exc
        if resp.status_code != 200:
            raise _http_error("Anthropic", resp)
        blocks = resp.json().get("content", [])
        return "".join(b.get("text", "") for b in blocks if b.get("type") == "text")

    # openai
    if not settings.OPENAI_API_KEY:
        raise LLMError("OPENAI_API_KEY is not set in .env")
    user_content: list[dict] | str = user
    if encoded:
        user_content = [{"type": "text", "text": user}] + [
            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{e}"}}
            for e in encoded
        ]
    try:
        resp = httpx.post(
            "https://api.openai.com/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {settings.OPENAI_API_KEY}",
                "content-type": "application/json",
            },
            json={
                "model": model,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user_content},
                ],
            },
            timeout=120,
        )
    except httpx.HTTPError as exc:
        raise LLMError(f"Could not reach OpenAI: {type(exc).__name__}") from exc
    if resp.status_code != 200:
        raise _http_error("OpenAI", resp)
    choices = resp.json().get("choices", [])
    return choices[0]["message"]["content"] if choices else ""
