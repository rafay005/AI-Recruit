"""Safe storage for uploaded CV files (kept outside any public web folder)."""
import re
import uuid
import zipfile
from pathlib import Path

from fastapi import HTTPException, UploadFile

from app.core.config import settings

BACKEND_DIR = Path(__file__).resolve().parents[2]

ALLOWED_TYPES = {
    ".pdf": "application/pdf",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
}
_STORED_RE = re.compile(r"^[0-9a-f]{32}\.(pdf|docx)$")
MAX_UNZIPPED_BYTES = 40 * 1024 * 1024


def cv_dir() -> Path:
    base = Path(settings.UPLOAD_DIR)
    if not base.is_absolute():
        base = BACKEND_DIR / base
    d = base / "cvs"
    d.mkdir(parents=True, exist_ok=True)
    return d


def cv_file_path(stored_name: str) -> Path:
    if not _STORED_RE.match(stored_name):
        raise ValueError("Invalid stored file name")
    return cv_dir() / stored_name


def delete_cv(stored_name: str) -> None:
    try:
        cv_file_path(stored_name).unlink(missing_ok=True)
    except (ValueError, OSError):
        pass


def clean_display_name(name: str | None) -> str:
    name = Path(name or "cv").name
    name = re.sub(r"[\x00-\x1f<>:\"/\\|?*]", "", name).strip() or "cv"
    stem, dot, ext = name.rpartition(".")
    if not dot:
        return name[:120]
    return f"{stem[:110]}.{ext[:8]}"


def _looks_like_pdf(head: bytes) -> bool:
    return head[:1024].lstrip().startswith(b"%PDF")


def _looks_like_docx(path: Path) -> bool:
    try:
        if not zipfile.is_zipfile(path):
            return False
        with zipfile.ZipFile(path) as z:
            names = set(z.namelist())
            if "word/document.xml" not in names:
                return False
            return sum(i.file_size for i in z.infolist()) <= MAX_UNZIPPED_BYTES
    except (zipfile.BadZipFile, OSError):
        return False


def save_cv(upload: UploadFile) -> tuple[str, str, str, int]:
    """Validate and store an uploaded CV.

    Returns (stored_name, display_name, content_type, size_bytes).
    Raises HTTPException with a clear message if the file is not acceptable.
    """
    display = clean_display_name(upload.filename)
    ext = Path(display).suffix.lower()
    if ext not in ALLOWED_TYPES:
        raise HTTPException(
            status_code=400,
            detail="Please upload your CV as a PDF or DOCX file.",
        )

    limit = settings.MAX_CV_MB * 1024 * 1024
    stored = f"{uuid.uuid4().hex}{ext}"
    path = cv_dir() / stored
    size = 0
    head = b""
    try:
        with open(path, "wb") as out:
            while True:
                chunk = upload.file.read(1024 * 256)
                if not chunk:
                    break
                if not head:
                    head = chunk[:1024]
                size += len(chunk)
                if size > limit:
                    raise HTTPException(
                        status_code=413,
                        detail=f"The file is too large. The maximum size is {settings.MAX_CV_MB} MB.",
                    )
                out.write(chunk)

        if size == 0:
            raise HTTPException(status_code=400, detail="The uploaded file is empty.")

        ok = _looks_like_pdf(head) if ext == ".pdf" else _looks_like_docx(path)
        if not ok:
            raise HTTPException(
                status_code=400,
                detail=f"This file is not a valid {ext[1:].upper()} document.",
            )
    except Exception:
        path.unlink(missing_ok=True)
        raise

    return stored, display, ALLOWED_TYPES[ext], size
