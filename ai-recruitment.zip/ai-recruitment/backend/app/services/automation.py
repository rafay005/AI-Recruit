"""Hands-free hiring: CV threshold -> interview, interview threshold -> selected or rejected.

Per job, when HR switches automation on:

  CV stage         runs when a CV finishes analysis (and on "Run now" for the backlog)
                   match >= CV threshold  -> decision "interview", interview created, candidate invited
                   match <  CV threshold  -> rejected (or left under review if HR turned that off)

  Interview stage  runs when an interview evaluation finishes
                   score >= interview threshold and an opening is free -> "hired" (shown as Selected)
                   score >= threshold but every opening is taken        -> rejected, "positions filled"
                   score <  threshold                                   -> rejected

First come, first served: the backlog is processed in the order people applied, and
openings are given to qualifying candidates in that order. The job row is locked while
a seat is given out, so two interviews finishing at once cannot both take the last one.

Automation only touches candidates still in the stage it owns: it never overrides a
decision HR made by hand. Every action is written to automation_events with the score
and the threshold, so HR can see exactly why it happened.
"""
import logging
from datetime import datetime, timezone

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.application import Application
from app.models.automation import AutomationEvent
from app.models.interview import Interview
from app.models.job import Job
from app.services import notify
from app.services.interview.plan import clamp_questions
from app.services.job_profile import ensure_profile
from app.services.matching import match_application

log = logging.getLogger("automation")

# What the candidate reads (no scores or thresholds: those stay internal).
NOTE_INVITED = "Your profile is a strong match for this role. You are invited to a short AI interview."
NOTE_CV_REJECTED = "Thank you for applying. Your profile does not match the requirements of this role closely enough at this time."
NOTE_SELECTED = "Congratulations! You have been selected. The hiring team will contact you with the next steps."
NOTE_INTERVIEW_REJECTED = "Thank you for taking the interview. We will not be moving forward with your application this time."
NOTE_FULL = "Thank you for taking the interview. All openings for this role have now been filled."


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _log(db: Session, job: Job, app: Application | None, action: str, score=None, threshold=None, detail=None):
    db.add(AutomationEvent(job_id=job.id, application_id=app.id if app else None, action=action,
                           score=score, threshold=threshold, detail=(detail or "")[:400] or None))


def _name(app: Application) -> str:
    ex = app.extracted if isinstance(app.extracted, dict) else {}
    return (ex.get("name") or app.candidate.full_name or "there").split(" ")[0]


def _decide(app: Application, decision: str, note: str) -> None:
    app.decision = decision
    app.decision_note = note
    app.decision_at = _now()
    app.decision_source = "auto"


def selected_count(db: Session, job: Job) -> int:
    return db.scalar(
        select(func.count(Application.id)).where(Application.job_id == job.id, Application.decision == "hired")
    ) or 0


# ------------------------------------------------------------------ CV stage


def process_cv(db: Session, app: Application, profile: dict | None = None) -> str | None:
    """Returns the action taken, or None when nothing applies. Caller commits."""
    job = app.job
    if not job.auto_enabled or app.analysis_status != "done" or not app.extracted:
        return None
    if app.decision != "under_review" or app.interview is not None:
        return None  # HR (or an earlier run) already moved this candidate
    m = match_application(job, app.extracted, app.parsed_text, profile)
    if m is None:
        return None
    app.match_score = m.overall
    t = job.auto_cv_threshold
    company = job.owner.company if job.owner else None

    if m.overall >= t:
        db.add(Interview(
            application_id=app.id, status="invited",
            questions_planned=clamp_questions(job.auto_questions, settings.INTERVIEW_QUESTIONS),
            followups_used=0, eval_status="pending",
        ))
        _decide(app, "interview", NOTE_INVITED)
        emailed = notify.interview_invite(_name(app), app.candidate.email, job.title, company)
        _log(db, job, app, "invited", m.overall, t,
             f"CV match {m.overall}% >= {t}%. Interview invitation {'emailed and ' if emailed else ''}shown in the candidate portal.")
        return "invited"

    if job.auto_reject_below_cv:
        _decide(app, "rejected", NOTE_CV_REJECTED)
        emailed = notify.decision(_name(app), app.candidate.email, job.title, company, selected=False)
        _log(db, job, app, "cv_rejected", m.overall, t,
             f"CV match {m.overall}% < {t}%.{' Candidate emailed.' if emailed else ''}")
        return "cv_rejected"

    already = db.scalar(select(AutomationEvent.id).where(
        AutomationEvent.application_id == app.id, AutomationEvent.action == "cv_held"))
    if not already:
        _log(db, job, app, "cv_held", m.overall, t, f"CV match {m.overall}% < {t}%. Left under review for HR.")
    return "cv_held"


# ------------------------------------------------------------------ interview stage


def _interview_score(iv: Interview) -> int | None:
    if iv.status != "completed" or iv.eval_status != "done" or not isinstance(iv.evaluation, dict):
        return None
    try:
        return int(iv.evaluation.get("overall"))
    except (TypeError, ValueError):
        return None


def process_interview(db: Session, iv: Interview) -> str | None:
    app = iv.application
    job = app.job
    if not job.auto_enabled or app.decision != "interview":
        return None
    score = _interview_score(iv)
    if score is None:
        return None
    t = job.auto_interview_threshold
    company = job.owner.company if job.owner else None

    if score < t:
        _decide(app, "rejected", NOTE_INTERVIEW_REJECTED)
        emailed = notify.decision(_name(app), app.candidate.email, job.title, company, selected=False)
        _log(db, job, app, "interview_rejected", score, t,
             f"Interview score {score} < {t}.{' Candidate emailed.' if emailed else ''}")
        return "interview_rejected"

    # Lock the job row while giving out a seat (PostgreSQL; a no-op on SQLite).
    db.execute(select(Job.id).where(Job.id == job.id).with_for_update())
    taken = selected_count(db, job)
    if taken < job.openings:
        _decide(app, "hired", NOTE_SELECTED)
        emailed = notify.decision(_name(app), app.candidate.email, job.title, company, selected=True)
        _log(db, job, app, "selected", score, t,
             f"Interview score {score} >= {t}. Opening {taken + 1} of {job.openings} filled.{' Candidate emailed.' if emailed else ''}")
        return "selected"
    _decide(app, "rejected", NOTE_FULL)
    emailed = notify.decision(_name(app), app.candidate.email, job.title, company, selected=False)
    _log(db, job, app, "openings_full", score, t,
         f"Interview score {score} >= {t}, but all {job.openings} openings were already filled.{' Candidate emailed.' if emailed else ''}")
    return "openings_full"


# ------------------------------------------------------------------ entry points


def run_job(db: Session, job: Job) -> dict:
    """Process the whole backlog of a job, first come first served. Commits."""
    summary = {"invited": 0, "cv_rejected": 0, "cv_held": 0, "selected": 0, "interview_rejected": 0, "openings_full": 0}
    if not job.auto_enabled:
        return summary
    profile = ensure_profile(db, job)
    apps = list(db.scalars(
        select(Application).where(Application.job_id == job.id)
        .order_by(Application.created_at.asc(), Application.id.asc())
    ))
    for a in apps:
        act = process_cv(db, a, profile)
        if act:
            summary[act] += 1
    db.flush()
    for a in apps:
        if a.interview is not None:
            act = process_interview(db, a.interview)
            if act:
                summary[act] += 1
    db.commit()
    return summary


def after_cv_analysis(application_id: int) -> None:
    """Called by the CV pipeline once a CV is read. Uses its own session; never raises."""
    from app.db.session import SessionLocal

    db = SessionLocal()
    try:
        app = db.get(Application, application_id)
        if app is not None and app.job.auto_enabled:
            process_cv(db, app)
            db.commit()
    except Exception:
        log.exception("Automation failed after CV analysis for application %s", application_id)
        db.rollback()
    finally:
        db.close()


def after_evaluation(interview_id: int) -> None:
    """Called once an interview has been evaluated. Uses its own session; never raises."""
    from app.db.session import SessionLocal

    db = SessionLocal()
    try:
        iv = db.get(Interview, interview_id)
        if iv is not None and iv.application.job.auto_enabled:
            process_interview(db, iv)
            db.commit()
    except Exception:
        log.exception("Automation failed after evaluation of interview %s", interview_id)
        db.rollback()
    finally:
        db.close()
