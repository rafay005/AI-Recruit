"""Tell a candidate about a decision. In the app always; by email only when SMTP is configured."""
import logging
import smtplib
from email.message import EmailMessage

from app.core.config import settings

log = logging.getLogger("notify")


def email_enabled() -> bool:
    return bool(settings.SMTP_HOST and (settings.SMTP_FROM or settings.SMTP_USER))


def send_email(to: str, subject: str, body: str) -> bool:
    """Returns True when the email was handed to the mail server. Never raises."""
    if not email_enabled() or not to:
        return False
    msg = EmailMessage()
    msg["From"] = settings.SMTP_FROM or settings.SMTP_USER
    msg["To"] = to
    msg["Subject"] = subject
    msg.set_content(body)
    try:
        with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT, timeout=15) as s:
            if settings.SMTP_TLS:
                s.starttls()
            if settings.SMTP_USER:
                s.login(settings.SMTP_USER, settings.SMTP_PASSWORD)
            s.send_message(msg)
        return True
    except Exception as exc:  # a mail problem must never break hiring
        log.warning("Email to candidate failed: %s", exc)
        return False


def _portal() -> str:
    return settings.FRONTEND_URL.rstrip("/") + "/candidate/applications"


def interview_invite(name: str, email: str, job_title: str, company: str | None) -> bool:
    at = f" at {company}" if company else ""
    return send_email(
        email,
        f"Interview invitation: {job_title}{at}",
        f"Hello {name},\n\nThank you for applying for the {job_title} role{at}. Your profile matches what we are "
        f"looking for, and we would like to invite you to a short AI interview.\n\nYou can start it whenever you are "
        f"ready from your applications page:\n{_portal()}\n\nGood luck!\nThe hiring team",
    )


def decision(name: str, email: str, job_title: str, company: str | None, selected: bool) -> bool:
    at = f" at {company}" if company else ""
    if selected:
        subject = f"Good news about the {job_title} role{at}"
        text = (f"Hello {name},\n\nCongratulations! You have been selected for the {job_title} role{at}. "
                f"The hiring team will contact you soon with the next steps.\n\n{_portal()}\n\nThe hiring team")
    else:
        subject = f"Your application for {job_title}{at}"
        text = (f"Hello {name},\n\nThank you for your interest in the {job_title} role{at}. After careful review we "
                f"will not be moving forward with your application this time. We wish you every success.\n\nThe hiring team")
    return send_email(email, subject, text)
