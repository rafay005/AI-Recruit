from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.application import Application
from app.models.job import Job
from app.schemas.cv import ExtractedCV
from app.schemas.match import GapSummaryLite, InterviewChipLite, JobCriteria, RankedCandidate, UnrankedCandidate
from app.services.job_profile import ensure_profile
from app.services.matching import match_application
from app.services.skillgap import current_assessment, to_summary


def job_criteria(job: Job) -> JobCriteria:
    return JobCriteria(
        id=job.id,
        title=job.title,
        required_skills=list(job.required_skills or []),
        nice_to_have_skills=list(job.nice_to_have_skills or []),
        min_experience_years=job.min_experience_years,
        max_experience_years=job.max_experience_years,
        education=job.education,
    )


def _chip(a: Application) -> InterviewChipLite | None:
    iv = a.interview
    if iv is None:
        return None
    ev = iv.evaluation if iv.eval_status == "done" and isinstance(iv.evaluation, dict) else None
    return InterviewChipLite(status=iv.status, score=ev.get("overall") if ev else None, label=ev.get("label") if ev else None)


def _name(app: Application) -> str:
    ex = app.extracted or {}
    return (ex.get("name") or app.candidate.full_name) if isinstance(ex, dict) else app.candidate.full_name


def rank_job(db: Session, job: Job) -> tuple[list[RankedCandidate], list[UnrankedCandidate]]:
    """Score every analysed application for a job and sort best first."""
    apps = list(
        db.scalars(
            select(Application)
            .where(Application.job_id == job.id)
            .order_by(Application.created_at.asc(), Application.id.asc())
        )
    )
    profile = ensure_profile(db, job)  # what the job is about, built once for every candidate
    scored = []
    unranked: list[UnrankedCandidate] = []
    for a in apps:
        m = match_application(job, a.extracted, a.parsed_text, profile) if a.analysis_status == "done" else None
        if m is None:
            if a.analysis_status in ("pending", "processing"):
                reason = "The CV is still being read."
            elif a.analysis_status == "failed":
                reason = a.analysis_error or "The CV could not be read."
            else:
                reason = "No CV data to compare."
            unranked.append(
                UnrankedCandidate(
                    application_id=a.id,
                    candidate_name=a.candidate.full_name,
                    analysis_status=a.analysis_status,
                    reason=reason,
                )
            )
            continue
        years = None
        gap = None
        try:
            cv = ExtractedCV.model_validate(a.extracted)
            years = cv.total_experience_years
            summary = to_summary(current_assessment(a, job, cv, m)[0])
            gap = GapSummaryLite(**summary.model_dump())
        except Exception:
            pass
        scored.append((a, m, years, gap))

    # Best overall first. Ties: more required skills, more experience, applied earlier.
    scored.sort(key=lambda t: (-t[1].overall, -t[1].required.score, -(t[2] or 0), t[0].created_at, t[0].id))
    ranked = [
        RankedCandidate(
            rank=i,
            application_id=a.id,
            candidate_name=_name(a),
            candidate_email=(a.extracted or {}).get("email") or a.candidate.email,
            years=years,
            applied_at=a.created_at,
            match=m,
            gap=gap,
            decision=a.decision or "under_review",
            interview=_chip(a),
        )
        for i, (a, m, years, gap) in enumerate(scored, start=1)
    ]
    return ranked, unranked
