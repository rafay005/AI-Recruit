"""Background job: read an uploaded CV and store the extracted data."""
import logging
from datetime import datetime, timezone
from pathlib import Path

from app.db.session import SessionLocal
from app.models.application import Application
from app.services.cv.errors import CVError
from app.services.cv.extraction import extract_cv
from app.services.cv.parsing import parse_cv
from app.services.storage import cv_file_path

log = logging.getLogger("cv")

STALE_AFTER_SECONDS = 600  # a "processing" analysis older than this is considered stuck


def _now() -> datetime:
    return datetime.now(timezone.utc)


def analyze_application(application_id: int) -> None:
    db = SessionLocal()
    done = False
    try:
        app = db.get(Application, application_id)
        if app is None:
            return
        app.analysis_status = "processing"
        app.analysis_started_at = _now()
        app.analysis_error = None
        app.analysis_note = None
        db.commit()

        try:
            path = cv_file_path(app.cv_stored_name)
            if not path.exists():
                raise CVError("The uploaded CV file could not be found. Please apply again.")
            parsed = parse_cv(path, Path(app.cv_stored_name).suffix)

            job = app.job
            extra = list(job.required_skills or []) + list(job.nice_to_have_skills or [])
            data, model, note = extract_cv(parsed.text, extra)

            notes = [n for n in (parsed.note, note) if n]
            app.parsed_text = parsed.text[:100_000]
            app.extracted = data.model_dump()
            app.extraction_method = parsed.method
            app.analysis_model = model
            app.analysis_note = " ".join(notes)[:400] or None
            app.analysis_status = "done"
            app.analyzed_at = _now()
        except CVError as exc:
            app.analysis_status = "failed"
            app.analysis_error = str(exc)[:400]
        except Exception:
            log.exception("CV analysis crashed for application %s", application_id)
            app.analysis_status = "failed"
            app.analysis_error = (
                "Something went wrong while reading this CV. Please try again or upload a different file."
            )
        db.commit()
        done = app.analysis_status == "done"
    finally:
        db.close()
    if done:
        # Hands-free hiring: invite or reject on the CV match, if the job has automation on.
        from app.services.automation import after_cv_analysis

        after_cv_analysis(application_id)
