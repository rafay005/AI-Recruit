class CVError(Exception):
    """A problem reading a CV. The message is safe to show to the candidate."""
