"""Turn an uploaded PDF or DOCX into plain text.

Text PDFs and DOCX files are read directly. Image-only (scanned) PDFs are read
with an AI vision model (VLM) or local OCR, depending on SCANNED_CV_MODE.
"""
import logging
import re
from dataclasses import dataclass
from pathlib import Path

from app.core.config import settings
from app.services.cv.errors import CVError
from app.services.cv.ocr import OCRUnavailable, ocr_available, ocr_images, render_pdf_pages
from app.services.jd_generator import LLMError
from app.services.llm_client import llm_available

log = logging.getLogger("cv")

MAX_PAGES = 15  # pages read from a text PDF
MAX_SCAN_PAGES = 4  # pages sent to OCR / vision for scanned CVs
MIN_TEXT_CHARS = 80


@dataclass
class ParseResult:
    text: str
    method: str  # pdf_text | docx | ocr | vlm
    pages: int
    note: str | None = None


def normalize_text(text: str) -> str:
    text = text.replace("\x00", "").replace("\r\n", "\n").replace("\r", "\n")
    text = text.replace("\u00a0", " ").replace("\u200b", "")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"[ \t]*\n[ \t]*", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _alnum_count(text: str) -> int:
    return sum(ch.isalnum() for ch in text)


# ----------------------------- DOCX -----------------------------


def _read_docx(path: Path) -> ParseResult:
    try:
        import docx
        from docx.table import Table
        from docx.text.paragraph import Paragraph
    except ImportError as exc:  # pragma: no cover
        raise CVError("DOCX support is not installed on the server.") from exc
    try:
        document = docx.Document(str(path))
    except Exception as exc:
        raise CVError("This DOCX file could not be opened. It may be damaged.") from exc

    parts: list[str] = []
    # Contact details are often placed in the page header.
    for section in document.sections:
        for p in section.header.paragraphs:
            if p.text.strip():
                parts.append(p.text.strip())

    for child in document.element.body.iterchildren():
        tag = child.tag.rsplit("}", 1)[-1]
        if tag == "p":
            parts.append(Paragraph(child, document).text)
        elif tag == "tbl":
            for row in Table(child, document).rows:
                seen: list[str] = []
                for cell in row.cells:
                    t = cell.text.strip()
                    if t and t not in seen:  # merged cells repeat their text
                        seen.append(t)
                if seen:
                    parts.append(" | ".join(seen))

    text = normalize_text("\n".join(parts))
    if _alnum_count(text) < MIN_TEXT_CHARS:
        raise CVError(
            "No readable text was found in this DOCX. If it contains only images, "
            "please upload a PDF or a text-based DOCX instead."
        )
    return ParseResult(text=text, method="docx", pages=1)


# ----------------------------- PDF -----------------------------


def _read_pdf_text(path: Path) -> tuple[str, int, int]:
    """Returns (text, total_pages, pages_read)."""
    try:
        from pypdf import PdfReader
    except ImportError as exc:  # pragma: no cover
        raise CVError("PDF support is not installed on the server.") from exc
    try:
        reader = PdfReader(str(path))
        if reader.is_encrypted:
            try:
                if not reader.decrypt(""):
                    raise CVError("This PDF is password protected. Please upload an unlocked copy.")
            except CVError:
                raise
            except Exception as exc:
                raise CVError("This PDF is password protected. Please upload an unlocked copy.") from exc
        total = len(reader.pages)
        chunks = []
        for page in reader.pages[:MAX_PAGES]:
            try:
                chunks.append(page.extract_text() or "")
            except Exception:
                chunks.append("")
        return normalize_text("\n\n".join(chunks)), total, min(total, MAX_PAGES)
    except CVError:
        raise
    except Exception as exc:
        raise CVError("This PDF could not be read. It may be damaged.") from exc


def _read_scanned_pdf(path: Path, total_pages: int) -> ParseResult:
    mode = (settings.SCANNED_CV_MODE or "auto").strip().lower()
    images = render_pdf_pages(path, max_pages=MAX_SCAN_PAGES)
    note_parts: list[str] = []
    if total_pages > MAX_SCAN_PAGES:
        note_parts.append(f"Only the first {MAX_SCAN_PAGES} pages of this scanned CV were read.")

    use_vlm = mode == "vlm" or (mode == "auto" and llm_available())
    if use_vlm:
        try:
            from app.services.cv.vlm import transcribe

            text = normalize_text(transcribe(images))
            if _alnum_count(text) >= MIN_TEXT_CHARS:
                return ParseResult(text, "vlm", total_pages, " ".join(note_parts) or None)
            note_parts.append("The AI vision model could not read enough text.")
        except LLMError as exc:
            if mode == "vlm":
                raise CVError(f"Reading this scanned CV with AI vision failed: {exc}") from exc
            log.warning("VLM failed, falling back to OCR: %s", exc)
            note_parts.append("AI vision was unavailable, so local OCR was used instead.")

    if mode != "vlm":
        try:
            text = normalize_text(ocr_images(images))
        except OCRUnavailable as exc:
            raise CVError(
                "This CV is a scan (images only) and no reader is available. "
                "Ask the administrator to install OCR (requirements-ocr.txt) or configure an AI key."
            ) from exc
        if _alnum_count(text) >= MIN_TEXT_CHARS:
            return ParseResult(text, "ocr", total_pages, " ".join(note_parts) or None)

    raise CVError(
        "We could not read text from this scanned CV. Please upload a clearer scan or a text-based PDF."
    )


def _read_pdf(path: Path) -> ParseResult:
    text, total, read = _read_pdf_text(path)
    pages = max(read, 1)
    scanned = _alnum_count(text) < MIN_TEXT_CHARS or _alnum_count(text) / pages < 40
    if not scanned:
        note = f"Only the first {MAX_PAGES} pages were read." if total > MAX_PAGES else None
        return ParseResult(text, "pdf_text", total, note)
    return _read_scanned_pdf(path, total)


def parse_cv(path: Path, ext: str) -> ParseResult:
    ext = ext.lower()
    if ext == ".pdf":
        return _read_pdf(path)
    if ext == ".docx":
        return _read_docx(path)
    raise CVError("Unsupported file type.")


__all__ = ["parse_cv", "ParseResult", "normalize_text", "ocr_available"]
