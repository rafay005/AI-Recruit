"""Known skills (canonical spelling). Used by the built-in extractor."""

SKILLS = [
    # Languages
    "Python", "Java", "JavaScript", "TypeScript", "C++", "C#", "Go", "Rust", "PHP", "Ruby",
    "Swift", "Kotlin", "Dart", "R", "MATLAB", "Scala", "SQL", "NoSQL", "Bash", "PowerShell",
    "HTML", "CSS", "Sass", "Perl", "Objective-C", "Assembly", "VBA",
    # Web
    "React", "Next.js", "Vue.js", "Angular", "Node.js", "Express.js", "Django", "Flask",
    "FastAPI", "Spring Boot", "Laravel", "ASP.NET", ".NET", "jQuery", "Bootstrap",
    "Tailwind CSS", "Redux", "GraphQL", "REST API", "REST APIs", "WebSockets", "Svelte", "Nuxt.js",
    "Material UI", "Streamlit", "Gradio",
    # Data / ML / AI
    "Pandas", "NumPy", "SciPy", "Scikit-learn", "TensorFlow", "PyTorch", "Keras", "OpenCV",
    "NLTK", "spaCy", "Hugging Face", "Transformers", "LangChain", "LangGraph", "LlamaIndex",
    "CrewAI", "AutoGen", "RAG", "LLMs", "LLM", "OpenAI API", "Prompt Engineering", "Computer Vision",
    "NLP", "Deep Learning", "Machine Learning", "Data Science", "Data Analysis",
    "Data Visualization", "Data Engineering", "ETL", "Matplotlib", "Seaborn", "Plotly",
    "Power BI", "Tableau", "Jupyter", "XGBoost", "LightGBM", "Generative AI", "Agentic AI",
    "AI Agents", "MLOps", "Feature Engineering", "YOLO", "CNN", "RNN", "LSTM", "GANs",
    "Reinforcement Learning", "Vector Databases", "Pinecone", "FAISS", "ChromaDB", "Qdrant",
    "Weaviate", "Fine-tuning", "LoRA", "Ollama", "OCR", "Apache Spark", "PySpark", "Hadoop",
    "Airflow", "dbt", "Snowflake", "BigQuery", "Databricks", "MLflow", "Weights & Biases",
    "Stable Diffusion", "Diffusion Models", "Speech Recognition", "Time Series",
    # Databases
    "PostgreSQL", "MySQL", "SQLite", "MongoDB", "Redis", "SQL Server", "Firebase",
    "Supabase", "Elasticsearch", "Cassandra", "DynamoDB", "MariaDB", "Neo4j",
    # DevOps / cloud
    "Docker", "Kubernetes", "AWS", "Azure", "GCP", "Google Cloud", "Terraform", "Ansible",
    "Jenkins", "GitHub Actions", "CI/CD", "Git", "GitHub", "GitLab", "Linux", "Nginx",
    "Apache Kafka", "Kafka", "RabbitMQ", "Celery", "Vercel", "Heroku", "Prometheus", "Grafana",
    # Tools / practices
    "Figma", "Jira", "Postman", "Selenium", "Pytest", "JUnit", "Microservices",
    "OOP", "System Design", "Flutter", "React Native", "Photoshop", "Illustrator",
    "SEO", "WordPress", "Shopify", "Power Apps", "Zapier", "n8n", "Cypress", "Playwright",
    "Unit Testing", "Test Automation", "Web Scraping", "Beautiful Soup", "Scrapy",
    "Blockchain", "Solidity", "Cybersecurity", "Networking", "Excel", "Power Query",
    # Ambiguous or generic: only counted if listed in a skills section
    "C", "Agile", "Scrum", "Kaggle", "Statistics", "Algorithms", "Data Structures",
    "Android", "iOS", "Unity", "Accounting", "Oracle", "Salesforce", "SAP", "QuickBooks",
    "Communication", "Leadership", "Teamwork", "Problem Solving", "Project Management",
    "Time Management", "Critical Thinking", "Public Speaking", "Negotiation",
]

# Only matched when they appear as an item in a skills list, never in free text.
AMBIGUOUS = {
    "C", "Go", "R", "Excel", "Swift", "Agile", "Scrum", "Kaggle", "Statistics", "Algorithms",
    "Data Structures", "Android", "iOS", "Unity", "Accounting", "Oracle", "Salesforce", "SAP",
    "QuickBooks", "Communication", "Leadership", "Teamwork", "Problem Solving",
    "Project Management", "Time Management", "Critical Thinking", "Public Speaking",
    "Negotiation", "Networking", "Transformers", "LLM", "OCR", "Git",
}

# Spelling variants -> canonical name. Used for items found in skills lists.
ALIASES = {
    "js": "JavaScript", "ts": "TypeScript", "reactjs": "React", "react.js": "React",
    "nodejs": "Node.js", "node": "Node.js", "node js": "Node.js", "nextjs": "Next.js",
    "next js": "Next.js", "vuejs": "Vue.js", "vue": "Vue.js", "expressjs": "Express.js",
    "express": "Express.js", "postgres": "PostgreSQL", "postgresql": "PostgreSQL",
    "mongo": "MongoDB", "sklearn": "Scikit-learn", "scikit learn": "Scikit-learn",
    "scikit-learn": "Scikit-learn", "k8s": "Kubernetes", "golang": "Go", "ml": "Machine Learning",
    "dl": "Deep Learning", "tf": "TensorFlow", "huggingface": "Hugging Face",
    "tailwind": "Tailwind CSS", "tailwindcss": "Tailwind CSS", "rest": "REST API",
    "restful api": "REST API", "restful apis": "REST APIs", "gen ai": "Generative AI",
    "genai": "Generative AI", "large language models": "LLMs", "ci cd": "CI/CD",
    "c plus plus": "C++", "cpp": "C++", "c sharp": "C#", "powerbi": "Power BI",
    "ms excel": "Excel", "microsoft excel": "Excel", "open cv": "OpenCV", "lang chain": "LangChain",
}
