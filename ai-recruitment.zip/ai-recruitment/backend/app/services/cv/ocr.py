"""Render PDF pages to images and run local OCR (RapidOCR).

RapidOCR is optional: install it with `pip install -r requirements-ocr.txt`.
"""
import io
from pathlib import Path

from app.services.cv.errors import CVError

_engine = None


class OCRUnavailable(Exception):
    pass


def render_pdf_pages(path: Path, max_pages: int = 4, scale: float = 2.0):
    """Return a list of PIL images, one per page (first `max_pages`)."""
    try:
        import pypdfium2 as pdfium
    except ImportError as exc:  # pragma: no cover
        raise CVError("PDF rendering is not installed on the server.") from exc
    try:
        pdf = pdfium.PdfDocument(str(path))
    except Exception as exc:
        raise CVError("This PDF could not be opened. It may be damaged or password protected.") from exc
    try:
        images = []
        for i in range(min(len(pdf), max_pages)):
            images.append(pdf[i].render(scale=scale).to_pil().convert("RGB"))
        return images
    finally:
        pdf.close()


def image_to_png(img, max_side: int = 1600) -> bytes:
    w, h = img.size
    longest = max(w, h)
    if longest > max_side:
        ratio = max_side / longest
        img = img.resize((int(w * ratio), int(h * ratio)))
    buf = io.BytesIO()
    img.save(buf, format="PNG", optimize=True)
    return buf.getvalue()


def ocr_available() -> bool:
    try:
        import rapidocr_onnxruntime  # noqa: F401
    except ImportError:
        return False
    return True


def ocr_images(images) -> str:
    global _engine
    try:
        import numpy as np
        from rapidocr_onnxruntime import RapidOCR
    except ImportError as exc:
        raise OCRUnavailable("RapidOCR is not installed") from exc
    if _engine is None:
        _engine = RapidOCR()
    pages = []
    for img in images:
        result, _ = _engine(np.array(img))
        lines = [r[1] for r in (result or []) if len(r) >= 3 and float(r[2]) >= 0.5]
        pages.append("\n".join(lines))
    return "\n\n".join(pages)
