"""Built-in CV extractor: no AI, no key. Rule-based and approximate.

It finds the usual CV sections (Education, Experience, Skills, Projects,
Certifications), then pulls structured items out of each one.
"""
import re
from datetime import date

from app.schemas.cv import (
    CertificationItem,
    EducationItem,
    ExperienceItem,
    ExtractedCV,
    ProjectItem,
)
from app.services.cv.skills_vocab import ALIASES, AMBIGUOUS, SKILLS

# ------------------------------------------------------------------ patterns

BULLET = r"[\u2022\u25cf\u25aa\u25e6\u2023\u2043\u2219\u00b7\u25cb\u25a0\u2756\u27a2\u2192\-\*\u2013\u2014o]"
BULLET_RE = re.compile(rf"^\s*(?:{BULLET}|\d{{1,2}}[.)])\s+")
STRICT_BULLET_RE = re.compile(r"^\s*[\u2022\u25cf\u25aa\u25e6\u2023\u2043\u2219\u00b7\u25cb\u25a0\u2756\u27a2\-\*]\s*")

MONTH = (
    r"(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|June?|July?|Aug(?:ust)?|"
    r"Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)"
)
DATE = rf"(?:{MONTH}\.?,?\s+(?:19|20)\d{{2}}|\d{{1,2}}\s*[/.-]\s*(?:19|20)\d{{2}}|(?:19|20)\d{{2}})"
PRESENT = r"(?:Present|Current|Currently|Now|Ongoing|Till\s+date|To\s+date|Date|Today)"
RANGE_RE = re.compile(
    rf"({DATE})\s*(?:-|\u2013|\u2014|to|until|till|\u2192)\s*({DATE}|{PRESENT})",
    re.IGNORECASE,
)
YEAR_RE = re.compile(r"\b(?:19|20)\d{2}\b")
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
PHONE_RE = re.compile(r"(?<!\d)(\+?\d[\d\s().\-]{8,17}\d)(?!\d)")

SECTION_ALIASES = {
    "summary": ["summary", "profile", "professional summary", "career summary", "objective",
                "career objective", "about me", "personal statement", "professional profile"],
    "education": ["education", "academic background", "academic qualifications", "qualifications",
                  "educational background", "academics", "academic profile", "education and training",
                  "educational qualifications"],
    "experience": ["experience", "work experience", "professional experience", "employment history",
                   "work history", "employment", "career history", "internships",
                   "internship experience", "relevant experience", "professional background",
                   "experience summary"],
    "skills": ["skills", "technical skills", "key skills", "core competencies", "skills and tools",
               "tools and technologies", "technologies", "expertise", "core skills",
               "technical expertise", "skills summary", "areas of expertise", "tech stack",
               "technical proficiency", "it skills", "skill set", "professional skills"],
    "projects": ["projects", "personal projects", "academic projects", "key projects",
                 "selected projects", "project experience", "notable projects", "projects undertaken",
                 "portfolio", "side projects", "final year project"],
    "certifications": ["certifications", "certificates", "licenses", "licences", "courses",
                       "training", "certifications and courses", "courses and certifications",
                       "licenses and certifications", "certifications and licenses",
                       "professional certifications", "training and certifications",
                       "achievements and certifications", "certification"],
    "other": ["languages", "interests", "hobbies", "references", "awards", "publications",
              "achievements", "volunteer", "volunteering", "extracurricular activities",
              "activities", "declaration", "personal information", "personal details", "contact",
              "contact information", "honors and awards", "awards and achievements",
              "links", "social links"],
}


def _norm_header(line: str) -> str:
    t = line.lower().replace("&", " and ")
    t = re.sub(r"[^a-z ]", " ", t)
    return re.sub(r"\s+", " ", t).strip()


_ALIAS_TO_SECTION = {_norm_header(a): sec for sec, al in SECTION_ALIASES.items() for a in al}


def _section_of(line: str) -> str | None:
    s = line.strip()
    if not s or len(s) > 50 or STRICT_BULLET_RE.match(s) or s.endswith("."):
        return None
    norm = _norm_header(s)
    if not norm or len(norm.split()) > 5:
        return None
    if norm in _ALIAS_TO_SECTION:
        return _ALIAS_TO_SECTION[norm]
    # "SKILLS SUMMARY", "Education:" style variations
    shouty = s.isupper() or s.rstrip().endswith(":")
    if shouty and len(norm.split()) <= 4:
        for alias, sec in _ALIAS_TO_SECTION.items():
            if norm.startswith(alias + " ") or norm.endswith(" " + alias):
                return sec
    return None


def split_sections(text: str) -> tuple[list[str], dict[str, list[str]]]:
    """Returns (header_lines, {section: lines}). Blank lines are kept."""
    header: list[str] = []
    sections: dict[str, list[str]] = {}
    current: str | None = None
    for raw in text.split("\n"):
        line = raw.rstrip()
        sec = _section_of(line)
        if sec:
            current = sec
            sections.setdefault(sec, [])
            continue
        (header if current is None else sections[current]).append(line)
    return header, sections


def _strip_bullet(line: str) -> str:
    return STRICT_BULLET_RE.sub("", line).strip() if STRICT_BULLET_RE.match(line) else re.sub(
        r"^\s*\d{1,2}[.)]\s+", "", line
    ).strip()


def _is_bullet(line: str) -> bool:
    return bool(STRICT_BULLET_RE.match(line)) or bool(re.match(r"^\s*\d{1,2}[.)]\s+", line))


def _clean_ends(s: str) -> str:
    return re.sub(r"^[\s,;:|()\[\]\-\u2013\u2014]+|[\s,;:|()\[\]\-\u2013\u2014]+$", "", s).strip()


def _blocks(lines: list[str]) -> list[list[str]]:
    blocks, cur = [], []
    for ln in lines:
        if ln.strip():
            cur.append(ln.strip())
        elif cur:
            blocks.append(cur)
            cur = []
    if cur:
        blocks.append(cur)
    return blocks


# ------------------------------------------------------------------ contact / name

NAME_STOP = {"resume", "curriculum", "vitae", "cv", "profile", "contact", "email", "phone",
             "address", "mobile", "objective", "summary", "portfolio", "linkedin", "github"}


def find_name(header: list[str]) -> str | None:
    for line in [ln.strip() for ln in header if ln.strip()][:6]:
        if EMAIL_RE.search(line) or re.search(r"\d", line) or "http" in line.lower():
            continue
        cleaned = re.sub(r"[|,•·].*$", "", line).strip()
        words = cleaned.split()
        if not 2 <= len(words) <= 4:
            continue
        if any(w.lower().strip(".:") in NAME_STOP for w in words):
            continue
        if all(re.fullmatch(r"[A-Za-z][A-Za-z.'\-]*", w) for w in words):
            if all(w[0].isupper() for w in words):
                return " ".join(w.capitalize() if w.isupper() else w for w in words)
    return None


def find_contact(text: str) -> tuple[str | None, str | None]:
    em = EMAIL_RE.search(text)
    phone = None
    for m in PHONE_RE.finditer(text[:3000]):
        digits = re.sub(r"\D", "", m.group(1))
        if 9 <= len(digits) <= 15 and not YEAR_RE.fullmatch(digits):
            phone = re.sub(r"\s+", " ", m.group(1)).strip()
            break
    return (em.group(0) if em else None), phone


# ------------------------------------------------------------------ dates

_MONTHS = {m: i + 1 for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"])}


def _parse_ym(s: str) -> tuple[int, int] | None:
    s = s.strip()
    if re.fullmatch(PRESENT, s, re.IGNORECASE):
        t = date.today()
        return t.year, t.month
    m = re.match(rf"({MONTH})\.?,?\s+((?:19|20)\d{{2}})", s, re.IGNORECASE)
    if m:
        return int(m.group(2)), _MONTHS[m.group(1)[:3].lower()]
    m = re.match(r"(\d{1,2})\s*[/.-]\s*((?:19|20)\d{2})", s)
    if m and 1 <= int(m.group(1)) <= 12:
        return int(m.group(2)), int(m.group(1))
    m = re.fullmatch(r"(?:19|20)\d{2}", s)
    if m:
        return int(s), 1
    return None


def years_from_experience(items: list[ExperienceItem]) -> float | None:
    spans: list[tuple[int, int]] = []
    for it in items:
        a = _parse_ym(it.start or "")
        b = _parse_ym(it.end or "")
        if a and b:
            s, e = a[0] * 12 + a[1], b[0] * 12 + b[1]
            if e >= s:
                # a year-only end date means the end of that year
                if it.end and re.fullmatch(r"(?:19|20)\d{2}", it.end.strip()):
                    e += 11
                spans.append((s, e + 1))
    if not spans:
        return None
    spans.sort()
    merged = [list(spans[0])]
    for s, e in spans[1:]:
        if s <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], e)
        else:
            merged.append([s, e])
    months = sum(e - s for s, e in merged)
    return round(months / 12, 1)


# ------------------------------------------------------------------ education

DEGREE_RE = re.compile(
    r"(?<![A-Za-z])(bachelor(?:'s|s)?|master(?:'s|s)?|b\.?\s?sc\.?|m\.?\s?sc\.?|b\.?s\.?|m\.?s\.?|"
    r"bs[a-z]{1,3}|ms[a-z]{1,3}|b\.?e\.?|m\.?e\.?|b\.?tech\.?|m\.?tech\.?|bba|mba|ph\.?d\.?|"
    r"doctorate|bca|mca|bcs|f\.?\s?sc\.?|hssc|ssc|intermediate|matric(?:ulation)?|"
    r"a[- ]levels?|o[- ]levels?|diploma|associate degree|undergraduate|postgraduate|dae)(?![A-Za-z])",
    re.IGNORECASE,
)
INSTITUTION_RE = re.compile(
    r"(university|college|institute|school|academy|polytechnic|faculty|campus|board)", re.IGNORECASE
)
GRADE_RE = re.compile(
    r"(?:cgpa|gpa|grade|percentage|marks|score)\s*[:\-]?\s*(\d+(?:\.\d+)?(?:\s*/\s*\d+(?:\.\d+)?)?\s*%?)"
    r"|(\d(?:\.\d+)?\s*/\s*(?:4(?:\.0+)?|5(?:\.0+)?|10(?:\.0+)?))",
    re.IGNORECASE,
)


def _strip_dates_and_grade(line: str) -> str:
    line = RANGE_RE.sub(" ", line)
    line = GRADE_RE.sub(" ", line)
    line = re.sub(r"\(\s*\)", " ", line)
    return _clean_ends(re.sub(r"\s+", " ", line))


def _education_block(block: list[str]) -> EducationItem | None:
    joined = " ".join(block)
    rng = RANGE_RE.search(joined)
    start = end = None
    if rng:
        start, end = rng.group(1), rng.group(2)
    else:
        years = YEAR_RE.findall(joined)
        if years:
            end = years[-1]
            start = years[0] if len(years) > 1 and years[0] != years[-1] else None
    gm = GRADE_RE.search(joined)
    grade = (gm.group(1) or gm.group(2)).strip() if gm else None

    degree_line = next((ln for ln in block if DEGREE_RE.search(_strip_dates_and_grade(ln))), None)
    inst_line = next((ln for ln in block if INSTITUTION_RE.search(ln)), None)
    degree = field = None
    if degree_line:
        dl = _strip_dates_and_grade(degree_line)
        if inst_line is degree_line:
            dl = _clean_ends(
                re.split(r"[,|\u2013\u2014]\s*(?=[^,|]*" + INSTITUTION_RE.pattern + ")", dl, flags=re.IGNORECASE)[0]
            )
        if re.search(r"\s+in\s+", dl, re.IGNORECASE):
            degree, field = re.split(r"\s+in\s+", dl, maxsplit=1, flags=re.IGNORECASE)
        else:
            m = DEGREE_RE.search(dl)
            rest = _clean_ends(dl[m.end():]) if m else ""
            if m and rest and not rest.lower().startswith("of ") and len(rest.split()) <= 6:
                degree, field = m.group(0), rest
            else:
                degree = dl
        degree, field = _clean_ends(degree), _clean_ends(field) if field else None
    institution = None
    if inst_line:
        il = _strip_dates_and_grade(inst_line)
        parts = [p.strip() for p in re.split(r"\s*[|,\u2013\u2014]\s*|\s+-\s+", il) if p.strip()]
        institution = next((p for p in parts if INSTITUTION_RE.search(p)), il)
    if not (degree or institution):
        return None
    return EducationItem(degree=degree, field=field, institution=institution,
                         start=start, end=end, grade=grade)


def parse_education(lines: list[str]) -> list[EducationItem]:
    out: list[EducationItem] = []
    for block in _blocks(lines):
        # Several entries written back to back without blank lines
        groups: list[list[str]] = [[]]
        for ln in block:
            has_deg = bool(DEGREE_RE.search(_strip_dates_and_grade(ln))) and not _is_bullet(ln)
            cur_has_deg = any(DEGREE_RE.search(_strip_dates_and_grade(x)) for x in groups[-1])
            if has_deg and cur_has_deg:
                groups.append([])
            groups[-1].append(_strip_bullet(ln))
        for g in groups:
            item = _education_block(g)
            if item:
                out.append(item)
    return out[:10]


# ------------------------------------------------------------------ experience

COMPANY_RE = re.compile(
    r"\b(inc|ltd|llc|llp|pvt|private|limited|corp|corporation|company|technologies|technology|"
    r"solutions|systems|software|labs|group|bank|university|institute|studio|agency|consulting|"
    r"services|enterprises|industries|global|digital|networks|ventures|foundation|hospital|"
    r"telecom|pakistan|international)\b",
    re.IGNORECASE,
)
TITLE_RE = re.compile(
    r"\b(engineer|developer|manager|analyst|intern|internship|lead|architect|consultant|designer|"
    r"scientist|specialist|officer|executive|director|administrator|assistant|associate|head|"
    r"coordinator|programmer|trainee|freelanc\w*|instructor|teacher|lecturer|researcher|technician|"
    r"supervisor|representative|accountant|writer|editor|founder|ceo|cto|president|volunteer)\b",
    re.IGNORECASE,
)


def _split_title_company(text: str) -> tuple[str | None, str | None]:
    text = _clean_ends(text)
    if not text:
        return None, None
    for sep in (r"\s+[|\u2022\u00b7]\s+", r"\s+[\u2013\u2014-]\s+", r"\s+(?:at|@)\s+", r",\s+"):
        parts = [p.strip() for p in re.split(sep, text) if p.strip()]
        if sep == r",\s+" and len(parts) >= 2:
            # "Title, Company" only when the first part really is a job title;
            # "Company, City" is a company with a location.
            if TITLE_RE.search(parts[0]) and not COMPANY_RE.search(parts[0]):
                return parts[0], parts[1]
            if COMPANY_RE.search(parts[0]):
                return None, parts[0]
            return None, parts[0] if not TITLE_RE.search(parts[0]) else parts[0]
        if len(parts) >= 2:
            a, b = parts[0], parts[1]
            if COMPANY_RE.search(a) and not COMPANY_RE.search(b):
                return b, a
            if TITLE_RE.search(b) and not TITLE_RE.search(a):
                return b, a
            return a, b
    if TITLE_RE.search(text) and not COMPANY_RE.search(text):
        return text, None
    if COMPANY_RE.search(text):
        return None, text
    return text, None


def _header_ok(line: str) -> bool:
    s = line.strip()
    return bool(s) and not _is_bullet(s) and len(s) <= 90 and not s.endswith(".")


def parse_experience(lines: list[str]) -> list[ExperienceItem]:
    idx = [i for i, ln in enumerate(lines) if RANGE_RE.search(ln) and not _is_bullet(ln)]
    items: list[ExperienceItem] = []

    if not idx:  # no dates anywhere: fall back to blank-line separated blocks
        for block in _blocks(lines)[:20]:
            head, desc = block[0], [_strip_bullet(x) for x in block[1:]]
            title, company = _split_title_company(head)
            if len(block) == 1 and not (TITLE_RE.search(head) or COMPANY_RE.search(head)):
                continue
            items.append(ExperienceItem(title=title, company=company, description="\n".join(desc) or None))
        return items

    headers: list[tuple[int, list[str]]] = []  # (header_start_index, pieces)
    last_anchor = -1
    for n, i in enumerate(idx):
        own = _strip_dates_and_grade(lines[i])
        own_title, own_company = _split_title_company(own) if own else (None, None)
        pieces: list[str] = [own] if own else []
        start = i
        if not (own_title and own_company):
            k = i - 1
            while k > last_anchor and len(pieces) < 2:
                if not lines[k].strip():
                    if pieces and k > 0 and lines[k - 1].strip():
                        k -= 1
                        continue
                    break
                if not _header_ok(lines[k]):
                    break
                pieces.insert(0, lines[k].strip())
                start = k
                k -= 1
        headers.append((start, pieces))
        last_anchor = i

    for n, i in enumerate(idx):
        start, pieces = headers[n]
        end_idx = headers[n + 1][0] if n + 1 < len(idx) else len(lines)
        desc_lines = [_strip_bullet(x) for x in lines[i + 1:end_idx] if x.strip()]
        rng = RANGE_RE.search(lines[i])
        if len(pieces) >= 2:
            a, b = pieces[-2], pieces[-1]
            if COMPANY_RE.search(a) and not COMPANY_RE.search(b):
                a, b = b, a
            elif TITLE_RE.search(b) and not TITLE_RE.search(a):
                a, b = b, a
            title, company = a, b
            company = re.split(r",\s+", company)[0] if company else company
        elif pieces:
            title, company = _split_title_company(pieces[0])
        else:
            title = company = None
        if not (title or company or desc_lines):
            continue
        items.append(ExperienceItem(
            title=title, company=company,
            start=rng.group(1) if rng else None, end=rng.group(2) if rng else None,
            description="\n".join(desc_lines) or None,
        ))
    return items[:20]


# ------------------------------------------------------------------ skills

_SKILL_LOOKUP = {s.lower(): s for s in SKILLS}
_SKILL_LOOKUP.update({k: v for k, v in ALIASES.items()})


def _skill_regex(term: str) -> re.Pattern:
    return re.compile(r"(?<![A-Za-z0-9+#.])" + re.escape(term) + r"(?![A-Za-z0-9+#])", re.IGNORECASE)


_SCAN_TERMS = [(s, _skill_regex(s)) for s in SKILLS if s not in AMBIGUOUS]
_SAFE_ALIASES = {"nodejs", "reactjs", "react.js", "postgres", "sklearn", "golang", "k8s", "nextjs",
                 "vuejs", "huggingface", "tailwindcss", "genai", "powerbi", "scikit learn"}
_ALIAS_TERMS = [(ALIASES[a], _skill_regex(a)) for a in _SAFE_ALIASES]


def _canon(token: str) -> str:
    return _SKILL_LOOKUP.get(token.lower().strip(), token.strip())


def parse_skills(lines: list[str], full_text: str, extra: list[str]) -> list[str]:
    found: list[str] = []
    seen: set[str] = set()

    def add(s: str):
        s = _canon(re.sub(r"\s+", " ", s).strip(" .:;-\u2013"))
        if s and s.lower() not in seen and 1 <= len(s) <= 45:
            seen.add(s.lower())
            found.append(s)

    for ln in lines:
        s = _strip_bullet(ln)
        if not s:
            continue
        if ":" in s and len(s.split(":", 1)[0]) <= 40:
            s = s.split(":", 1)[1]
        s = re.sub(r"\s*\(([^)]*)\)", r", \1", s)
        for tok in re.split(r"\s*[,;|\u2022\u00b7\u25aa/]\s*|\s{2,}", s):
            tok = tok.strip()
            if tok and len(tok.split()) <= 4 and not tok.endswith("."):
                add(tok)

    scan = re.sub(
        r"https?://\S+|www\.\S+|[\w.+-]+@[\w-]+\.[\w.]+|\b[\w-]+\.(?:com|org|net|io|dev|co|pk|me)\b\S*",
        " ",
        full_text,
    )
    for canon, rx in _SCAN_TERMS + _ALIAS_TERMS:
        if canon.lower() not in seen and rx.search(scan):
            add(canon)
    for e in extra:
        if e and e.lower() not in seen and _skill_regex(e).search(scan):
            add(e)
    return found[:80]


# ------------------------------------------------------------------ projects / certs

TECH_LINE_RE = re.compile(
    r"^\s*(?:tech(?:nologies|nology)?(?:\s+stack)?|tools|stack|built\s+with|technologies\s+used|tools\s+used)\s*[:\-]\s*(.+)$",
    re.IGNORECASE,
)


def _split_techs(s: str) -> list[str]:
    return [_canon(t) for t in re.split(r"\s*[,;|/\u2022]\s*", s) if t.strip() and len(t.strip()) <= 40][:20]


def _project_from_text(body: str) -> dict:
    tech: list[str] = []
    pm = re.search(r"\(([^)]{2,100})\)\s*$", body)
    if pm:
        tech = _split_techs(pm.group(1))
        body = body[: pm.start()].strip()
    desc = ""
    if re.search(r"\s[:\u2013\u2014-]\s|:\s", body):
        head, desc = re.split(r"\s+[\u2013\u2014-]\s+|:\s+", body, maxsplit=1)
    else:
        head = body
    um = re.search(r"\s+(?:using|with|built with|built using)\s+(.+)$", head, re.IGNORECASE)
    if um and not tech:
        tech = _split_techs(um.group(1))
    return {"name": head.strip()[:120], "desc": [desc.strip()] if desc.strip() else [], "tech": tech}


def parse_projects(lines: list[str]) -> list[ProjectItem]:
    nonblank = [ln for ln in lines if ln.strip()]
    if nonblank and all(_is_bullet(ln) for ln in nonblank):
        # A plain list: every bullet is its own project.
        return [
            ProjectItem(name=d["name"] or None, description="\n".join(d["desc"]) or None, technologies=d["tech"])
            for d in (_project_from_text(_strip_bullet(ln)) for ln in nonblank[:15])
        ]
    projects: list[dict] = []
    cur: dict | None = None
    for raw in lines:
        if not raw.strip():
            continue
        s = raw.strip()
        tm = TECH_LINE_RE.match(_strip_bullet(s))
        if tm and cur is not None:
            cur["tech"].extend(_split_techs(tm.group(1)))
            continue
        if not _is_bullet(s) and len(s) <= 90 and not s.endswith("."):
            name, tech = s, []
            pm = re.search(r"\(([^)]{2,80})\)\s*$", s)
            if pm and ("," in pm.group(1) or _canon(pm.group(1)) != pm.group(1)):
                tech = _split_techs(pm.group(1))
                name = s[: pm.start()].strip()
            name = _clean_ends(RANGE_RE.sub("", name))
            if " - " in name or " \u2013 " in name or ": " in name:
                head, tail = re.split(r"\s+[-\u2013]\s+|:\s+", name, maxsplit=1)
                cur = {"name": head, "desc": [tail], "tech": tech}
            else:
                cur = {"name": name, "desc": [], "tech": tech}
            projects.append(cur)
        elif cur is not None:
            cur["desc"].append(_strip_bullet(s))
        else:
            body = _strip_bullet(s)
            if re.search(r"\s[:\u2013-]\s", body):
                head, tail = re.split(r"\s[:\u2013-]\s", body, maxsplit=1)
                cur = {"name": head.strip(), "desc": [tail.strip()], "tech": []}
            else:
                cur = {"name": body[:80], "desc": [body] if len(body) > 80 else [], "tech": []}
            projects.append(cur)
    out = []
    for p in projects[:15]:
        out.append(ProjectItem(name=p["name"] or None, description="\n".join(p["desc"]) or None,
                               technologies=p["tech"]))
    return out


def parse_certifications(lines: list[str]) -> list[CertificationItem]:
    out: list[CertificationItem] = []
    for raw in lines:
        s = _strip_bullet(raw)
        if len(s) < 4 or len(s) > 160:
            continue
        ym = YEAR_RE.findall(s)
        dt = None
        dm = re.search(rf"({MONTH}\.?\s+(?:19|20)\d{{2}})", s, re.IGNORECASE)
        if dm:
            dt = dm.group(1)
        elif ym:
            dt = ym[-1]
        core = re.sub(rf"\(?\s*(?:{MONTH}\.?\s+)?(?:19|20)\d{{2}}\s*\)?", " ", s, flags=re.IGNORECASE)
        core = re.sub(r"\s+", " ", core).strip(" ,;:|-\u2013\u2014")
        name, issuer = core, None
        for sep in (r"\s+[-\u2013\u2014]\s+", r"\s+by\s+", r"\s+from\s+", r"\s*\|\s*", r"\s*\(([^)]+)\)\s*$", r",\s+"):
            parts = re.split(sep, core, maxsplit=1)
            if len(parts) >= 2:
                name, issuer = parts[0], parts[1]
                break
        out.append(CertificationItem(
            name=name.strip(" ,;:|-\u2013\u2014"),
            issuer=issuer.strip(" ,;:|-\u2013\u2014()") if issuer else None,
            date=dt,
        ))
    return out[:25]


# ------------------------------------------------------------------ main

def heuristic_extract(text: str, extra_skills: list[str] | None = None) -> ExtractedCV:
    header, sections = split_sections(text)
    email, phone = find_contact(text)
    summary_lines = [ln.strip() for ln in sections.get("summary", []) if ln.strip()]
    experience = parse_experience(sections.get("experience", []))
    return ExtractedCV(
        name=find_name(header),
        email=email,
        phone=phone,
        summary=" ".join(summary_lines)[:1200] or None,
        education=parse_education(sections.get("education", [])),
        experience=experience,
        skills=parse_skills(sections.get("skills", []), text, extra_skills or []),
        projects=parse_projects(sections.get("projects", [])),
        certifications=parse_certifications(sections.get("certifications", [])),
        total_experience_years=years_from_experience(experience),
    )
