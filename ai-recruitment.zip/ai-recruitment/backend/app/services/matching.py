"""Compare a CV with a job's requirements and explain the result.

Deterministic on purpose: the same CV and job always give the same score, and
every point can be traced to a visible reason (the CV line that supports it). No
generative AI call is involved in scoring, so CV text cannot talk its way into a
higher score.

Each requirement is checked with hybrid search (see services/search/hybrid.py):
  1. exact: the skill or a known alias is on the CV                     -> full credit
  2. similar: a known sibling tool (MySQL for PostgreSQL)               -> half credit
  3. meaning: keyword + embedding search finds a CV line that means the
     same thing. For broad capabilities ("video editing", "AI") that is a
     full match; for a named tool it is only half credit.

Score = weighted average of
  required skills   (default 60)
  role relevance    (default 20)   the candidate's work vs the job's responsibilities
  nice-to-have      (default 10)
  experience        (default 20)   years in CV vs the job's range
  education         (default 10)   highest degree vs the job's requirement
Parts that do not apply to a job are dropped and the weights re-balanced.
Name, gender, age, nationality and university are never used.
"""
import re
from dataclasses import dataclass

from app.core.config import settings
from app.models.job import Job
from app.schemas.cv import ExtractedCV
from app.schemas.match import (
    EducationBlock,
    ExperienceBlock,
    MatchBreakdown,
    RelevanceBlock,
    RelevanceItem,
    SkillMatch,
    SkillsBlock,
)

# ------------------------------------------------------------------ skill keys

_ALIAS = {
    "js": "javascript", "ts": "typescript", "reactjs": "react", "nodejs": "node", "node": "node",
    "nextjs": "nextjs", "vuejs": "vue", "vue": "vue", "expressjs": "express", "express": "express",
    "postgres": "postgresql", "postgre": "postgresql", "mongo": "mongodb", "sklearn": "scikitlearn",
    "k8s": "kubernetes", "golang": "go", "ml": "machinelearning", "dl": "deeplearning",
    "tf": "tensorflow", "huggingface": "huggingface", "tailwind": "tailwindcss",
    "restapi": "restapi", "restapis": "restapi", "restful": "restapi", "restfulapi": "restapi",
    "restfulapis": "restapi", "rest": "restapi", "genai": "generativeai", "llms": "llm",
    "largelanguagemodels": "llm", "cicd": "cicd", "cpp": "c++", "csharp": "c#", "msexcel": "excel",
    "microsoftexcel": "excel", "googlecloud": "gcp", "googlecloudplatform": "gcp",
    "amazonwebservices": "aws", "artificialintelligence": "ai", "naturallanguageprocessing": "nlp",
    "retrievalaugmentedgeneration": "rag", "html5": "html", "css3": "css",
    "objectorientedprogramming": "oop", "mssql": "sqlserver", "microsoftsqlserver": "sqlserver",
    "dotnet": "net", "aspnet": "aspnet", "powerbi": "powerbi", "chroma": "chromadb",
}

# Short or generic aliases that must not be searched for in free text.
_NO_TEXT = {"node", "express", "rest", "vue", "go", "ml", "dl", "tf", "js", "ts", "ai", "cv", "restful"}


def squash(s: str) -> str:
    return re.sub(r"[^a-z0-9+#]", "", s.lower())


def canon(s: str) -> str:
    k = _ALIAS.get(squash(s), squash(s))
    if len(k) > 4 and k.endswith("s") and not k.endswith("ss"):
        k = k[:-1]
    return k


_REVERSE_ALIAS: dict[str, list[str]] = {}
for _a, _c in _ALIAS.items():
    _REVERSE_ALIAS.setdefault(canon(_c), []).append(_a)

# Similar skills: having one earns partial credit for another in the same group.
_GROUPS_DISPLAY = [
    ["PostgreSQL", "MySQL", "SQL Server", "SQLite", "MariaDB", "Oracle"],
    ["MongoDB", "DynamoDB", "Cassandra", "Couchbase", "Firebase"],
    ["AWS", "Azure", "GCP"],
    ["React", "Vue.js", "Angular", "Svelte", "Next.js"],
    ["PyTorch", "TensorFlow", "Keras", "JAX"],
    ["FastAPI", "Flask", "Django"],
    ["LangChain", "LlamaIndex", "LangGraph", "CrewAI", "AutoGen", "Haystack"],
    ["Pinecone", "FAISS", "ChromaDB", "Qdrant", "Weaviate", "Milvus"],
    ["Power BI", "Tableau", "Looker", "Qlik"],
    ["JavaScript", "TypeScript"],
    ["Jenkins", "GitHub Actions", "GitLab CI", "CircleCI"],
    ["Selenium", "Cypress", "Playwright"],
    ["Kafka", "RabbitMQ"],
    ["Redis", "Memcached"],
    ["Elasticsearch", "OpenSearch", "Solr"],
    ["Terraform", "Ansible", "CloudFormation"],
    ["Spark", "PySpark", "Hadoop"],
    ["Laravel", "Symfony", "CodeIgniter"],
    ["Flutter", "React Native"],
    ["Git", "GitHub", "GitLab", "Bitbucket"],
    ["Excel", "Google Sheets"],
    ["Express.js", "NestJS", "Koa"],
    ["Java", "Kotlin"],
]
_GROUP_OF: dict[str, list[str]] = {}
for _g in _GROUPS_DISPLAY:
    for _m in _g:
        _GROUP_OF.setdefault(canon(_m), [])
        _GROUP_OF[canon(_m)] = [x for x in _g if canon(x) != canon(_m)]


def _patterns(skill: str) -> list[re.Pattern]:
    """Regexes that find a skill in free text, tolerant of spacing and punctuation."""
    k = canon(skill)
    forms = {skill.lower()}
    for alias in _REVERSE_ALIAS.get(k, []):
        if alias not in _NO_TEXT and len(alias) >= 3:
            forms.add(alias)
    out = []
    for f in forms:
        tokens = re.findall(r"[a-z0-9]+|[+#]+", f)
        if not tokens:
            continue
        body = r"[\s\-_.]*".join(re.escape(t) for t in tokens)
        out.append(re.compile(rf"(?<![a-z0-9]){body}(?![a-z0-9])", re.IGNORECASE))
    return out


# ------------------------------------------------------------------ evidence

EVIDENCE_LABEL = {
    "skills": "Listed in skills",
    "experience": "Used in experience",
    "projects": "Used in projects",
    "certifications": "In certifications",
    "summary": "In summary",
    "cv_text": "Mentioned in the CV",
}


@dataclass
class Evidence:
    skill_labels: dict[str, str]  # canon key -> skill as written in the CV
    sections: dict[str, str]  # section -> lowercase text
    full_text: str


def build_evidence(cv: ExtractedCV, parsed_text: str | None) -> Evidence:
    exp = "\n".join(
        " ".join(x for x in (e.title, e.company, e.description) if x) for e in cv.experience
    )
    proj = "\n".join(
        " ".join(x for x in (p.name, p.description, " ".join(p.technologies)) if x)
        for p in cv.projects
    )
    cert = "\n".join(" ".join(x for x in (c.name, c.issuer) if x) for c in cv.certifications)
    return Evidence(
        skill_labels={canon(s): s for s in cv.skills},
        sections={
            "experience": exp.lower(),
            "projects": proj.lower(),
            "certifications": cert.lower(),
            "summary": (cv.summary or "").lower(),
        },
        full_text=(parsed_text or "").lower(),
    )


def find_skill(skill: str, ev: Evidence) -> str | None:
    """Returns the evidence code ('skills', 'experience', ...) or None."""
    k = canon(skill)
    if k in ev.skill_labels:
        return "skills"
    if len(k) <= 2:  # "C", "R", "Go": too ambiguous to search in free text
        return None
    pats = _patterns(skill)
    for section in ("experience", "projects", "certifications", "summary"):
        if any(p.search(ev.sections[section]) for p in pats):
            return section
    if any(p.search(ev.full_text) for p in pats):
        return "cv_text"
    return None


# Hybrid-search thresholds (0..1 hybrid score of the best CV line).
MEANING_MATCH_AT = 0.60  # broad capability: experience that means the same thing counts as a match
MEANING_RELATED_AT = 0.52  # broad capability: partly shown
TOOL_RELATED_AT = 0.62  # named tool: a clearly similar tool or experience earns partial credit only

_SHOWN_IN = {
    "skills": "Related skill listed",
    "experience": "Shown in work experience",
    "projects": "Shown in projects",
    "certifications": "Shown in certifications",
    "summary": "Shown in summary",
    "cv_text": "Shown in the CV",
}


def _mentions(skill: str, text: str) -> bool:
    return any(p.search(text.lower()) for p in _patterns(skill))


def _match_skills(wanted: list[str] | list[dict], ev: Evidence, idx=None) -> SkillsBlock:
    """Each requirement: exact/alias match -> known similar tool -> hybrid search by meaning."""
    items: list[SkillMatch] = []
    for req in wanted:
        r = req if isinstance(req, dict) else {"name": req, "description": req, "conceptual": False}
        skill = r["name"]
        hits = idx.search(r.get("description") or skill, [skill], k=8) if idx is not None else []
        found = find_skill(skill, ev)
        if found:
            # Point at a real line that uses it (not just the skills list) when there is one.
            line = next((h for h in hits if h.chunk.section != "skills" and _mentions(skill, h.chunk.text)), None)
            items.append(SkillMatch(
                skill=skill, status="match", evidence=EVIDENCE_LABEL[found], method="exact", score=1.0,
                snippet=line.snippet if line else None, source=line.chunk.source if line else None,
                confidence=1.0,
            ))
            continue
        related = None
        for other in _GROUP_OF.get(canon(skill), []):
            f = find_skill(other, ev)
            if f:
                related = (other, f)
                break
        best = hits[0] if hits else None
        conf = best.score if best else 0.0
        if r.get("conceptual") and best and conf >= MEANING_MATCH_AT:
            items.append(SkillMatch(
                skill=skill, status="match", evidence=_SHOWN_IN[best.chunk.section], method="meaning",
                score=round(min(1.0, 0.7 + 0.3 * conf), 3), snippet=best.snippet, source=best.chunk.source,
                via=best.chunk.label, confidence=conf,
            ))
        elif related:
            items.append(SkillMatch(
                skill=skill, status="related", evidence=EVIDENCE_LABEL[related[1]], via=related[0],
                method="similar", score=0.5, confidence=conf or None,
            ))
        elif best and conf >= (MEANING_RELATED_AT if r.get("conceptual") else TOOL_RELATED_AT):
            items.append(SkillMatch(
                skill=skill, status="related", evidence=_SHOWN_IN[best.chunk.section],
                via=best.chunk.label, method="meaning" if r.get("conceptual") else "similar",
                score=0.5, snippet=best.snippet, source=best.chunk.source, confidence=conf,
            ))
        else:
            items.append(SkillMatch(skill=skill, status="missing", method="none", score=0.0,
                                    confidence=conf if best else None))
    matched = sum(i.status == "match" for i in items)
    related_n = sum(i.status == "related" for i in items)
    total = len(items)
    score = sum(i.score for i in items) / total if total else 0.0
    return SkillsBlock(
        total=total,
        matched=matched,
        related=related_n,
        missing=total - matched - related_n,
        score=round(score, 4),
        items=items,
    )


# ------------------------------------------------------------------ education

_LEVEL_NAMES = {
    4: "PhD",
    3: "Master's degree",
    2: "Bachelor's degree",
    1: "Diploma or intermediate",
    0.5: "Matriculation",
}
_L4 = {"phd", "doctorate", "doctoral", "dphil"}
_L3 = {"master", "masters", "msc", "ms", "mba", "mphil", "mtech", "mca", "mcs", "mscs", "msse", "msit", "mse"}
_L2 = {"bachelor", "bachelors", "bsc", "bs", "btech", "bba", "bca", "bcs", "bscs", "bsse", "bsit", "bse",
       "bsee", "bcom", "undergraduate"}
_L1 = {"diploma", "associate", "dae", "intermediate", "fsc", "hssc", "alevel", "alevels"}
_L05 = {"matric", "matriculation", "ssc", "olevel", "olevels"}
_UPPER_ONLY = {"BE": 2, "ME": 3, "BA": 2, "MA": 3}


def education_level(text: str) -> float | None:
    if not text:
        return None
    clean = text.replace(".", "")
    best: float | None = None
    for tok in re.findall(r"[A-Za-z]+", clean):
        low = tok.lower()
        lvl = None
        if low in _L4:
            lvl = 4
        elif low in _L3:
            lvl = 3
        elif low in _L2:
            lvl = 2
        elif low in _L1:
            lvl = 1
        elif low in _L05:
            lvl = 0.5
        elif tok in _UPPER_ONLY:
            lvl = _UPPER_ONLY[tok]
        if lvl is not None and (best is None or lvl > best):
            best = lvl
    return best


def _education(job: Job, cv: ExtractedCV) -> EducationBlock:
    if not job.education:
        return EducationBlock(applicable=False, status="na")
    req = education_level(job.education)
    if req is None:
        if re.search(r"\bdegree\b|\bgraduate\b", job.education, re.IGNORECASE):
            req = 2
        else:
            return EducationBlock(applicable=False, status="na")
    best_lvl, best_text = None, None
    for e in cv.education:
        text = " ".join(x for x in (e.degree, e.field) if x)
        lvl = education_level(text)
        if lvl is not None and (best_lvl is None or lvl > best_lvl):
            best_lvl, best_text = lvl, text
    required_label = _LEVEL_NAMES.get(req, "Degree")
    if best_lvl is None:
        return EducationBlock(applicable=True, status="unknown", required=required_label, score=0.5)
    if best_lvl >= req:
        score, status = 1.0, "meets"
    elif best_lvl >= req - 1:
        score, status = 0.5, "below"
    else:
        score, status = 0.2, "below"
    return EducationBlock(
        applicable=True, status=status, required=required_label, candidate=best_text, score=score
    )


# ------------------------------------------------------------------ experience


def _experience(job: Job, cv: ExtractedCV) -> ExperienceBlock:
    mn, mx = job.min_experience_years, job.max_experience_years
    if mn is None and mx is None:
        return ExperienceBlock(applicable=False, status="na")
    years = cv.total_experience_years
    base = dict(applicable=True, required_min=mn, required_max=mx, candidate_years=years)
    if years is None:
        return ExperienceBlock(status="unknown", score=0.5, **base)
    need = mn or 0
    if years >= need:
        return ExperienceBlock(status="meets", score=1.0, **base)
    return ExperienceBlock(status="below", score=round(max(0.0, years / need), 4), **base)


# ------------------------------------------------------------------ overall


def label_for(percent: int) -> str:
    if percent >= 80:
        return "Strong match"
    if percent >= 60:
        return "Good match"
    if percent >= 40:
        return "Partial match"
    return "Weak match"


# ------------------------------------------------------------------ relevance

_WORK_SECTIONS = {"experience", "projects", "summary", "certifications", "cv_text"}
# Mean hybrid score of a typical unrelated CV sits near 0.15, a closely matching one near 0.7.
_REL_FLOOR, _REL_SPAN = 0.15, 0.55


def _relevance(job: Job, profile: dict, idx) -> RelevanceBlock:
    """Does the candidate's actual work look like the work this job involves?"""
    if idx is None or not idx.semantic:
        return RelevanceBlock(applicable=False)
    queries = [(f"The role: {job.title}", f"Experience working as {job.title}. {profile.get('summary') or ''}")]
    queries += [(r, r) for r in (profile.get("responsibilities") or [])[:8]]
    items: list[RelevanceItem] = []
    for label, q in queries:
        hits = idx.search(q, q, sections=_WORK_SECTIONS, k=1)
        h = hits[0] if hits else None
        s = h.score if h else 0.0
        items.append(RelevanceItem(
            text=label, score=round(s, 3),
            status="strong" if s >= 0.6 else "partial" if s >= 0.35 else "weak",
            snippet=h.snippet if h and s >= 0.35 else None,
            source=h.chunk.source if h and s >= 0.35 else None,
        ))
    mean = sum(i.score for i in items) / len(items)
    return RelevanceBlock(applicable=True, score=round(max(0.0, min(1.0, (mean - _REL_FLOOR) / _REL_SPAN)), 4),
                          items=items)


def match_cv(job: Job, cv: ExtractedCV, parsed_text: str | None, profile: dict | None = None) -> MatchBreakdown:
    from app.services.job_profile import profile_for
    from app.services.search.hybrid import cv_index

    profile = profile or profile_for(job)
    reqs = {(r["kind"], canon(r["name"])): r for r in profile.get("requirements") or []}

    def _reqs(kind: str, names: list[str]) -> list[dict]:
        return [reqs.get((kind, canon(n))) or {"name": n, "description": n, "conceptual": False} for n in names]

    ev = build_evidence(cv, parsed_text)
    try:
        idx = cv_index(cv, parsed_text)
    except Exception:  # search is an enhancement; the exact matcher still works without it
        idx = None
    required = _match_skills(_reqs("required", list(job.required_skills or [])), ev, idx)
    nice = _match_skills(_reqs("nice", list(job.nice_to_have_skills or [])), ev, idx) if job.nice_to_have_skills else None
    experience = _experience(job, cv)
    education = _education(job, cv)
    relevance = _relevance(job, profile, idx)

    parts: list[tuple[str, float, float]] = [("required", settings.RANK_WEIGHT_REQUIRED, required.score)]
    if relevance.applicable and relevance.score is not None:
        parts.append(("relevance", settings.RANK_WEIGHT_RELEVANCE, relevance.score))
    if nice:
        parts.append(("nice_to_have", settings.RANK_WEIGHT_NICE, nice.score))
    if experience.applicable and experience.score is not None:
        parts.append(("experience", settings.RANK_WEIGHT_EXPERIENCE, experience.score))
    if education.applicable and education.score is not None:
        parts.append(("education", settings.RANK_WEIGHT_EDUCATION, education.score))

    total_w = sum(w for _, w, _ in parts) or 1.0
    overall = round(100 * sum(w * s for _, w, s in parts) / total_w)
    overall = max(0, min(100, overall))
    weights = {name: round(100 * w / total_w, 1) for name, w, _ in parts}
    return MatchBreakdown(
        overall=overall,
        label=label_for(overall),
        required=required,
        nice_to_have=nice,
        experience=experience,
        education=education,
        relevance=relevance,
        weights=weights,
        search_mode="hybrid" if idx is not None and idx.semantic else "keyword",
        role_family=profile.get("role_family_label"),
    )


def match_application(
    job: Job, extracted: dict | None, parsed_text: str | None, profile: dict | None = None
) -> MatchBreakdown | None:
    if not extracted:
        return None
    try:
        cv = ExtractedCV.model_validate(extracted)
    except Exception:
        return None
    return match_cv(job, cv, parsed_text, profile)
