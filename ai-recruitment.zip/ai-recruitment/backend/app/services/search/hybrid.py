"""Hybrid search over one CV: keywords (BM25) + meaning (embeddings).

The CV is split into small, self-contained chunks: each listed skill, each bullet of
each job, each project, the summary sentences and certifications. A query (one job
requirement, expanded into what it means for this job) is scored against every chunk:

    keyword score   BM25 plus how many of the requirement's own words appear (0..1)
    meaning score   cosine similarity minus a "noise floor" (0..1). The floor is how
                    similar the query is to unrelated filler sentences, so generic
                    queries do not score high on everything.
    hybrid score    0.7 * meaning + 0.3 * keyword  (keyword only when the model is off)

The best chunk is returned with its text, so every match can be explained by pointing
at the exact line of the CV.
"""
import hashlib
import json
import re
from collections import OrderedDict
from dataclasses import dataclass

import numpy as np

from app.schemas.cv import ExtractedCV
from app.services.search import embeddings
from app.services.search.bm25 import BM25, tokenize

# Thresholds were calibrated on bge-small-en-v1.5 with expanded queries: true matches sit
# 0.15-0.30 above the floor, unrelated text sits below about 0.07.
MARGIN_ZERO = 0.04
MARGIN_SPAN = 0.14
W_SEMANTIC = 0.7

# Unrelated sentences that set the noise floor for each query.
_ANCHORS = [
    "Worked as a cashier at a grocery store.",
    "Volunteered at a local animal shelter on weekends.",
    "Hobbies include hiking, cooking and reading novels.",
    "Responsible for office administration and filing paperwork.",
    "Drove delivery trucks across the region.",
    "Fluent in English and Urdu.",
    "Member of the university cricket club.",
    "References available on request.",
]
_anchor_vecs: np.ndarray | None = None


def _anchors() -> np.ndarray | None:
    global _anchor_vecs
    if _anchor_vecs is None:
        _anchor_vecs = embeddings.embed(_ANCHORS)
    return _anchor_vecs


@dataclass
class Chunk:
    text: str  # what is searched
    display: str  # short snippet shown to HR
    section: str  # skills | experience | projects | summary | certifications | cv_text
    source: str | None = None  # "AI Engineer at Acme", "Project: Chatbot"
    label: str | None = None  # for skill chunks: the skill as written


@dataclass
class Hit:
    chunk: Chunk
    score: float  # hybrid 0..1
    semantic: float | None  # 0..1, None when the model is off
    keyword: float  # 0..1

    @property
    def snippet(self) -> str:
        return self.chunk.display


def _clip(s: str, n: int) -> str:
    s = re.sub(r"\s+", " ", s or "").strip()
    return s if len(s) <= n else s[: n - 1].rsplit(" ", 1)[0] + "…"


def _pieces(text: str | None) -> list[str]:
    """Split a description into bullet/sentence pieces of a useful size."""
    if not text:
        return []
    parts = re.split(r"\n+|\s*[•●▪◦‣]\s*|(?<=[.!?])\s+(?=[A-Z])", text)
    out: list[str] = []
    for p in parts:
        p = re.sub(r"^\s*[-*\d.)]+\s+", "", p).strip(" -–;")
        if not p:
            continue
        if out and len(p.split()) < 4:
            out[-1] = f"{out[-1]} {p}"
        else:
            out.append(p)
    return [p for p in out if len(p.split()) >= 3][:12]


def build_chunks(cv: ExtractedCV, parsed_text: str | None) -> list[Chunk]:
    chunks: list[Chunk] = []
    for s in cv.skills:
        chunks.append(Chunk(text=s, display=s, section="skills", label=s))
    for e in cv.experience:
        head = " at ".join(x for x in (e.title, e.company) if x) or "Work experience"
        # The source names the role, never the employer: it can end up in interview questions.
        src = f"your role as {e.title}" if e.title else "your work experience"
        chunks.append(Chunk(text=head, display=e.title or head, section="experience", source=src))
        for p in _pieces(e.description):
            chunks.append(Chunk(text=f"{head}: {p}", display=_clip(p, 170), section="experience", source=src))
    for pr in cv.projects:
        # "AI Monitoring System (Full-Stack" -> "AI Monitoring System" (unbalanced brackets from parsing)
        name = re.sub(r"\s*[(\[][^)\]]*$", "", pr.name or "").strip(" -–:|") or "Project"
        tech = ", ".join(pr.technologies)
        head = f"Project {name}" + (f" ({tech})" if tech else "")
        chunks.append(Chunk(text=head, display=_clip(head, 170), section="projects", source=f"the {name} project"))
        for p in _pieces(pr.description):
            chunks.append(Chunk(text=f"{name}: {p}", display=_clip(p, 170), section="projects", source=f"the {name} project"))
    for p in _pieces(cv.summary):
        chunks.append(Chunk(text=p, display=_clip(p, 170), section="summary"))
    for c in cv.certifications:
        t = " - ".join(x for x in (c.name, c.issuer) if x)
        chunks.append(Chunk(text=f"Certification: {t}", display=t, section="certifications", source=c.name))
    # Sparse extraction: also search the raw CV lines.
    if len(chunks) < 12 and parsed_text:
        for line in parsed_text.splitlines():
            line = line.strip()
            if len(line.split()) >= 5:
                chunks.append(Chunk(text=line, display=_clip(line, 170), section="cv_text"))
            if len(chunks) >= 120:
                break
    return chunks[:220]


class CVIndex:
    def __init__(self, cv: ExtractedCV, parsed_text: str | None):
        self.chunks = build_chunks(cv, parsed_text)
        self.bm25 = BM25([c.text for c in self.chunks])
        self.vecs = embeddings.embed([c.text for c in self.chunks]) if self.chunks else None

    @property
    def semantic(self) -> bool:
        return self.vecs is not None and len(self.chunks) > 0

    def search(
        self,
        query: str,
        terms: list[str] | str,
        *,
        sections: set[str] | None = None,
        k: int = 3,
    ) -> list[Hit]:
        """Best chunks for a query. `terms` are the requirement's own words (for keyword coverage)."""
        if not self.chunks:
            return []
        term_toks = tokenize(terms) if isinstance(terms, str) else [t for x in terms for t in tokenize(x)]
        bm = self.bm25.scores(tokenize(query) + term_toks)
        cov = self.bm25.coverage(term_toks)
        kw = np.array([0.6 * c + 0.4 * (b / (b + 2.5)) for c, b in zip(cov, bm)], dtype=np.float32)

        sem = None
        if self.vecs is not None:
            qv = embeddings.embed([query], query=True)
            anchors = _anchors()
            if qv is not None and anchors is not None:
                q = qv[0]
                floor = float((anchors @ q).max())
                margin = self.vecs @ q - floor
                sem = np.clip((margin - MARGIN_ZERO) / MARGIN_SPAN, 0.0, 1.0)

        score = (W_SEMANTIC * sem + (1 - W_SEMANTIC) * kw) if sem is not None else kw
        idx = [i for i in np.argsort(-score) if sections is None or self.chunks[i].section in sections]
        return [
            Hit(
                chunk=self.chunks[i],
                score=round(float(score[i]), 4),
                semantic=round(float(sem[i]), 4) if sem is not None else None,
                keyword=round(float(kw[i]), 4),
            )
            for i in idx[:k]
        ]


_cache: "OrderedDict[str, CVIndex]" = OrderedDict()


def cv_index(cv: ExtractedCV, parsed_text: str | None) -> CVIndex:
    """Cached per CV content, so ranking a job repeatedly does not re-chunk or re-embed."""
    key = hashlib.sha256(
        (json.dumps(cv.model_dump(), sort_keys=True, default=str) + "|" + (parsed_text or "")[:20000]
         + "|" + str(embeddings.available())).encode("utf-8")
    ).hexdigest()
    if key in _cache:
        _cache.move_to_end(key)
        return _cache[key]
    idx = CVIndex(cv, parsed_text)
    _cache[key] = idx
    if len(_cache) > 300:
        _cache.popitem(last=False)
    return idx


def relatedness(query: str, text: str) -> float | None:
    """How related a text is to a query, 0..1 on the same scale as search. None without the model."""
    if not query or not text:
        return None
    q = embeddings.embed([query], query=True)
    p = embeddings.embed([text[:2000]])
    anchors = _anchors()
    if q is None or p is None or anchors is None:
        return None
    floor = float((anchors @ q[0]).max())
    return float(np.clip((float(p[0] @ q[0]) - floor - MARGIN_ZERO) / MARGIN_SPAN, 0.0, 1.0))


def best_match(query: str, options: list[str]) -> tuple[int, float] | None:
    """Index and similarity (raw cosine) of the option closest in meaning to the query."""
    if not options:
        return None
    q = embeddings.embed([query], query=True)
    o = embeddings.embed(options)
    if q is None or o is None:
        return None
    s = o @ q[0]
    i = int(np.argmax(s))
    return i, float(s[i])
