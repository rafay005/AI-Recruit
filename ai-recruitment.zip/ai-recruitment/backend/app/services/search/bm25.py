"""Small BM25 (keyword relevance) over a list of short documents."""
import math
import re
from collections import Counter

_STOP = set(
    "a an and are as at be by for from has have in into is it its of on or that the this to was were will "
    "with you your our we they their them he she his her i me my not but if so than then there these those "
    "can could should would may might must also very more most such any all each other some about over "
    "work working worked experience experienced skill skills strong good excellent ability able knowledge "
    "using use used role job candidate team years year etc including include".split()
)


def tokenize(text: str) -> list[str]:
    toks = re.findall(r"[a-z0-9][a-z0-9+#.]*", (text or "").lower())
    out = []
    for t in toks:
        t = t.strip(".")
        if not t or t in _STOP or (len(t) < 2 and t not in {"c", "r"}):
            continue
        if len(t) > 4 and t.endswith("s") and not t.endswith("ss"):
            t = t[:-1]
        out.append(t)
    return out


class BM25:
    def __init__(self, docs: list[str], k1: float = 1.4, b: float = 0.6):
        self.k1, self.b = k1, b
        self.docs = [tokenize(d) for d in docs]
        self.tf = [Counter(d) for d in self.docs]
        n = len(self.docs)
        self.avgdl = (sum(len(d) for d in self.docs) / n) if n else 0.0
        df: Counter = Counter()
        for d in self.docs:
            df.update(set(d))
        # A floor on IDF keeps a term that appears in every chunk from scoring zero.
        self.idf = {t: max(0.15, math.log(1 + (n - f + 0.5) / (f + 0.5))) for t, f in df.items()}

    def scores(self, query: str | list[str]) -> list[float]:
        q = tokenize(query) if isinstance(query, str) else query
        out = []
        for tf, d in zip(self.tf, self.docs):
            s = 0.0
            dl = len(d) or 1
            for t in q:
                f = tf.get(t)
                if not f:
                    continue
                s += self.idf.get(t, 0.0) * f * (self.k1 + 1) / (f + self.k1 * (1 - self.b + self.b * dl / (self.avgdl or 1)))
            out.append(s)
        return out

    def coverage(self, terms: list[str]) -> list[float]:
        """Share of the given terms that appear in each document (0..1)."""
        if not terms:
            return [0.0] * len(self.docs)
        uniq = list(dict.fromkeys(terms))
        return [sum(1 for t in uniq if t in tf) / len(uniq) for tf in self.tf]
