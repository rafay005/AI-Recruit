"""Local sentence embeddings (meaning, not keywords).

Uses a small open model (bge-small-en, ~70 MB) through fastembed/ONNX. It is downloaded
once into EMBEDDING_CACHE_DIR and then runs offline on the CPU; no API key is needed.
Vectors are cached in memory and in the `text_embeddings` table, so each CV chunk and
job requirement is only embedded once.

If the model cannot be loaded (package missing, no network on first run, or
SEMANTIC_SEARCH=off) `available()` is False and callers fall back to keyword search.
"""
import hashlib
import logging
import threading
from pathlib import Path

import numpy as np

from app.core.config import settings

log = logging.getLogger("search")

# bge models want this prefix on short queries (not on the passages being searched).
QUERY_PREFIX = "Represent this sentence for searching relevant passages: "

_lock = threading.Lock()
_model = None
_failed: str | None = None
_mem: dict[str, np.ndarray] = {}
_MEM_MAX = 20000


def _enabled() -> bool:
    return (settings.SEMANTIC_SEARCH or "auto").strip().lower() != "off"


def _cache_dir() -> str:
    p = Path(settings.EMBEDDING_CACHE_DIR)
    if not p.is_absolute():
        p = Path(__file__).resolve().parents[3] / p
    p.mkdir(parents=True, exist_ok=True)
    return str(p)


def _load():
    global _model, _failed
    if _model is not None or _failed is not None:
        return _model
    with _lock:
        if _model is not None or _failed is not None:
            return _model
        if not _enabled():
            _failed = "Semantic search is turned off (SEMANTIC_SEARCH=off)."
            return None
        try:
            from fastembed import TextEmbedding as _FE

            _model = _FE(settings.EMBEDDING_MODEL, cache_dir=_cache_dir())
            log.info("Embedding model loaded: %s", settings.EMBEDDING_MODEL)
        except Exception as exc:  # missing package, no network on first download, ...
            _failed = f"Embedding model unavailable: {type(exc).__name__}: {exc}"[:300]
            log.warning(_failed)
    return _model


def available() -> bool:
    return _load() is not None


def unavailable_reason() -> str | None:
    _load()
    return _failed


def warm_up() -> None:
    """Load the model in the background so the first ranking request is fast."""
    threading.Thread(target=_load, name="embedding-warmup", daemon=True).start()


def _key(text: str, query: bool) -> str:
    raw = f"{settings.EMBEDDING_MODEL}|{'q' if query else 'p'}|{text}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _db_get(keys: list[str]) -> dict[str, np.ndarray]:
    if not keys:
        return {}
    try:
        from app.db.session import SessionLocal
        from app.models.embedding import TextEmbedding

        with SessionLocal() as db:
            rows = db.query(TextEmbedding).filter(TextEmbedding.key.in_(keys)).all()
            return {r.key: np.frombuffer(r.vector, dtype=np.float32) for r in rows}
    except Exception as exc:
        log.debug("embedding cache read failed: %s", exc)
        return {}


def _db_put(items: dict[str, np.ndarray]) -> None:
    if not items:
        return
    try:
        from app.db.session import SessionLocal
        from app.models.embedding import TextEmbedding

        with SessionLocal() as db:
            for k, v in items.items():
                db.merge(TextEmbedding(key=k, model=settings.EMBEDDING_MODEL, vector=v.astype(np.float32).tobytes()))
            db.commit()
    except Exception as exc:  # the cache is an optimisation; never fail a request over it
        log.debug("embedding cache write failed: %s", exc)


def embed(texts: list[str], *, query: bool = False) -> np.ndarray | None:
    """L2-normalised vectors, one row per text, or None when the model is unavailable."""
    model = _load()
    if model is None:
        return None
    if not texts:
        return np.zeros((0, 384), dtype=np.float32)
    keys = [_key(t, query) for t in texts]
    found = {k: _mem[k] for k in keys if k in _mem}
    missing = [k for k in dict.fromkeys(keys) if k not in found]
    if missing:
        from_db = _db_get(missing)
        found.update(from_db)
        missing = [k for k in missing if k not in from_db]
    if missing:
        todo = {}
        for k, t in zip(keys, texts):
            if k in missing and k not in todo:
                todo[k] = (QUERY_PREFIX + t) if query else t
        with _lock:
            vecs = list(model.embed(list(todo.values()), batch_size=32))
        fresh = {}
        for k, v in zip(todo.keys(), vecs):
            v = np.asarray(v, dtype=np.float32)
            n = float(np.linalg.norm(v)) or 1.0
            fresh[k] = v / n
        found.update(fresh)
        _db_put(fresh)
    if len(_mem) > _MEM_MAX:
        _mem.clear()
    _mem.update(found)
    return np.stack([found[k] for k in keys])
