"""Build the interview plan: which topics to cover, tailored to the job AND the candidate.

Inputs that make every interview different:
  * the job profile: role family (technical / creative / people / business style),
    responsibilities, AI-written scenarios and focus areas when available
  * this candidate's hybrid-search evidence: the actual CV line or project behind
    each matched skill, the gaps, and which responsibilities their work covers
  * a per-candidate seed: when several topics or phrasings fit equally well, the
    choice differs between candidates, so two people with the same CV shape still
    get different questions

Each item carries a ready-to-ask `question` (used by the built-in interviewer, and as
a draft for the AI interviewer) and a `hint` for the AI. Employer and candidate names
are never put into questions, because questions are sent to the AI later.
"""
import random
import re

from app.models.job import Job
from app.schemas.cv import ExtractedCV
from app.schemas.gap import GapAssessment
from app.schemas.match import MatchBreakdown
from app.services.job_profile import is_action
from app.services.search.bm25 import tokenize

MIN_QUESTIONS, MAX_QUESTIONS = 3, 8


def clamp_questions(n: int | None, default: int) -> int:
    return max(MIN_QUESTIONS, min(MAX_QUESTIONS, int(n or default)))


def _lower_first(s: str) -> str:
    return s[0].lower() + s[1:] if s and not s[:2].isupper() else s


def first_responsibility(job: Job) -> str | None:
    """The first usable responsibility of the job, cleaned up."""
    from app.services.job_profile import responsibilities_of

    for line in responsibilities_of(job):
        if 8 <= len(line) <= 140:
            return _lower_first(line)
    return None


# ------------------------------------------------------------------ phrasing

_INTRO = [
    "To start, could you tell me a little about yourself and the experience that is most relevant to this role?",
    "Let's begin with you. Could you tell me a little about yourself, and which part of your experience best prepares you for this {title} role?",
    "To get us started, tell me a little about yourself and the work you've done that connects most closely to what this {title} role involves.",
]
_VERIFY_CTX = [
    "I can see you've worked with {topic} in {where}. Could you walk me through what you built there, and which decisions were yours?",
    "Let's talk about {topic}. In {where}, what problem were you solving with it, and how did you approach it?",
    "I'd like to understand your hands-on {topic} work. Taking {where} as an example, what was the hardest part and how did you handle it?",
]
_VERIFY = [
    "I can see {topic} on your CV. Could you walk me through a project where you used it, and what you personally built or decided?",
    "Tell me about the most substantial thing you've done with {topic}. What was your own part in it?",
    "How have you used {topic} in practice? Pick one real example and take me through it.",
]
_MEANING = [  # a line of the CV means the same thing as the requirement
    "This role needs {topic}. Your CV mentions \"{snippet}\". How does that experience carry over to this job?",
    "On {topic}: you wrote \"{snippet}\". Could you tell me more about that, and what you would bring from it to this role?",
]
_MEANING_SKILL = [  # a listed skill covers the requirement
    "This role needs {topic}, and you list {label} on your CV. Could you give me a real example where you used it?",
    "You list {label}, which matters here because the role needs {topic}. Tell me about a time it made a real difference in your work.",
]
_MEANING_CERT = [
    "This role needs {topic}, and you have the \"{snippet}\" certification. How have you applied what you learned in real work?",
]
_MEANING_WHERE = [
    "This role needs {topic}, and {where} looks related. How does that experience carry over to this job?",
]
_GAP = [
    "This role also involves {topic}{ctx}. How much have you worked with it, and if not much, how would you get up to speed?",
    "{Topic} is an important part of this job{ctx}. What is the closest experience you have, and how would you close the gap in your first weeks?",
    "How comfortable are you with {topic}{ctx}? If it's new to you, what would your plan be to learn it quickly?",
]
_GAP_VIA = [
    "You've worked with {via}. This role uses {topic}{ctx}. How would you transfer what you know, and what would you need to learn?",
]
_PROJECT = [
    "{Where} looks closely related to this part of the role: \"{resp}\". What was your part in it, and what would you do differently today?",
    "Let's go deeper into {where}. This role includes \"{resp}\". How does that work compare, and what did you learn from it?",
]
_SCENARIO_QUOTE = [
    "Here is part of the role: \"{resp}\". How would you approach that, step by step?",
    "This role involves the following: \"{resp}\". Walk me through how you would handle it from start to finish.",
]
_SCENARIO = {
    "technical": [
        "Here is a scenario from the role: you may be asked to {resp}. How would you approach that, step by step?",
        "Imagine that in your first month you need to {resp}. Walk me through how you would plan it and what could go wrong.",
        "Suppose the team asks you to {resp}. What would you do first, and how would you know it is working?",
    ],
    "creative": [
        "Here is a scenario from the role: you may be asked to {resp}. Talk me through your process from brief to final delivery.",
        "Imagine your first project here is to {resp}. How would you plan it, keep the quality consistent, and hit the deadline?",
        "Suppose a client asks you to {resp}. What questions would you ask first, and how would you approach the work?",
    ],
    "people": [
        "Here is a scenario from the role: you may be asked to {resp}. How would you handle it, and how would you know it went well?",
        "Imagine you need to {resp} in your first few weeks. Walk me through what you would do.",
        "Suppose you are asked to {resp}, and the person on the other side is unhappy. How would you approach it?",
    ],
    "business": [
        "Here is a scenario from the role: you may be asked to {resp}. How would you approach that, step by step?",
        "Imagine you need to {resp} with a tight deadline. How would you plan and prioritise the work?",
        "Suppose your manager asks you to {resp}. What would you do first, and how would you measure success?",
    ],
}
_SCENARIO_AI = ["Here is a situation from this role: {scenario} How would you approach it?"]
_SCENARIO_NONE = [
    "Think of a realistic problem a {title} would face. How would you approach solving it, step by step?",
]
_DEPTH = {
    "technical": ("Technical depth", [
        "What is the most technically challenging thing you have worked on recently, and what decisions did you make?",
        "Tell me about a hard technical problem you solved. What options did you consider, and why did you choose the one you did?",
    ]),
    "creative": ("Past work", [
        "Tell me about the piece of work you are proudest of. What creative decisions did you make, and why?",
        "Walk me through a project where the first version did not work. How did you change it?",
    ]),
    "people": ("Past work", [
        "Tell me about a difficult situation with a customer or colleague, and how you handled it.",
        "Describe a time you had to win someone's trust quickly. What did you do?",
    ]),
    "business": ("Past work", [
        "Tell me about a time you delivered results under a tight deadline. How did you plan and prioritise?",
        "Describe a decision you made with incomplete information. How did it turn out?",
    ]),
}
_MOTIVATION = [
    "Last question. What interests you about this role, and is there anything you would like the hiring team to know about you?",
    "Last question. Why does this {title} role appeal to you right now, and is there anything else you would like the hiring team to know?",
    "Last question. What would you hope to achieve in your first six months in this role, and is there anything you'd like to add?",
]


class _Pick:
    """Deterministic per candidate: the same interview always gets the same plan."""

    def __init__(self, seed):
        self.seed = seed

    def rng(self, key: str) -> random.Random:
        return random.Random(f"{self.seed}|{key}")

    def one(self, key: str, options: list):
        return options[self.rng(key).randrange(len(options))] if options else None


def _cap(s: str | None) -> str:
    return (s or "")[:1].upper() + (s or "")[1:]


def _fill(tpl: str, **kw) -> str:
    out = tpl.format(**{k: (v or "") for k, v in kw.items()}, Topic=_cap(kw.get("topic")), Where=_cap(kw.get("where")))
    return re.sub(r"\s+", " ", out).strip()


def _scrubber(cv: ExtractedCV, full_name: str | None):
    """Remove employer and person names, emails and links from CV text quoted in a question."""
    names = {e.company for e in cv.experience if e.company} | {n for n in (cv.name, full_name) if n}
    pats = [re.compile(re.escape(n), re.I) for n in sorted(names, key=len, reverse=True) if len(n) >= 3]
    for n in (cv.name, full_name):
        for tok in (n or "").split():
            if len(tok) >= 3:
                pats.append(re.compile(rf"\b{re.escape(tok)}\b", re.I))

    def scrub(text: str | None) -> str | None:
        if not text:
            return text
        t = re.sub(r"\S+@\S+|https?://\S+|www\.\S+", "", text)
        for p in pats:
            t = p.sub("the company", t)
        t = re.sub(r"\s+", " ", t).strip(" .;,")
        return t[:110].rsplit(" ", 1)[0] + "…" if len(t) > 110 else t

    return scrub


_SECTION_BY_LABEL = {
    "Related skill listed": "skills", "Shown in certifications": "certifications",
    "Shown in work experience": "experience", "Shown in projects": "projects",
}


def _section_of(evidence: str | None) -> str | None:
    return _SECTION_BY_LABEL.get(evidence or "")


def _display(skill: str) -> str:
    """How a requirement reads in a sentence: "ai" -> "AI"."""
    s = skill.strip()
    return s.upper() if len(s) <= 3 and s.isalpha() else s


def _quotable(snippet: str) -> bool:
    """A CV line worth quoting back: a full phrase, not a fragment cut mid-sentence."""
    return len(snippet.split()) >= 5 and (snippet[:1].isupper() or snippet[:1].isdigit())


def _resp_for(topic: str, resps: list[str]) -> str | None:
    """The responsibility that mentions this topic, if any."""
    toks = {t for t in tokenize(topic) if len(t) >= 3}
    for r in resps:
        if toks & set(tokenize(r)):
            return r
    return None


def build_plan(
    job: Job,
    cv: ExtractedCV,
    match: MatchBreakdown,
    gaps: GapAssessment,
    n_questions: int,
    profile: dict | None = None,
    seed: int | str = 0,
    full_name: str | None = None,
) -> list[dict]:
    """A list of {kind, topic, hint, question}. Always starts with an intro and ends with a wrap-up."""
    from app.services.job_profile import profile_for

    profile = profile or profile_for(job)
    pick = _Pick(f"{seed}|{getattr(job, 'id', '')}")
    scrub = _scrubber(cv, full_name)
    style = profile.get("style") or "technical"
    title = getattr(job, "title", None) or "this"
    resps = [_lower_first(r) for r in (profile.get("responsibilities") or []) if 8 <= len(r) <= 160]
    req_ctx = {r["name"]: r.get("context") for r in profile.get("requirements") or []}

    n = clamp_questions(n_questions, 5)
    slots = n - 3  # intro, scenario and wrap-up are always there

    # Skills to verify: strongest evidence first (used in real work), then shown by meaning, then
    # only listed. Ties are shuffled per candidate.
    def tier(i) -> int:
        if i.method == "exact" and i.snippet and i.source:
            return 0
        if i.method == "meaning":
            return 1
        return 2

    matched = [i for i in match.required.items if i.status == "match"]
    rng = pick.rng("verify")
    matched.sort(key=lambda i: (tier(i), rng.random()))
    gap_items = sorted(gaps.items, key=lambda i: (i.severity != "critical", i.status == "related"))

    # The candidate's work that best matches a responsibility (for a deeper dive).
    rel_items = [r for r in (match.relevance.items if match.relevance else []) if not r.text.startswith("The role:")]
    project = max((r for r in rel_items if r.source and r.status != "weak"), key=lambda r: r.score, default=None)

    n_gap = 0 if not gap_items else (1 if slots <= 3 else 2)
    n_gap = min(n_gap, slots, len(gap_items))
    n_project = 1 if project and slots - n_gap >= 2 else 0
    n_verify = min(slots - n_gap - n_project, len(matched))
    n_gap = min(slots - n_verify - n_project, len(gap_items))  # use spare slots on gaps if few skills matched
    n_depth = max(0, slots - n_verify - n_gap - n_project)

    plan: list[dict] = [{
        "kind": "intro", "topic": "Background",
        "hint": "Ask for a short background focused on experience relevant to this job.",
        "question": _fill(pick.one("intro", _INTRO), title=title),
    }]

    for it in matched[:n_verify]:
        topic = _display(it.skill)
        key = f"v|{it.skill}"
        snippet = scrub(it.snippet)
        if it.method == "meaning":
            section = _section_of(it.evidence)
            if section == "skills" and it.via:
                q = _fill(pick.one(key, _MEANING_SKILL), topic=topic, label=it.via)
            elif section == "certifications" and snippet:
                q = _fill(pick.one(key, _MEANING_CERT), topic=topic, snippet=snippet)
            elif snippet and _quotable(snippet):
                q = _fill(pick.one(key, _MEANING), topic=topic, snippet=snippet)
            elif it.source:
                q = _fill(pick.one(key, _MEANING_WHERE), topic=topic, where=it.source)
            else:
                q = _fill(pick.one(key, _VERIFY), topic=topic)
        elif it.source:
            q = _fill(pick.one(key, _VERIFY_CTX), topic=topic, where=it.source)
        else:
            q = _fill(pick.one(key, _VERIFY), topic=topic)
        evidence = f" The CV line: \"{snippet}\"." if snippet else ""
        plan.append({
            "kind": "verify", "topic": it.skill, "question": q,
            "hint": f"The CV shows {topic}{' in ' + it.source if it.source else ''}.{evidence} Ask them to walk through real work with it; probe depth and what they personally did.",
        })

    for it in gap_items[:n_gap]:
        resp = _resp_for(it.skill, resps)
        ctx = f", for example when you need to {resp}" if resp and len(resp) <= 90 and is_action(resp) else ""
        if it.similar_skill:
            q = _fill(pick.one(f"g|{it.skill}", _GAP_VIA), topic=_display(it.skill), via=it.similar_skill, ctx=ctx)
        else:
            q = _fill(pick.one(f"g|{it.skill}", _GAP), topic=_display(it.skill), ctx=ctx)
        why = req_ctx.get(it.skill)
        plan.append({
            "kind": "gap", "topic": it.skill, "question": q,
            "hint": (f"{it.skill} is wanted for the job but not clearly shown on the CV."
                     + (f" How the job uses it: {why}." if why else "")
                     + " Explore their experience with it, or how they would learn it. Do not say it is missing from the CV."),
        })

    if n_project and project:
        resp = _lower_first(project.text)
        plan.append({
            "kind": "project", "topic": "Relevant work",
            "question": _fill(pick.one("project", _PROJECT), where=project.source, resp=resp),
            "hint": f"Their {project.source} looks related to this responsibility: {project.text}. Dig into what they did there and how it transfers.",
        })

    depth_topic, depth_opts = _DEPTH.get(style, _DEPTH["technical"])
    for k in range(n_depth):
        plan.append({
            "kind": "depth", "topic": depth_topic,
            "question": depth_opts[(pick.rng("depth").randrange(len(depth_opts)) + k) % len(depth_opts)],
            "hint": "Ask about the most challenging relevant work they have done and the decisions they made.",
        })

    # Scenario: an AI-written situation, else a responsibility. Prefer one the CV covers least,
    # because that is where the interview learns the most; shuffled per candidate.
    scenarios = profile.get("scenarios") or []
    weak = {r.text.lower() for r in rel_items if r.status != "strong"}
    candidates = [r for r in resps if r.lower() in weak] or resps
    resp = pick.one("scenario", candidates) if candidates else None
    if scenarios:
        sc = pick.one("scenario-ai", scenarios)
        q = _fill(_SCENARIO_AI[0], scenario=sc.rstrip(".") + ".")
        hint = f"Pose this realistic scenario from the job: {sc} Ask how they would approach it."
    elif resp:
        opts = _SCENARIO.get(style, _SCENARIO["technical"]) if is_action(resp) else _SCENARIO_QUOTE
        q = _fill(pick.one("scenario-t", opts), resp=resp if is_action(resp) else resp[:1].upper() + resp[1:])
        hint = f"Pose a realistic scenario from the job: {resp}. Ask how they would approach it."
    else:
        q = _fill(_SCENARIO_NONE[0], title=title)
        hint = f"Pose a realistic problem a {title} would face and ask how they would approach it."
    plan.append({"kind": "scenario", "topic": "Role scenario", "question": q, "hint": hint})

    plan.append({
        "kind": "motivation", "topic": "Motivation",
        "question": _fill(pick.one("motivation", _MOTIVATION), title=title),
        "hint": "Ask what attracts them to the role and invite anything they want to add. This is the last question.",
    })
    return plan
