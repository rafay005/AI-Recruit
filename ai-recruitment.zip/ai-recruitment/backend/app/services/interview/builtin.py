"""The built-in interviewer: no AI, no key. It still adapts to what the candidate says.

Questions come from the plan. Follow-ups are chosen by reading the candidate's answer:
too short, a new technology mentioned, a challenge, teamwork, or a number to explain.
"""
import re

from app.models.job import Job
from app.services.cv.heuristic import parse_skills
from app.services.interview.plan import first_responsibility

REPEAT_RE = re.compile(r"\b(repeat|say that again|say it again|come again|pardon|didn'?t (hear|catch|get)|could you rephrase)\b", re.I)
SKIP_RE = re.compile(r"\b(i don'?t know|no idea|not sure|skip|pass on|next question|can we move on)\b", re.I)
CHALLENGE_RE = re.compile(r"\b(challeng\w*|difficult\w*|problem|issue|bug|deadline|failed|failure|obstacle|struggl\w*)\b", re.I)
TEAM_RE = re.compile(r"\b(team|colleague\w*|manager|stakeholder\w*|client\w*|customer\w*|we\b)", re.I)
NUMBER_RE = re.compile(r"\b\d+(?:[.,]\d+)?\s*(?:%|percent|k\b|users|customers|requests|ms|seconds|hours|days|x\b)|\b\d{3,}\b", re.I)
LEARN_RE = re.compile(r"\b(learn\w*|course|tutorial|practice|practise|study|studying|documentation|docs|mentor\w*|project|certif\w*|read|books?)\b", re.I)


def first_name(full_name: str | None) -> str:
    token = (full_name or "").strip().split(" ")[0]
    token = re.sub(r"[^A-Za-z\u00C0-\u024F'\-]", "", token)[:30]
    return token or "there"


def greeting(first: str, job: Job, company: str | None) -> str:
    where = f" at {company}" if company else ""
    return (
        f"Hello {first}, welcome, and thank you for making the time. "
        f"I'm the AI interviewer for the {job.title} role{where}. "
        "I'll ask you a few questions, one at a time, and you can answer out loud. "
        "There are no trick questions, and you can ask me to repeat anything. Let's begin."
    )


def question_text(item: dict, job: Job) -> str:
    if item.get("question"):  # written for this job and candidate by the planner
        return item["question"]
    kind, topic = item["kind"], item["topic"]
    if kind == "intro":
        return "To start, could you tell me a little about yourself and the experience that is most relevant to this role?"
    if kind == "verify":
        return (f"I can see you have worked with {topic}. Could you walk me through a project where you used it, "
                "and what you personally built or decided?")
    if kind == "gap":
        return (f"This role also involves {topic}. How much have you worked with it, "
                "and if not much, how would you get up to speed?")
    if kind == "depth":
        return "What is the most technically challenging thing you have worked on recently, and what decisions did you make?"
    if kind == "scenario":
        resp = first_responsibility(job)
        if resp:
            return f"Here is a scenario from the role: you may be asked to {resp}. How would you approach that, step by step?"
        return f"Think of a realistic problem a {job.title} would face. How would you approach solving it, step by step?"
    return ("Last question. What interests you about this role, "
            "and is there anything you would like the hiring team to know about you?")


def closing_text(first: str, reason: str = "completed") -> str:
    if reason == "candidate_ended":
        return (f"No problem, {first}. We'll wrap up here. Thank you for your time. "
                "The hiring team will review what we covered.")
    if reason == "time_limit":
        return (f"We're out of time, {first}, so let's wrap up. Thank you for the conversation. "
                "The hiring team will review it and be in touch.")
    return (f"That was my last question, {first}. Thank you, I enjoyed the conversation. "
            "The hiring team will review your interview and get back to you.")


def words(text: str) -> int:
    return len(text.split())


def is_repeat_request(answer: str) -> bool:
    return words(answer) <= 14 and bool(REPEAT_RE.search(answer))


def is_skip(answer: str) -> bool:
    return words(answer) <= 14 and bool(SKIP_RE.search(answer))


_FU = {
    "short_gap": ["Could you tell me a bit more about how you would go about it, with a concrete first step?",
                  "What would a concrete first step look like for you there?"],
    "short": ["Could you give me a specific example of that, including what your own role was?",
              "Can you make that concrete with a specific example? What exactly did you do?",
              "Could you walk me through one specific example of that, and your part in it?"],
    "gap_plan": ["What would be the very first thing you would do in your first week to get comfortable with it?",
                 "If you started next month, what would you do in your first week to get comfortable with it?"],
    "mentioned": ["You mentioned {x}. Why did you choose it, and how did it work out?",
                  "You mentioned {x}. What made it the right choice there, and what would you change now?"],
    "challenge": ["What was the hardest part of that, and how did you handle it?",
                  "Which part of that was the hardest, and what did you do when it got difficult?"],
    "number": ["How did you measure that result, and what was your own contribution to it?",
               "That's a clear result. How did you measure it, and which part of it was your own work?"],
    "team": ["How did you work with others on that, and what exactly was your part?",
             "Who else was involved, and what exactly was your part?"],
}


def pick_followup(item: dict, answer: str, topic_skill_terms: list[str], seed: int = 0) -> str | None:
    """Choose a follow-up question from the content of the answer, or None to move on.

    `seed` picks between equivalent phrasings, so candidates do not all hear the same words."""
    def say(kind: str, **kw) -> str:
        opts = _FU[kind]
        return opts[seed % len(opts)].format(**kw)

    kind = item["kind"]
    if kind == "motivation":
        return None
    n = words(answer)
    if n < 20:
        return say("short_gap") if kind == "gap" else say("short")
    if kind == "gap" and not LEARN_RE.search(answer):
        return say("gap_plan")
    mentioned = [s for s in parse_skills([], answer, []) if s.lower() not in {t.lower() for t in topic_skill_terms}]
    if mentioned:
        return say("mentioned", x=mentioned[0])
    if CHALLENGE_RE.search(answer):
        return say("challenge")
    if NUMBER_RE.search(answer):
        return say("number")
    if TEAM_RE.search(answer):
        return say("team")
    return None
