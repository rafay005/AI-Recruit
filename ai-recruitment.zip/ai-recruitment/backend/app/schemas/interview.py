from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field, field_validator


class InterviewBrief(BaseModel):
    id: int
    status: str


class TurnOut(BaseModel):
    idx: int
    role: str
    kind: str
    text: str
    created_at: datetime


class HRTurnOut(TurnOut):
    topic: str | None = None
    input_mode: str | None = None
    source: str | None = None


class InterviewCandidateOut(BaseModel):
    id: int
    status: str
    job_title: str
    company: str | None
    mode: str | None
    questions_planned: int
    questions_asked: int
    started_at: datetime | None
    completed_at: datetime | None
    max_minutes: int
    turns: list[TurnOut]
    can_answer: bool  # the interviewer asked something and is waiting
    needs_reply: bool  # the candidate answered but no reply was stored (connection dropped)


class StartIn(BaseModel):
    consent: bool = False


class AnswerIn(BaseModel):
    text: str = Field(min_length=1, max_length=4000)
    input_mode: Literal["voice", "typed"] = "typed"

    @field_validator("text")
    @classmethod
    def _clean(cls, v: str) -> str:
        v = " ".join(v.split())
        if not v:
            raise ValueError("The answer is empty")
        return v


class TurnsOut(BaseModel):
    """Result of start / answer / end: the new turns plus the current state."""

    new_turns: list[TurnOut]
    status: str
    done: bool
    questions_asked: int
    questions_planned: int


class InviteIn(BaseModel):
    questions: int | None = Field(default=None, ge=3, le=8)
    focus: str | None = Field(default=None, max_length=300)

    @field_validator("focus", mode="before")
    @classmethod
    def _blank(cls, v):
        if isinstance(v, str):
            v = " ".join(v.split())
            return v or None
        return v


class Communication(BaseModel):
    score: int
    notes: str


class SkillRating(BaseModel):
    skill: str
    rating: int | None
    evidence: str


class AnswerScore(BaseModel):
    question: str
    score: int
    comment: str


class Evaluation(BaseModel):
    source: Literal["ai", "built-in"]
    model: str | None = None
    overall: int
    label: str
    summary: str
    strengths: list[str]
    concerns: list[str]
    communication: Communication
    skills: list[SkillRating]
    answers: list[AnswerScore]
    flags: list[str]
    questions_answered: int
    questions_planned: int
    ended_early: bool
    ended_reason: str | None = None
    duration_seconds: int | None = None
    note: str | None = None


class InterviewHROut(BaseModel):
    id: int
    application_id: int
    status: str
    mode: str | None
    questions_planned: int
    questions_asked: int
    focus: str | None
    invited_at: datetime
    started_at: datetime | None
    completed_at: datetime | None
    ended_reason: str | None
    eval_status: str
    eval_error: str | None
    evaluation: Evaluation | None
    turns: list[HRTurnOut]


class InterviewChip(BaseModel):
    status: str
    score: int | None = None
    label: str | None = None
