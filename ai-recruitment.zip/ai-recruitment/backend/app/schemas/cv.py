"""Structured data extracted from a CV. Lenient on input (LLM output is messy),
strict on output (lengths clipped, wrong types coerced, empty items dropped)."""
import re
from typing import Any

from pydantic import BaseModel, Field, field_validator, model_validator


def _s(v: Any, n: int = 300, keep_lines: bool = False) -> str | None:
    if v is None:
        return None
    if isinstance(v, (list, tuple)):
        v = "\n".join(str(x) for x in v if x is not None) if keep_lines else ", ".join(
            str(x) for x in v if x is not None
        )
    if keep_lines:
        lines = [re.sub(r"[ \t]+", " ", ln).strip() for ln in str(v).splitlines()]
        v = "\n".join(ln for ln in lines if ln)
    else:
        v = re.sub(r"\s+", " ", str(v)).strip()
    if not v or v.lower() in {"null", "none", "n/a", "na", "-", "not provided"}:
        return None
    return v[:n]


class _Item(BaseModel):
    model_config = {"extra": "ignore"}


class EducationItem(_Item):
    degree: str | None = None
    field: str | None = None
    institution: str | None = None
    start: str | None = None
    end: str | None = None
    grade: str | None = None

    @field_validator("*", mode="before")
    @classmethod
    def _clip(cls, v):
        return _s(v, 200)


class ExperienceItem(_Item):
    title: str | None = None
    company: str | None = None
    start: str | None = None
    end: str | None = None
    description: str | None = None

    @field_validator("title", "company", "start", "end", mode="before")
    @classmethod
    def _clip_short(cls, v):
        return _s(v, 200)

    @field_validator("description", mode="before")
    @classmethod
    def _clip_long(cls, v):
        return _s(v, 1500, True)


class ProjectItem(_Item):
    name: str | None = None
    description: str | None = None
    technologies: list[str] = Field(default_factory=list)

    @field_validator("name", mode="before")
    @classmethod
    def _name(cls, v):
        return _s(v, 200)

    @field_validator("description", mode="before")
    @classmethod
    def _desc(cls, v):
        return _s(v, 1200, True)

    @field_validator("technologies", mode="before")
    @classmethod
    def _tech(cls, v):
        return _clean_list(v, 60, 30)


class CertificationItem(_Item):
    name: str | None = None
    issuer: str | None = None
    date: str | None = None

    @field_validator("*", mode="before")
    @classmethod
    def _clip(cls, v):
        return _s(v, 200)


def _clean_list(v: Any, item_len: int, max_items: int) -> list[str]:
    if v is None:
        return []
    if isinstance(v, str):
        v = re.split(r"[,;\n|]", v)
    out: list[str] = []
    seen: set[str] = set()
    for x in v:
        t = _s(x, item_len)
        if t and t.lower() not in seen:
            seen.add(t.lower())
            out.append(t)
        if len(out) >= max_items:
            break
    return out


def _clean_items(v: Any, max_items: int) -> list[Any]:
    if v is None:
        return []
    if isinstance(v, dict):
        v = [v]
    return [x for x in list(v)[:max_items] if isinstance(x, (dict, BaseModel))]


class ExtractedCV(BaseModel):
    model_config = {"extra": "ignore"}

    name: str | None = None
    email: str | None = None
    phone: str | None = None
    summary: str | None = None
    education: list[EducationItem] = Field(default_factory=list)
    experience: list[ExperienceItem] = Field(default_factory=list)
    skills: list[str] = Field(default_factory=list)
    projects: list[ProjectItem] = Field(default_factory=list)
    certifications: list[CertificationItem] = Field(default_factory=list)
    total_experience_years: float | None = None

    @field_validator("name", "email", "phone", mode="before")
    @classmethod
    def _short(cls, v):
        return _s(v, 120)

    @field_validator("summary", mode="before")
    @classmethod
    def _summary(cls, v):
        return _s(v, 1200)

    @field_validator("skills", mode="before")
    @classmethod
    def _skills(cls, v):
        return _clean_list(v, 60, 80)

    @field_validator("education", mode="before")
    @classmethod
    def _edu(cls, v):
        return _clean_items(v, 10)

    @field_validator("experience", mode="before")
    @classmethod
    def _exp(cls, v):
        return _clean_items(v, 20)

    @field_validator("projects", mode="before")
    @classmethod
    def _proj(cls, v):
        return _clean_items(v, 15)

    @field_validator("certifications", mode="before")
    @classmethod
    def _cert(cls, v):
        return _clean_items(v, 25)

    @field_validator("total_experience_years", mode="before")
    @classmethod
    def _years(cls, v):
        try:
            f = float(v)
        except (TypeError, ValueError):
            return None
        return round(f, 1) if 0 <= f <= 60 else None

    @model_validator(mode="after")
    def _drop_empty(self):
        self.education = [e for e in self.education if any(e.model_dump().values())]
        self.experience = [e for e in self.experience if e.title or e.company or e.description]
        self.projects = [p for p in self.projects if p.name or p.description]
        self.certifications = [c for c in self.certifications if c.name]
        return self
