from datetime import datetime

from pydantic import BaseModel

from app.schemas.cv import ExtractedCV
from app.schemas.interview import InterviewBrief


class JobBrief(BaseModel):
    id: int
    title: str
    company: str | None = None


class ApplicationOut(BaseModel):
    """What a candidate sees about their own application."""

    id: int
    job: JobBrief
    phone: str | None
    cover_note: str | None
    cv_filename: str
    cv_size: int
    analysis_status: str  # pending | processing | done | failed
    analysis_error: str | None
    analysis_note: str | None
    extraction_method: str | None  # pdf_text | docx | ocr | vlm
    analysis_model: str | None
    created_at: datetime
    analyzed_at: datetime | None
    extracted: ExtractedCV | None
    decision: str = "under_review"
    decision_note: str | None = None
    decision_at: datetime | None = None
    interview: InterviewBrief | None = None


class ApplicationListItem(BaseModel):
    """One row in the HR candidates list."""

    id: int
    job_id: int
    job_title: str
    candidate_name: str
    candidate_email: str
    cv_filename: str
    created_at: datetime
    analysis_status: str
    skills: list[str]
    total_experience_years: float | None
    extraction_method: str | None
    match_percent: int | None = None
    match_label: str | None = None
    decision: str = "under_review"


class HRApplicationDetail(ApplicationOut):
    candidate_account_name: str
    candidate_account_email: str
    parsed_text: str | None


class DecisionIn(BaseModel):
    decision: str
    note: str | None = None


class DecisionOut(BaseModel):
    decision: str
    decision_note: str | None
    decision_at: datetime | None
