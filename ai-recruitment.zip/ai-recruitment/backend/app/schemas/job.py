import re
from datetime import date, datetime
from typing import Literal

from pydantic import BaseModel, Field, field_validator, model_validator

EmploymentType = Literal["full_time", "part_time", "contract", "internship"]
WorkMode = Literal["onsite", "remote", "hybrid"]
ExperienceLevel = Literal["entry", "mid", "senior", "lead"]


def _clean_skills(values: list[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for raw in values:
        skill = re.sub(r"\s+", " ", str(raw)).strip()
        if not skill:
            continue
        if len(skill) > 60:
            raise ValueError("Each skill must be 60 characters or fewer")
        key = skill.lower()
        if key not in seen:
            seen.add(key)
            out.append(skill)
    if len(out) > 40:
        raise ValueError("A maximum of 40 skills is allowed")
    return out


class JobRequirements(BaseModel):
    """What HR types in. Used for both create and update."""

    title: str = Field(min_length=3, max_length=200)
    department: str | None = Field(default=None, max_length=120)
    location: str | None = Field(default=None, max_length=160)
    employment_type: EmploymentType = "full_time"
    work_mode: WorkMode = "onsite"
    experience_level: ExperienceLevel = "mid"
    min_experience_years: int | None = Field(default=None, ge=0, le=50)
    max_experience_years: int | None = Field(default=None, ge=0, le=50)
    education: str | None = Field(default=None, max_length=200)
    salary_min: int | None = Field(default=None, ge=0, le=100_000_000)
    salary_max: int | None = Field(default=None, ge=0, le=100_000_000)
    salary_currency: str | None = Field(default=None, max_length=8)
    show_salary: bool = False
    openings: int = Field(default=1, ge=1, le=1000)
    application_deadline: date | None = None
    required_skills: list[str] = Field(default_factory=list)
    nice_to_have_skills: list[str] = Field(default_factory=list)
    responsibilities: str | None = Field(default=None, max_length=4000)
    company_about: str | None = Field(default=None, max_length=2000)

    @field_validator("title", mode="before")
    @classmethod
    def _strip_title(cls, v):
        return v.strip() if isinstance(v, str) else v

    @field_validator(
        "department",
        "location",
        "education",
        "salary_currency",
        "responsibilities",
        "company_about",
        mode="before",
    )
    @classmethod
    def _blank_to_none(cls, v):
        if isinstance(v, str):
            v = v.strip()
            return v or None
        return v

    @field_validator("required_skills", "nice_to_have_skills")
    @classmethod
    def _skills(cls, v: list[str]) -> list[str]:
        return _clean_skills(v)

    @model_validator(mode="after")
    def _cross_checks(self):
        if not self.required_skills:
            raise ValueError("Add at least one required skill")
        if (
            self.min_experience_years is not None
            and self.max_experience_years is not None
            and self.max_experience_years < self.min_experience_years
        ):
            raise ValueError("Maximum experience cannot be less than minimum")
        if (
            self.salary_min is not None
            and self.salary_max is not None
            and self.salary_max < self.salary_min
        ):
            raise ValueError("Maximum salary cannot be less than minimum")
        if self.show_salary and self.salary_min is None and self.salary_max is None:
            raise ValueError("Enter a salary range or turn off 'show salary'")
        if self.application_deadline and self.application_deadline < date.today():
            raise ValueError("Application deadline cannot be in the past")
        return self


class GenerateJDRequest(BaseModel):
    instructions: str | None = Field(default=None, max_length=1000)

    @field_validator("instructions", mode="before")
    @classmethod
    def _blank(cls, v):
        if isinstance(v, str):
            v = v.strip()
            return v or None
        return v


class JDUpdate(BaseModel):
    jd_text: str = Field(min_length=20, max_length=20000)


class JobOut(BaseModel):
    id: int
    title: str
    department: str | None
    location: str | None
    employment_type: str
    work_mode: str
    experience_level: str
    min_experience_years: int | None
    max_experience_years: int | None
    education: str | None
    salary_min: int | None
    salary_max: int | None
    salary_currency: str | None
    show_salary: bool
    openings: int
    application_deadline: date | None
    required_skills: list[str]
    nice_to_have_skills: list[str]
    responsibilities: str | None
    company_about: str | None
    jd_text: str | None
    jd_source: str | None
    jd_edited: bool
    jd_model: str | None
    status: str
    approved_at: datetime | None
    published_at: datetime | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class JobListItem(BaseModel):
    applicant_count: int = 0
    id: int
    title: str
    department: str | None
    location: str | None
    employment_type: str
    work_mode: str
    experience_level: str
    openings: int
    application_deadline: date | None
    status: str
    published_at: datetime | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class PublicJobOut(BaseModel):
    """What a logged-in candidate may see about a published job."""

    id: int
    title: str
    company: str | None
    department: str | None
    location: str | None
    employment_type: str
    work_mode: str
    experience_level: str
    openings: int
    application_deadline: date | None
    required_skills: list[str]
    nice_to_have_skills: list[str]
    salary_min: int | None
    salary_max: int | None
    salary_currency: str | None
    jd_text: str | None
    published_at: datetime | None
