from datetime import datetime
from typing import Literal

from pydantic import BaseModel

from app.schemas.match import JobCriteria


class GapItem(BaseModel):
    skill: str
    status: Literal["missing", "related"]
    severity: Literal["critical", "trainable"]
    effort: str  # rough time to close the gap
    reason: str
    how_to_close: str
    similar_skill: str | None = None  # for "related": the similar skill the candidate has


class GapAssessment(BaseModel):
    source: Literal["built-in", "ai"]
    model: str | None = None
    verdict: Literal["none", "trainable", "critical"]
    summary: str
    items: list[GapItem]


class SkillGapOut(BaseModel):
    application_id: int
    candidate_name: str
    job: JobCriteria
    required: list[str]
    candidate_has: list[str]  # required skills the candidate has
    candidate_extra: list[str]  # other skills on the CV
    missing: list[str]  # required skills not found
    similar: list[str]  # required skills where the candidate has a similar one
    nice_missing: list[str]
    assessment: GapAssessment
    ai_available: bool
    ai_cached: bool
    generated_at: datetime | None = None


class GapSummary(BaseModel):
    verdict: Literal["none", "trainable", "critical"]
    critical: int
    trainable: int
    missing: list[str]
