from datetime import datetime
from typing import Literal

from pydantic import BaseModel


class SkillMatch(BaseModel):
    skill: str
    status: Literal["match", "related", "missing"]
    evidence: str | None = None  # where in the CV it was found
    via: str | None = None  # for "related": the similar skill the candidate has
    # How it was found: exact (the skill itself or a known alias), meaning (hybrid search
    # found experience that means the same thing), similar (a related tool or experience).
    method: Literal["exact", "meaning", "similar", "none"] = "none"
    snippet: str | None = None  # the CV line that supports it
    source: str | None = None  # where that line is: "the Chatbot project", "AI Engineer at Acme"
    score: float = 0.0  # 0..1 credit for this item
    confidence: float | None = None  # hybrid search score of the best line, 0..1


class RelevanceItem(BaseModel):
    text: str  # a responsibility of the job, or the role itself
    score: float  # 0..1
    status: Literal["strong", "partial", "weak"]
    snippet: str | None = None
    source: str | None = None


class RelevanceBlock(BaseModel):
    applicable: bool
    score: float | None = None
    items: list[RelevanceItem] = []


class SkillsBlock(BaseModel):
    total: int
    matched: int
    related: int
    missing: int
    score: float  # 0..1
    items: list[SkillMatch]


class ExperienceBlock(BaseModel):
    applicable: bool
    status: Literal["meets", "below", "unknown", "na"]
    required_min: int | None = None
    required_max: int | None = None
    candidate_years: float | None = None
    score: float | None = None


class EducationBlock(BaseModel):
    applicable: bool
    status: Literal["meets", "below", "unknown", "na"]
    required: str | None = None
    candidate: str | None = None
    score: float | None = None


class MatchBreakdown(BaseModel):
    overall: int  # 0..100
    label: str
    required: SkillsBlock
    nice_to_have: SkillsBlock | None
    experience: ExperienceBlock
    education: EducationBlock
    relevance: RelevanceBlock = RelevanceBlock(applicable=False)
    weights: dict[str, float]  # effective weights in percent, summing to 100
    search_mode: Literal["hybrid", "keyword"] = "keyword"
    role_family: str | None = None


class GapSummaryLite(BaseModel):
    verdict: Literal["none", "trainable", "critical"]
    critical: int
    trainable: int
    missing: list[str]


class InterviewChipLite(BaseModel):
    status: str
    score: int | None = None
    label: str | None = None


class RankedCandidate(BaseModel):
    rank: int
    application_id: int
    candidate_name: str
    candidate_email: str
    years: float | None
    applied_at: datetime
    match: MatchBreakdown
    gap: GapSummaryLite | None = None
    decision: str = "under_review"
    interview: InterviewChipLite | None = None


class UnrankedCandidate(BaseModel):
    application_id: int
    candidate_name: str
    analysis_status: str
    reason: str


class JobCriteria(BaseModel):
    id: int
    title: str
    required_skills: list[str]
    nice_to_have_skills: list[str]
    min_experience_years: int | None
    max_experience_years: int | None
    education: str | None


class RankingOut(BaseModel):
    job: JobCriteria
    ranked: list[RankedCandidate]
    unranked: list[UnrankedCandidate]


class CandidateMatchOut(BaseModel):
    job: JobCriteria
    rank: int | None
    total_ranked: int
    match: MatchBreakdown | None
    reason: str | None = None
