Phase 6 test (run from the backend folder, venv active):

  set DATABASE_URL=sqlite:///./p6.db
  set SECRET_KEY=k
  set LLM_PROVIDER=template
  set PYTHONPATH=.
  alembic upgrade head
  python tests\test_phase6.py
  python tests\test_hybrid.py     (job understanding, hybrid ranking, per-candidate interviews)
  python tests\test_automation.py (hands-free hiring thresholds, first come first served, dashboard insights)

Demo data for trying the dashboard (writes to your real DATABASE_URL, under @airecruit-demo.example.com accounts only):

  python scripts\seed_demo.py            create or reset; logins go to scripts\DEMO_ACCOUNTS.md
  python scripts\seed_demo.py --remove   delete it

It prints PASS/FAIL per check and "FAILURES: 0" at the end. It uses a throwaway SQLite file, not your PostgreSQL data.
