"""Hands-free hiring + insights dashboard. Run like test_phase6.py (see README), on a fresh SQLite DB."""
import uuid
from datetime import date, timedelta

from fastapi.testclient import TestClient

from app.db.session import SessionLocal
from app.main import app
from app.models.application import Application
from app.models.automation import AutomationEvent
from app.models.interview import Interview
from app.models.user import User

fails = 0


def ok(label, cond, extra=""):
    global fails
    print(("PASS " if cond else "FAIL ") + label + (f"  [{str(extra)[:300]}]" if (extra and not cond) else ""))
    if not cond:
        fails += 1


c = TestClient(app)


def reg(email, role, company=None, name=None):
    r = c.post("/api/auth/register", json={"full_name": name or "U " + email[:4], "email": email, "password": "password123", "role": role, "company": company})
    assert r.status_code == 201, r.text


def login(email):
    return {"Authorization": "Bearer " + c.post("/api/auth/login", data={"username": email, "password": "password123"}).json()["access_token"]}


tag = uuid.uuid4().hex[:6]
hr, hr2 = f"hr-{tag}@x.com", f"hr2-{tag}@x.com"
reg(hr, "hr", "Acme"); reg(hr2, "hr", "Other")
H, H2 = login(hr), login(hr2)
names = ["Amina", "Bilal", "Chen", "Dana", "Eli", "Farah"]
cands = {n: f"{n.lower()}-{tag}@x.com" for n in names}
for n, e in cands.items():
    reg(e, "candidate", name=f"{n} Test")
tok = {n: login(e) for n, e in cands.items()}

job = {"title": "Backend Python Developer", "location": "Remote", "required_skills": ["Python", "FastAPI", "PostgreSQL"],
       "nice_to_have_skills": [], "openings": 1, "min_experience_years": 2, "education": "BS Computer Science",
       "responsibilities": "- Build REST APIs with FastAPI\n- Design PostgreSQL schemas",
       "application_deadline": str(date.today() + timedelta(days=30))}
jid = c.post("/api/hr/jobs", json=job, headers=H).json()["id"]
for step in ("generate-jd", "approve", "publish"):
    c.post(f"/api/hr/jobs/{jid}/{step}", headers=H)

strong = {"skills": ["Python", "FastAPI", "PostgreSQL", "Docker"], "total_experience_years": 4, "education": [{"degree": "BS", "field": "Computer Science"}],
          "experience": [{"title": "Backend Developer", "company": "Corp", "description": "Built REST APIs with FastAPI and PostgreSQL."}]}
weak = {"skills": ["Excel", "Accounting"], "total_experience_years": 1, "education": [{"degree": "BCom"}],
        "experience": [{"title": "Accountant", "company": "Ledger", "description": "Prepared invoices and payroll."}]}

db = SessionLocal()


def seed(name, ex, status="done"):
    uid = db.query(User).filter(User.email == cands[name]).one().id
    a = Application(job_id=jid, candidate_id=uid, cv_filename="cv.pdf", cv_stored_name=uuid.uuid4().hex + ".pdf",
                    cv_content_type="application/pdf", cv_size=10, analysis_status=status,
                    extracted={**ex, "name": f"{name} Test"} if status == "done" else None, parsed_text="")
    db.add(a); db.commit()
    return a.id


ids = {"Amina": seed("Amina", strong), "Bilal": seed("Bilal", weak), "Chen": seed("Chen", strong), "Dana": seed("Dana", strong)}
db.close()

# ------------------------------------------------------------------ settings
g = c.get(f"/api/hr/jobs/{jid}/automation", headers=H).json()
ok("automation is off by default", g["enabled"] is False and g["cv_threshold"] == 60 and g["interview_threshold"] == 65)
ok("preview lists every analysed CV score", len(g["cv_scores"]) == 4, g["cv_scores"])
ok("other HR cannot see it", c.get(f"/api/hr/jobs/{jid}/automation", headers=H2).status_code == 404)
ok("bad threshold -> 422", c.put(f"/api/hr/jobs/{jid}/automation", json={"enabled": True, "cv_threshold": 140, "interview_threshold": 50}, headers=H).status_code == 422)
ok("run while off -> 409", c.post(f"/api/hr/jobs/{jid}/automation/run", headers=H).status_code == 409)

# HR decides Dana by hand first: automation must not touch her.
c.put(f"/api/hr/applications/{ids['Dana']}/decision", json={"decision": "shortlisted", "note": "Strong referral"}, headers=H)

r = c.put(f"/api/hr/jobs/{jid}/automation", json={"enabled": True, "cv_threshold": 60, "interview_threshold": 50, "reject_below_cv": True, "questions": 3}, headers=H)
d = r.json()
ok("turning it on runs the backlog", r.status_code == 200 and d["last_run"]["invited"] == 2 and d["last_run"]["cv_rejected"] == 1, d.get("last_run"))
apps = {a["id"]: a for a in c.get(f"/api/hr/applications?job_id={jid}", headers=H).json()}
ok("strong CVs moved to interview", apps[ids["Amina"]]["decision"] == "interview" and apps[ids["Chen"]]["decision"] == "interview")
ok("weak CV rejected", apps[ids["Bilal"]]["decision"] == "rejected")
ok("HR's manual decision is never overridden", apps[ids["Dana"]]["decision"] == "shortlisted")
mine = c.get("/api/applications/mine", headers=tok["Amina"]).json()[0]
ok("candidate sees the interview invitation and a friendly note", mine["interview"] and mine["interview"]["status"] == "invited" and "invited" in (mine["decision_note"] or "").lower(), mine)
bilal = c.get("/api/applications/mine", headers=tok["Bilal"]).json()[0]
ok("rejected candidate sees no score or threshold", bilal["decision"] == "rejected" and "%" not in (bilal["decision_note"] or ""), bilal["decision_note"])
iv = c.get(f"/api/hr/applications/{ids['Amina']}/interview", headers=H).json()
ok("interview uses the job's question count", iv["questions_planned"] == 3)
ok("events logged with score and threshold", all(e["threshold"] == 60 and e["score"] is not None for e in d["events"] if e["action"] in ("invited", "cv_rejected")) and len(d["events"]) == 3, d["events"])
ok("running again does nothing new", sum(c.post(f"/api/hr/jobs/{jid}/automation/run", headers=H).json()["last_run"].values()) == 0)

# A new application arrives while automation is on (the pipeline hook).
from app.services.automation import after_cv_analysis  # noqa: E402

db = SessionLocal(); ids["Eli"] = seed("Eli", strong); db.close()
after_cv_analysis(ids["Eli"])
ok("new CV is handled as soon as it is analysed", c.get(f"/api/hr/applications/{ids['Eli']}", headers=H).json()["decision"] == "interview")


# ------------------------------------------------------------------ interview stage, first come first served
def take_interview(name, answer):
    iid = c.get("/api/applications/mine", headers=tok[name]).json()[0]["interview"]["id"]
    c.post(f"/api/interviews/{iid}/start", json={"consent": True}, headers=tok[name])
    for _ in range(20):
        g = c.get(f"/api/interviews/{iid}", headers=tok[name]).json()
        if g["status"] == "completed":
            break
        c.post(f"/api/interviews/{iid}/answer", json={"text": answer}, headers=tok[name])
    return iid


good = ("At my last job I designed and built REST APIs with FastAPI and PostgreSQL for 50000 users. I owned the schema design, "
        "reduced latency by 40 percent with caching, and deployed everything with Docker while mentoring two juniors.")
# Chen applied after Amina but finishes first -> Chen takes the single opening.
take_interview("Chen", good)
chen = c.get(f"/api/hr/applications/{ids['Chen']}", headers=H).json()
ok("passing interview -> selected automatically", chen["decision"] == "hired", chen["decision"])
ok("selected candidate sees 'Selected' note", "selected" in (c.get("/api/applications/mine", headers=tok["Chen"]).json()[0]["decision_note"] or "").lower())
take_interview("Amina", good)
amina = c.get(f"/api/hr/applications/{ids['Amina']}", headers=H).json()
ok("next passer after the opening is filled -> rejected (positions filled)", amina["decision"] == "rejected" and "filled" in (amina["decision_note"] or ""), amina["decision_note"])
take_interview("Eli", "ok")
ok("weak interview -> rejected", c.get(f"/api/hr/applications/{ids['Eli']}", headers=H).json()["decision"] == "rejected")
db = SessionLocal()
acts = [e.action for e in db.query(AutomationEvent).filter(AutomationEvent.job_id == jid).order_by(AutomationEvent.id)]
ok("audit trail of every step", acts.count("selected") == 1 and "openings_full" in acts and "interview_rejected" in acts, acts)
ok("never more selected than openings", db.query(Application).filter(Application.job_id == jid, Application.decision == "hired").count() == 1)
ok("automated decisions are marked as such", db.get(Application, ids["Chen"]).decision_source == "auto" and db.get(Application, ids["Dana"]).decision_source == "hr")
db.close()

# Automation off -> nothing happens on its own
c.put(f"/api/hr/jobs/{jid}/automation", json={"enabled": False, "cv_threshold": 60, "interview_threshold": 50}, headers=H)
db = SessionLocal(); ids["Farah"] = seed("Farah", strong); db.close()
after_cv_analysis(ids["Farah"])
ok("automation off -> candidate stays under review", c.get(f"/api/hr/applications/{ids['Farah']}", headers=H).json()["decision"] == "under_review")

# ------------------------------------------------------------------ dashboard
ins = c.get("/api/hr/dashboard/insights", headers=H).json()
k = ins["kpis"]
ok("insights: KPIs", k["total_applicants"] == 6 and k["selected"] == 1 and k["automated_decisions"] == 4 and k["automation_rate"] is not None and k["avg_match"] is not None, k)
ok("insights: funnel is monotone", [f["count"] for f in ins["funnel"]] == sorted([f["count"] for f in ins["funnel"]], reverse=True) and ins["funnel"][0]["count"] == 6, ins["funnel"])
ok("insights: 30-day timeline", len(ins["timeline"]) == 30 and sum(t["applications"] for t in ins["timeline"]) == 6)
ok("insights: histograms", sum(b["count"] for b in ins["match_histogram"]) == 6 and len(ins["match_histogram"]) == 10 and sum(b["count"] for b in ins["interview_histogram"]) == 3)
ok("insights: per-job row with automation status", ins["jobs"][0]["selected"] == 1 and ins["jobs"][0]["auto_enabled"] is False and ins["jobs"][0]["best_candidate"])
ok("insights: top candidates and skills", ins["top_candidates"] and ins["skills"][0]["coverage"] is not None, ins["skills"])
ok("insights: activity feed mixes automation and applications", any(a["auto"] for a in ins["activity"]) and any(a["kind"] == "applied" for a in ins["activity"]))
ok("insights: other HR sees none of it", c.get("/api/hr/dashboard/insights", headers=H2).json()["kpis"]["total_applicants"] == 0)

# ------------------------------------------------------------------ pipeline board (manual moves)
b = c.get(f"/api/hr/pipeline?job_id={jid}", headers=H).json()
ok("board: 5 stages and every candidate as a card", [s["key"] for s in b["stages"]] == ["under_review", "shortlisted", "interview", "hired", "rejected"] and len(b["cards"]) == 6, len(b["cards"]))
ok("board: ranked cards carry rank and match", all(x["rank"] and x["match"] is not None for x in b["cards"]))
ok("board: all-jobs view works, other HR gets 404", len(c.get("/api/hr/pipeline", headers=H).json()["cards"]) == 6 and c.get(f"/api/hr/pipeline?job_id={jid}", headers=H2).status_code == 404)
fid = ids["Farah"]
mv = lambda body, h=H: c.put(f"/api/hr/applications/{fid}/stage", json=body, headers=h)  # noqa: E731
r = mv({"stage": "interview"}).json()
ok("drag to Interview creates the invitation", r["created_interview"] and r["card"]["stage"] == "interview" and r["card"]["interview_status"] == "invited" and r["card"]["decision_source"] == "hr", r)
ok("candidate sees the invitation", c.get("/api/applications/mine", headers=tok["Farah"]).json()[0]["interview"]["status"] == "invited")
r = mv({"stage": "under_review", "cancel_interview": True}).json()
ok("undo: back to Under review cancels the untaken invitation", r["cancelled_interview"] and r["card"]["interview_status"] is None and r["card"]["decision_source"] is None, r)
r = mv({"stage": "hired"}).json()
ok("selecting beyond the openings warns but still selects", r["card"]["stage"] == "hired" and r["warning"] and "already filled" in r["warning"], r)
r = mv({"stage": "rejected", "note": "We chose a candidate with more API experience."}).json()
ok("reject with a note", r["card"]["stage"] == "rejected" and c.get(f"/api/hr/applications/{fid}", headers=H).json()["decision_note"].startswith("We chose"))
ok("unknown stage -> 422, other HR -> 404", mv({"stage": "maybe"}).status_code == 422 and mv({"stage": "hired"}, H2).status_code == 404)
aid = ids["Amina"]
c.put(f"/api/hr/applications/{aid}/stage", json={"stage": "interview"}, headers=H)
r = c.put(f"/api/hr/applications/{aid}/stage", json={"stage": "rejected", "cancel_interview": True}, headers=H)
ok("a finished interview cannot be cancelled (409)", r.status_code == 409)
c.put(f"/api/hr/jobs/{jid}/automation", json={"enabled": True, "cv_threshold": 10, "interview_threshold": 10}, headers=H)
ok("automation never overrides a manual move", c.get(f"/api/hr/applications/{fid}", headers=H).json()["decision"] == "rejected")
acts = c.get("/api/hr/dashboard/insights", headers=H).json()["activity"]
ok("manual moves appear in the activity feed as manual", any(a["kind"] == "manual_move" and a["auto"] is False for a in acts))

print("\nFAILURES:", fails)
