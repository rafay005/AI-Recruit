"""Job understanding, hybrid ranking and per-candidate interviews. Run like test_phase6.py (see README)."""
from app.schemas.cv import ExtractedCV
from app.schemas.gap import GapAssessment
from app.services.interview.plan import build_plan
from app.services.job_profile import built_in_profile, is_action, responsibilities_of
from app.services.matching import match_cv
from app.services.search import embeddings
from app.services.search.bm25 import BM25, tokenize
from app.services.search.hybrid import cv_index
from app.services.skillgap import built_in_assessment

fails = 0


def ok(label, cond, extra=""):
    global fails
    print(("PASS " if cond else "FAIL ") + label + (f"  [{str(extra)[:300]}]" if (extra and not cond) else ""))
    if not cond:
        fails += 1


class Job:
    def __init__(self, **kw):
        base = dict(id=1, title="", department=None, experience_level="mid", required_skills=[], nice_to_have_skills=[],
                    responsibilities=None, jd_text=None, education=None, min_experience_years=None,
                    max_experience_years=None, profile=None, profile_signature=None, owner=None)
        base.update(kw)
        self.__dict__.update(base)


video_job = Job(
    id=3, title="AI Video Generator",
    required_skills=["artificial intellligence", "video editing", "video creation", "good speaking skills"],
    nice_to_have_skills=["html"],
    responsibilities=("We need a freelancer to create AI-generated videos for physiotherapy exercises, using the same characters "
                      "across 100+ videos. The ideal freelancer will help develop a consistent visual style and ensure the "
                      "final videos are clear and easy to follow."),
)
py_job = Job(
    id=1, title="Senior Python Developer", required_skills=["Python", "FastAPI", "PostgreSQL"],
    responsibilities=("## Senior Python Developer\n\nWe are looking for an experienced developer.\n\n**Responsibilities:**\n"
                      "- Build and optimize RESTful APIs and backend services.\n- Work with databases such as PostgreSQL or MySQL.\n"
                      "\n**Requirements:**\n- 5+ years of Python.\n\n**What We Offer:**\n- Competitive pay."),
)
ml_cv = ExtractedCV.model_validate({
    "name": "Sam Lee", "summary": "Machine learning engineer building LLM applications and computer vision systems.",
    "skills": ["Python", "PyTorch", "LangChain", "Flask", "MySQL", "Docker"],
    "experience": [{"title": "ML Engineer", "company": "SecretCorp", "description":
                    "Built an LLM chatbot with RAG over company documents at SecretCorp.\nServed models behind Flask REST APIs backed by MySQL."}],
    "projects": [{"name": "Defect detector (Full-Stack", "description": "Trained a YOLO model to detect defects on a factory line.", "technologies": ["PyTorch"]}],
    "total_experience_years": 3})
video_cv = ExtractedCV.model_validate({
    "name": "Nora Diaz", "summary": "Video editor and content creator producing YouTube and social media videos.",
    "skills": ["Premiere Pro", "After Effects", "DaVinci Resolve", "Runway", "Public Speaking"],
    "experience": [{"title": "Video Editor", "company": "MediaHouse", "description":
                    "Edited 300+ short-form videos for brand clients.\nCreated explainer animations and motion graphics.\n"
                    "Used Runway and Pika to generate AI video shots for campaigns.\nHosted a weekly live stream and presented to clients."}],
    "total_experience_years": 4})
acct_cv = ExtractedCV.model_validate({
    "name": "Kim Park", "summary": "Accountant focused on audits and tax.", "skills": ["Excel", "QuickBooks", "Auditing"],
    "experience": [{"title": "Senior Accountant", "company": "Ledger LLP", "description": "Prepared monthly financial statements.\nManaged payroll and vendor invoices."}],
    "total_experience_years": 6})

# ------------------------------------------------------------------ keyword layer
ok("tokenize drops stop words and plurals", tokenize("Building the REST APIs and pipelines") == ["building", "rest", "apis", "pipeline"] or "pipeline" in tokenize("pipelines"), tokenize("Building the REST APIs and pipelines"))
bm = BM25(["edited short videos for clients", "prepared financial statements", "video editing in premiere pro"])
s = bm.scores("video editing")
ok("BM25 ranks the matching document first", s[2] > s[0] > s[1], s)

# ------------------------------------------------------------------ understanding the job post
resps = responsibilities_of(py_job)
ok("responsibilities: headings, requirements and benefits are left out", resps == ["Build and optimize RESTful APIs and backend services", "Work with databases such as PostgreSQL or MySQL"], resps)
vresps = responsibilities_of(video_job)
ok("responsibilities from prose: lead-ins removed, actions kept", vresps[0].startswith("Create AI-generated videos") and any(r.startswith("Develop a consistent visual style") for r in vresps), vresps)
ok("is_action", is_action("Build APIs") and not is_action("The videos should be clear") and not is_action("Working with clients"))
vp = built_in_profile(video_job)
reqs = {r["name"]: r for r in vp["requirements"]}
ok("broad capabilities are conceptual, named tools are not",
   reqs["video editing"]["conceptual"] and reqs["good speaking skills"]["conceptual"] and reqs["artificial intellligence"]["conceptual"]
   and not reqs["html"]["conceptual"] and not {r["name"]: r for r in built_in_profile(py_job)["requirements"]}["FastAPI"]["conceptual"])
ok("requirements are expanded into their meaning", "Premiere" in reqs["video editing"]["description"] and "machine learning" in reqs["artificial intellligence"]["description"])
ok("the job title never leaks into a requirement's search query", all("Video Generator" not in r["description"] for r in vp["requirements"]))
ok("FastAPI's query names its siblings", "Flask" in {r["name"]: r for r in built_in_profile(py_job)["requirements"]}["FastAPI"]["description"])

semantic = embeddings.available()
print(f"(semantic model available: {semantic})")
if semantic:
    ok("role family: video job is creative, python job is technical", vp["style"] == "creative" and built_in_profile(py_job)["style"] == "technical", (vp["role_families"], built_in_profile(py_job)["role_families"]))

    # ------------------------------------------------------------------ hybrid matching
    mv = match_cv(video_job, video_cv, None)
    mm = match_cv(video_job, ml_cv, None)
    ma = match_cv(video_job, acct_cv, None)
    items = {i.skill: i for i in mv.required.items}
    ok("hybrid mode is used", mv.search_mode == "hybrid")
    ok("'video editing' matched by meaning, with the CV line as evidence", items["video editing"].status == "match" and items["video editing"].method == "meaning" and "edit" in (items["video editing"].snippet or "").lower(), items["video editing"])
    ok("typo 'artificial intellligence' still understood (AI CV)", {i.skill: i for i in mm.required.items}["artificial intellligence"].status == "match")
    ok("ML CV does not get 'video editing' from 'video'-free ML work", {i.skill: i for i in mm.required.items}["video editing"].status == "missing")
    ok("ranking follows meaning: video editor > ML engineer > accountant for the video job", mv.overall > mm.overall > ma.overall, (mv.overall, mm.overall, ma.overall))
    mp_ml, mp_v = match_cv(py_job, ml_cv, None), match_cv(py_job, video_cv, None)
    ok("...and ML engineer > video editor for the Python job", mp_ml.overall > mp_v.overall, (mp_ml.overall, mp_v.overall))
    fi = {i.skill: i for i in mp_ml.required.items}
    ok("named tool: Flask gives FastAPI only partial credit", fi["FastAPI"].status == "related" and fi["FastAPI"].score == 0.5, fi["FastAPI"])
    ok("known sibling: MySQL counts as similar to PostgreSQL", fi["PostgreSQL"].status == "related" and fi["PostgreSQL"].via == "MySQL", fi["PostgreSQL"])
    ok("exact match points at the real line that uses it", fi["Python"].status == "match" and fi["Python"].method == "exact")
    ok("relevance: responsibilities are compared with the candidate's work", mp_ml.relevance.applicable and mp_ml.relevance.score > match_cv(py_job, acct_cv, None).relevance.score)
    ok("relevance is a weighted part of the score", "relevance" in mp_ml.weights)
    ok("experience source never names the employer", all("SecretCorp" not in (c.source or "") for c in cv_index(ml_cv, None).chunks))
    ok("truncated project names are cleaned", any(c.source == "the Defect detector project" for c in cv_index(ml_cv, None).chunks))

    # ------------------------------------------------------------------ interviews differ per job and per candidate
    def plan(job, cv, seed, n=6):
        m = match_cv(job, cv, None)
        return build_plan(job, cv, m, built_in_assessment(job, cv, None, m), n, seed=seed, full_name=cv.name)

    pv, pm = plan(video_job, video_cv, 1), plan(video_job, ml_cv, 2)
    qv, qm = [p["question"] for p in pv], [p["question"] for p in pm]
    ok("plan: intro first, scenario then wrap-up last", pv[0]["kind"] == "intro" and pv[-2]["kind"] == "scenario" and pv[-1]["kind"] == "motivation")
    ok("different candidates for the same job get different questions", len(set(qv[1:-1]) & set(qm[1:-1])) == 0, (qv, qm))
    ok("questions are built from the job's own responsibilities", any("physiotherapy" in q or "visual style" in q for q in qv), qv)
    ok("questions use the candidate's own evidence", any("Video Editor" in q or "Public Speaking" in q for q in qv), qv)
    ok("ML candidate is probed on the video gap", any(p["kind"] == "gap" and "video" in p["topic"] for p in pm), [p["topic"] for p in pm])
    ok("creative role -> creative scenario wording", "brief" in pv[-2]["question"] or "quality" in pv[-2]["question"] or "client" in pv[-2]["question"] or "role" in pv[-2]["question"], pv[-2]["question"])
    pm2 = plan(video_job, ml_cv, 99)
    ok("same CV, different seed -> wording varies", [p["question"] for p in pm2] != qm)
    ok("same seed -> same plan (stable)", [p["question"] for p in plan(video_job, ml_cv, 2)] == qm)
    pj = plan(py_job, ml_cv, 2)
    ok("same candidate, different job -> different questions", len(set(p["question"] for p in pj[1:-1]) & set(qm[1:-1])) == 0)
    allq = " ".join(p["question"] + p["hint"] for p in pv + pm + pj)
    ok("employer and candidate names never appear in questions or hints", all(x not in allq for x in ("SecretCorp", "MediaHouse", "Sam", "Nora", "Lee", "Diaz")), allq[:300])
    ok("plan size is respected", len(plan(video_job, video_cv, 1, n=3)) == 3 and len(plan(video_job, video_cv, 1, n=8)) == 8)
else:
    print("SKIP semantic checks: " + str(embeddings.unavailable_reason()))
    m = match_cv(py_job, ml_cv, None)
    ok("keyword-only fallback still ranks", m.search_mode == "keyword" and m.overall > 0)

# keyword-only mode works without the model
from app.core.config import settings  # noqa: E402
import app.services.search.embeddings as E  # noqa: E402

saved = (E._model, E._failed)
E._model, E._failed = None, "off for test"
mk = match_cv(py_job, ml_cv, "Python Flask MySQL")
ok("keyword fallback: exact skills still match, no relevance part", mk.search_mode == "keyword" and {i.skill: i for i in mk.required.items}["Python"].status == "match" and "relevance" not in mk.weights, mk.weights)
pk = build_plan(py_job, ml_cv, mk, GapAssessment(source="built-in", verdict="none", summary="", items=[]), 5, seed=3)
ok("keyword fallback: interview plan still built", len(pk) == 5 and all(p.get("question") for p in pk))
E._model, E._failed = saved

print("\nFAILURES:", fails)
