--
-- PostgreSQL database dump
--

\restrict eJQcBmoHwZhTQ2pd7PYekzn51huanB36nJW30SShQo5PRyW4t6MMD15mgcHilh0

-- Dumped from database version 14.23
-- Dumped by pg_dump version 14.23

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: userrole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.userrole AS ENUM (
    'HR',
    'CANDIDATE'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: applications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.applications (
    id integer NOT NULL,
    job_id integer NOT NULL,
    candidate_id integer NOT NULL,
    phone character varying(40),
    cover_note text,
    cv_filename character varying(200) NOT NULL,
    cv_stored_name character varying(80) NOT NULL,
    cv_content_type character varying(100) NOT NULL,
    cv_size integer NOT NULL,
    analysis_status character varying(20) NOT NULL,
    analysis_started_at timestamp with time zone,
    analyzed_at timestamp with time zone,
    analysis_error character varying(400),
    analysis_note character varying(400),
    extraction_method character varying(30),
    analysis_model character varying(80),
    parsed_text text,
    extracted json,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    decision character varying(20) DEFAULT 'under_review'::character varying NOT NULL,
    decision_note character varying(500),
    decision_at timestamp with time zone,
    gap_assessment json,
    gap_signature character varying(64),
    gap_model character varying(80),
    gap_generated_at timestamp with time zone,
    decision_source character varying(10),
    match_score integer
);


--
-- Name: applications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.applications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: applications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.applications_id_seq OWNED BY public.applications.id;


--
-- Name: automation_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_events (
    id integer NOT NULL,
    job_id integer NOT NULL,
    application_id integer,
    action character varying(30) NOT NULL,
    score integer,
    threshold integer,
    detail character varying(400),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: automation_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.automation_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: automation_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.automation_events_id_seq OWNED BY public.automation_events.id;


--
-- Name: interview_turns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interview_turns (
    id integer NOT NULL,
    interview_id integer NOT NULL,
    idx integer NOT NULL,
    role character varying(12) NOT NULL,
    kind character varying(20) NOT NULL,
    topic character varying(120),
    text text NOT NULL,
    input_mode character varying(10),
    source character varying(12),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: interview_turns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.interview_turns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: interview_turns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.interview_turns_id_seq OWNED BY public.interview_turns.id;


--
-- Name: interviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interviews (
    id integer NOT NULL,
    application_id integer NOT NULL,
    status character varying(20) NOT NULL,
    mode character varying(20),
    questions_planned integer NOT NULL,
    focus character varying(300),
    plan json,
    followups_used integer NOT NULL,
    invited_at timestamp with time zone DEFAULT now() NOT NULL,
    consent_at timestamp with time zone,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    ended_reason character varying(30),
    eval_status character varying(20) NOT NULL,
    evaluation json,
    eval_model character varying(80),
    eval_error character varying(300),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: interviews_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.interviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: interviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.interviews_id_seq OWNED BY public.interviews.id;


--
-- Name: jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jobs (
    id integer NOT NULL,
    owner_id integer NOT NULL,
    title character varying(200) NOT NULL,
    department character varying(120),
    location character varying(160),
    employment_type character varying(30) NOT NULL,
    work_mode character varying(20) NOT NULL,
    experience_level character varying(20) NOT NULL,
    min_experience_years integer,
    max_experience_years integer,
    education character varying(200),
    salary_min integer,
    salary_max integer,
    salary_currency character varying(8),
    show_salary boolean NOT NULL,
    openings integer NOT NULL,
    application_deadline date,
    required_skills json NOT NULL,
    nice_to_have_skills json NOT NULL,
    responsibilities text,
    company_about text,
    jd_text text,
    jd_source character varying(20),
    jd_edited boolean NOT NULL,
    jd_model character varying(80),
    status character varying(20) NOT NULL,
    approved_at timestamp with time zone,
    published_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    profile json,
    profile_signature character varying(64),
    auto_enabled boolean DEFAULT false NOT NULL,
    auto_cv_threshold integer DEFAULT 60 NOT NULL,
    auto_interview_threshold integer DEFAULT 65 NOT NULL,
    auto_reject_below_cv boolean DEFAULT true NOT NULL,
    auto_questions integer DEFAULT 5 NOT NULL
);


--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: text_embeddings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.text_embeddings (
    key character varying(64) NOT NULL,
    model character varying(120) NOT NULL,
    vector bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    full_name character varying(120) NOT NULL,
    email character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    role public.userrole NOT NULL,
    company character varying(160),
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: applications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applications ALTER COLUMN id SET DEFAULT nextval('public.applications_id_seq'::regclass);


--
-- Name: automation_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_events ALTER COLUMN id SET DEFAULT nextval('public.automation_events_id_seq'::regclass);


--
-- Name: interview_turns id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_turns ALTER COLUMN id SET DEFAULT nextval('public.interview_turns_id_seq'::regclass);


--
-- Name: interviews id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interviews ALTER COLUMN id SET DEFAULT nextval('public.interviews_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: applications applications_cv_stored_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_cv_stored_name_key UNIQUE (cv_stored_name);


--
-- Name: applications applications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_pkey PRIMARY KEY (id);


--
-- Name: automation_events automation_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_events
    ADD CONSTRAINT automation_events_pkey PRIMARY KEY (id);


--
-- Name: interview_turns interview_turns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_turns
    ADD CONSTRAINT interview_turns_pkey PRIMARY KEY (id);


--
-- Name: interviews interviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT interviews_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: text_embeddings text_embeddings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.text_embeddings
    ADD CONSTRAINT text_embeddings_pkey PRIMARY KEY (key);


--
-- Name: applications uq_application_job_candidate; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT uq_application_job_candidate UNIQUE (job_id, candidate_id);


--
-- Name: interview_turns uq_turn_interview_idx; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_turns
    ADD CONSTRAINT uq_turn_interview_idx UNIQUE (interview_id, idx);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_applications_analysis_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_applications_analysis_status ON public.applications USING btree (analysis_status);


--
-- Name: ix_applications_candidate_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_applications_candidate_id ON public.applications USING btree (candidate_id);


--
-- Name: ix_applications_decision; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_applications_decision ON public.applications USING btree (decision);


--
-- Name: ix_applications_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_applications_id ON public.applications USING btree (id);


--
-- Name: ix_applications_job_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_applications_job_id ON public.applications USING btree (job_id);


--
-- Name: ix_automation_events_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_events_action ON public.automation_events USING btree (action);


--
-- Name: ix_automation_events_application_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_events_application_id ON public.automation_events USING btree (application_id);


--
-- Name: ix_automation_events_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_events_created_at ON public.automation_events USING btree (created_at);


--
-- Name: ix_automation_events_job_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_events_job_id ON public.automation_events USING btree (job_id);


--
-- Name: ix_interview_turns_interview_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_interview_turns_interview_id ON public.interview_turns USING btree (interview_id);


--
-- Name: ix_interviews_application_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_interviews_application_id ON public.interviews USING btree (application_id);


--
-- Name: ix_interviews_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_interviews_id ON public.interviews USING btree (id);


--
-- Name: ix_interviews_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_interviews_status ON public.interviews USING btree (status);


--
-- Name: ix_jobs_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_jobs_id ON public.jobs USING btree (id);


--
-- Name: ix_jobs_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_jobs_owner_id ON public.jobs USING btree (owner_id);


--
-- Name: ix_jobs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_jobs_status ON public.jobs USING btree (status);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: applications applications_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: applications applications_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.jobs(id) ON DELETE CASCADE;


--
-- Name: automation_events automation_events_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_events
    ADD CONSTRAINT automation_events_application_id_fkey FOREIGN KEY (application_id) REFERENCES public.applications(id) ON DELETE CASCADE;


--
-- Name: automation_events automation_events_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_events
    ADD CONSTRAINT automation_events_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.jobs(id) ON DELETE CASCADE;


--
-- Name: interview_turns interview_turns_interview_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interview_turns
    ADD CONSTRAINT interview_turns_interview_id_fkey FOREIGN KEY (interview_id) REFERENCES public.interviews(id) ON DELETE CASCADE;


--
-- Name: interviews interviews_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT interviews_application_id_fkey FOREIGN KEY (application_id) REFERENCES public.applications(id) ON DELETE CASCADE;


--
-- Name: jobs jobs_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict eJQcBmoHwZhTQ2pd7PYekzn51huanB36nJW30SShQo5PRyW4t6MMD15mgcHilh0

