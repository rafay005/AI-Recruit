# Phase 5 backend notes (skill gap + decision status)

From `ai-recruitment\backend`, with `(venv)` active:

```
alembic upgrade head
uvicorn app.main:app --reload --port 8000
```

`alembic upgrade head` should print: Running upgrade 0003 -> 0004, application decision status and cached skill-gap explanation

## Skill gap

- Built-in assessment (always on, no AI): classifies each missing required skill as critical or trainable
  using the kind of skill (tool, platform, framework, language, core domain), whether the job title or
  responsibilities rely on it, whether the candidate has a similar skill, and whether the foundation it
  builds on is missing.
- AI explanation (only if an AI key is set in .env): the AI reviews the same gaps and explains each one.
  Only skills, years of experience and job titles are sent. No name, email or employer.
  The result is saved, and thrown away automatically if the job or the CV data changes.
- The AI never changes the match score and cannot add skills.

## Decision status

HR can set: under review, shortlisted, interview, rejected, hired, with an optional message.
The candidate sees the status and the message on "My applications". They never see the score,
rank or skill gap. The dashboard "Shortlisted" counts shortlisted + interview + hired.
